"""PR CI waiter engine — a pure, unit-testable verdict state machine.

Given a GitHub PR (repo, number, pinned head SHA, expected checks) and
configurable time bounds (settle window, poll interval, total timeout), the
engine polls PR state + check runs / commit statuses via injected callables
and returns a STRUCTURED terminal verdict.

DESIGN: pure engine — no network calls, no `gh` CLI invocation, no real
sleeps inside the implementation.  The GitHub-query layer AND the clock/sleep
are injected so every verdict path is unit-testable with fakes (spec §7
"Traps").

VERDICT SET (spec §4.3):
  ci_pass, ci_failed, stale_head, checks_missing, timeout,
  pr_closed, pr_draft, github_error

The guarded-merge verdicts (merged, merge_guard_review, merge_guard_qa,
merge_guard_mergeable, merge_failed) are OUT OF SCOPE for this module
(PR #3 in the breakdown).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable


# ── data types ───────────────────────────────────────────────────────────────


@dataclass
class CheckState:
    """A single check-run or commit-status for the pinned SHA."""

    name: str
    status: str  # queued | in_progress | pending | completed
    conclusion: str | None = None
    # ^ success | skipped | neutral | failure | cancelled | timed_out |
    #   action_required | None (when status != completed)


@dataclass
class PRState:
    """PR metadata fetched each poll iteration."""

    head_sha: str
    open: bool
    draft: bool


@dataclass
class PRCIWaiterVerdict:
    """Structured terminal verdict from the waiter engine.

    Carries diagnostic detail so the task owner can decide revise / fail /
    escalate on resume.
    """

    verdict: str
    observed_head_sha: str | None = None
    checks: list[CheckState] | None = None
    elapsed_seconds: float | None = None
    error_detail: str | None = None


# ── verdict → exit-code map ──────────────────────────────────────────────────

# Stable, distinct non-zero codes for scripting.  ci_pass is the only
# zero-code verdict.
VERDICT_EXIT_CODES: dict[str, int] = {
    "ci_pass": 0,
    "ci_failed": 1,
    "stale_head": 2,
    "checks_missing": 3,
    "timeout": 4,
    "pr_closed": 5,
    "pr_draft": 6,
    "github_error": 7,
}

# ── internal helpers ─────────────────────────────────────────────────────────

_NON_TERMINAL_STATUSES: set[str] = {"queued", "in_progress", "pending"}
_PASSED_CONCLUSIONS: set[str] = {"success", "skipped", "neutral"}
_FAILED_CONCLUSIONS: set[str] = {"failure", "cancelled", "timed_out", "action_required"}


def _classify_check(check: CheckState) -> str | None:
    """Classify a check as 'passed', 'failed', or None (non-terminal)."""
    if check.status in _NON_TERMINAL_STATUSES:
        return None
    if check.conclusion in _PASSED_CONCLUSIONS:
        return "passed"
    if check.conclusion in _FAILED_CONCLUSIONS:
        return "failed"
    # Unknown conclusion — treat as non-terminal (keep polling)
    return None


# ── clock protocol ───────────────────────────────────────────────────────────


class _Clock:
    """Minimal clock interface for injection.

    Any object with monotonic() and sleep(seconds) satisfies this protocol.
    """

    ...


# ── engine ───────────────────────────────────────────────────────────────────


def wait_for_ci(
    *,
    repo: str,
    pr_number: int,
    pinned_head_sha: str,
    expected_checks: list[str],
    settle_seconds: float,
    poll_interval_seconds: float,
    timeout_seconds: float,
    fetch_pr_state: Callable[[], PRState],
    fetch_checks: Callable[[str], list[CheckState]],
    clock: object,
) -> PRCIWaiterVerdict:
    """Poll GitHub until CI reaches a terminal verdict for *pinned_head_sha*.

    Poll-loop order per spec §4.1:
      1. Fetch PR state.
      2. Re-verify head SHA FIRST — if != pinned_head_sha → stale_head (terminal).
      3. If PR closed → pr_closed (terminal).
      4. If PR draft → pr_draft (terminal).
      5. Collect check runs + commit statuses for pinned SHA.
      6. Settle window: if expected checks absent and elapsed < settle_seconds,
         keep polling — do NOT treat absence as pass.
      7. After settle: if any expected check never appeared → checks_missing.
      8. Classify each check.
      9. All expected checks passed → ci_pass (terminal, merge-eligible).
      10. Any expected check failed → ci_failed (terminal).
      11. Elapsed >= timeout_seconds while still pending → timeout (terminal).
      12. GitHub-query layer raises an unrecoverable error → github_error
          (terminal, carries error detail).

    Parameters
    ----------
    repo: ``owner/repo`` — informational, for error messages.
    pr_number: GitHub PR number.
    pinned_head_sha: full 40-char SHA the PR pointed to when the waiter was
        launched.  The SHA is re-verified on EVERY iteration; if the PR head
        advances the verdict is ``stale_head``.
    expected_checks: list of check-run / commit-status context names that
        must ALL pass for CI to be considered green.
    settle_seconds: how long to wait for expected checks to *appear* before
        treating absence as ``checks_missing``.
    poll_interval_seconds: seconds between polls (injected via clock.sleep).
    timeout_seconds: total bounded wait ceiling.
    fetch_pr_state: callable returning the current PR state (head SHA,
        open/closed, draft).  Raise an exception on unrecoverable GitHub
        errors.
    fetch_checks: callable taking a SHA and returning check-runs / commit
        statuses for that SHA.  Raise an exception on unrecoverable GitHub
        errors.
    clock: object with ``monotonic() -> float`` and ``sleep(seconds)``.
        The implementation, not the test, does the sleeping.
    """
    start = clock.monotonic()  # type: ignore[union-attr]

    def _now() -> float:
        return clock.monotonic()  # type: ignore[union-attr]

    def _elapsed() -> float:
        return _now() - start

    def _verdict(
        name: str,
        observed_head_sha: str | None = None,
        checks: list[CheckState] | None = None,
        error_detail: str | None = None,
    ) -> PRCIWaiterVerdict:
        return PRCIWaiterVerdict(
            verdict=name,
            observed_head_sha=observed_head_sha,
            checks=checks,
            elapsed_seconds=_elapsed(),
            error_detail=error_detail,
        )

    # Expected checks as a set for fast lookup
    expected: set[str] = set(expected_checks)

    while True:
        # ── fetch PR state (with error guard) ──
        try:
            pr = fetch_pr_state()
        except Exception as exc:
            return _verdict("github_error", error_detail=str(exc))

        # ── 2. SHA re-verify FIRST (before reading checks) ──
        if pr.head_sha != pinned_head_sha:
            return _verdict("stale_head", observed_head_sha=pr.head_sha)

        # ── 3. PR closed ──
        if not pr.open:
            return _verdict("pr_closed")

        # ── 4. PR draft ──
        if pr.draft:
            return _verdict("pr_draft")

        # ── 5. Collect checks (with error guard) ──
        try:
            all_checks = fetch_checks(pinned_head_sha)
        except Exception as exc:
            return _verdict("github_error", error_detail=str(exc))

        # Map checks by name for classification
        checks_by_name: dict[str, CheckState] = {
            c.name: c for c in all_checks
        }

        # ── 6. Settle window — absent expected checks → keep polling ──
        missing_expected = expected - set(checks_by_name.keys())
        if missing_expected and _elapsed() < settle_seconds:
            # Timeout ceiling dominates — never extend past timeout_seconds
            if _elapsed() >= timeout_seconds:
                return _verdict("timeout", checks=all_checks)
            # Cap sleep to remaining settle AND remaining timeout
            remaining = min(
                settle_seconds - _elapsed(),
                timeout_seconds - _elapsed(),
                poll_interval_seconds,
            )
            _sleep(clock, remaining)
            continue

        # ── 7. After settle: expected checks never appeared ──
        if missing_expected:
            # Timeout ceiling still dominates — if deadline reached, return timeout
            if _elapsed() >= timeout_seconds:
                return _verdict("timeout", checks=all_checks)
            return _verdict("checks_missing", checks=all_checks)

        # ── 8. Classify expected checks ──
        passed: set[str] = set()
        failed: set[str] = set()
        pending: set[str] = set()

        for name in expected:
            check = checks_by_name[name]
            classification = _classify_check(check)
            if classification == "passed":
                passed.add(name)
            elif classification == "failed":
                failed.add(name)
            else:
                pending.add(name)

        # ── 10. Any expected check failed → ci_failed ──
        if failed:
            return _verdict("ci_failed", checks=all_checks)

        # ── 9. All expected checks passed → ci_pass ──
        if not pending:
            return _verdict("ci_pass", checks=all_checks)

        # ── 11. Timeout check BEFORE sleeping ──
        if _elapsed() >= timeout_seconds:
            return _verdict("timeout", checks=all_checks)

        # ── non-terminal — sleep, then poll again ──
        remaining = min(timeout_seconds - _elapsed(), poll_interval_seconds)
        _sleep(clock, remaining)


def _sleep(clock: object, seconds: float) -> None:
    """Sleep using the injected clock."""
    clock.sleep(seconds)  # type: ignore[union-attr]


# ── real-gh adapter + CLI entrypoint ───────────────────────────────────────


def _gh_fetch_pr_state(repo: str, pr_number: int) -> PRState:
    """Fetch PR state via `gh pr view`.

    Returns a PRState with head_sha, open, draft from the GitHub API.
    Raises RuntimeError on gh failure.
    """
    import json
    import subprocess

    result = subprocess.run(
        [
            "gh", "pr", "view", str(pr_number),
            "--repo", repo,
            "--json", "headRefOid,state,isDraft",
        ],
        capture_output=True,
        text=True,
        timeout=30,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"gh pr view failed (exit {result.returncode}): {result.stderr.strip()}"
        )
    data = json.loads(result.stdout)
    return PRState(
        head_sha=data["headRefOid"],
        open=(data["state"] == "OPEN"),
        draft=data.get("isDraft", False),
    )


def _gh_fetch_checks(repo: str, sha: str) -> list[CheckState]:
    """Fetch check runs + commit statuses for a SHA via `gh api`.

    Returns a combined list of CheckState objects from both check-runs
    and commit-statuses endpoints.  Raises RuntimeError on gh failure.
    """
    import json
    import subprocess

    checks: list[CheckState] = []

    # ── check runs ──
    result = subprocess.run(
        [
            "gh", "api",
            f"repos/{repo}/commits/{sha}/check-runs",
            "--jq", "[.check_runs[] | {name:.name, status:.status, conclusion:.conclusion}]",
        ],
        capture_output=True,
        text=True,
        timeout=30,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"gh api check-runs failed (exit {result.returncode}): {result.stderr.strip()}"
        )
    if result.stdout.strip():
        for item in json.loads(result.stdout):
            checks.append(CheckState(
                name=item["name"],
                status=item["status"],
                conclusion=item.get("conclusion"),
            ))

    # ── commit statuses ──
    result = subprocess.run(
        [
            "gh", "api",
            f"repos/{repo}/commits/{sha}/status",
            "--jq", "[.statuses[]? | {name:.context, status:\"completed\", conclusion:.state}]",
        ],
        capture_output=True,
        text=True,
        timeout=30,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"gh api commit-status failed (exit {result.returncode}): {result.stderr.strip()}"
        )
    if result.stdout.strip():
        for item in json.loads(result.stdout):
            checks.append(CheckState(
                name=item["name"],
                status=item["status"],
                conclusion=item.get("conclusion"),
            ))

    return checks


class _RealClock:
    """Real monotonic clock wrapping time.monotonic / time.sleep."""

    @staticmethod
    def monotonic() -> float:
        import time
        return time.monotonic()

    @staticmethod
    def sleep(seconds: float) -> None:
        import time
        time.sleep(seconds)


if __name__ == "__main__":
    import argparse
    import json
    import sys

    parser = argparse.ArgumentParser(
        description="PR CI waiter — poll GitHub checks for a pinned PR head SHA.",
    )
    parser.add_argument("--repo", required=True, help="owner/repo")
    parser.add_argument("--pr", required=True, type=int, help="PR number")
    parser.add_argument("--head-sha", required=True, help="Pinned 40-char head SHA")
    parser.add_argument(
        "--expected-check", action="append", default=[],
        dest="expected_checks",
        help="Check name that must pass (repeatable)",
    )
    parser.add_argument(
        "--settle-seconds", type=float, default=120.0,
        help="Seconds to wait for expected checks to appear (default: 120)",
    )
    parser.add_argument(
        "--poll-interval-seconds", type=float, default=15.0,
        help="Seconds between polls (default: 15)",
    )
    parser.add_argument(
        "--timeout-seconds", type=float, default=3600.0,
        help="Total bounded wait ceiling in seconds (default: 3600)",
    )
    args = parser.parse_args()

    # ── Entrypoint guard: reject empty expected-check policy ──
    # The load-bearing PR-CI invariant is 'no checks is not pass'.
    # An empty expected_checks list would cause the engine to return
    # ci_pass without any check actually passing, which breaches the
    # invariant that a CI poll job must verify at least one check.
    # This guard enforces the invariant at the entrypoint layer so the
    # pure engine (unchanged) never receives an empty list.
    if not args.expected_checks:
        output = {
            "verdict": "checks_missing",
            "observed_head_sha": None,
            "elapsed_seconds": 0.0,
            "error_detail": (
                "No --expected-check supplied; at least one expected check "
                "is required. 'No checks is not pass.'"
            ),
            "checks": [],
        }
        json.dump(output, sys.stdout, indent=2)
        sys.stdout.write("\n")
        sys.exit(VERDICT_EXIT_CODES["checks_missing"])

    verdict = wait_for_ci(
        repo=args.repo,
        pr_number=args.pr,
        pinned_head_sha=args.head_sha,
        expected_checks=args.expected_checks,
        settle_seconds=args.settle_seconds,
        poll_interval_seconds=args.poll_interval_seconds,
        timeout_seconds=args.timeout_seconds,
        fetch_pr_state=lambda: _gh_fetch_pr_state(args.repo, args.pr),
        fetch_checks=lambda sha: _gh_fetch_checks(args.repo, sha),
        clock=_RealClock(),
    )

    # Print structured JSON verdict to stdout
    output = {
        "verdict": verdict.verdict,
        "observed_head_sha": verdict.observed_head_sha,
        "elapsed_seconds": verdict.elapsed_seconds,
        "error_detail": verdict.error_detail,
        "checks": [
            {"name": c.name, "status": c.status, "conclusion": c.conclusion}
            for c in (verdict.checks or [])
        ],
    }
    json.dump(output, sys.stdout, indent=2)
    sys.stdout.write("\n")

    exit_code = VERDICT_EXIT_CODES.get(verdict.verdict, 7)
    sys.exit(exit_code)
