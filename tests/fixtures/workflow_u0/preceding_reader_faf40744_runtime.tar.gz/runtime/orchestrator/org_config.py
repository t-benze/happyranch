"""Org-level configuration loaded from <runtime>/org/config.yaml.

A small, additive layer between the global Settings defaults and per-agent
overrides. The file is optional — a runtime without it inherits the global
defaults exactly as before.
"""
from __future__ import annotations

import json
import os
import re
import tempfile
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime, timezone, tzinfo
from typing import TYPE_CHECKING
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

import yaml

from runtime.orchestrator._paths import OrgPaths

if TYPE_CHECKING:
    from runtime.config import Settings
    from runtime.skills.models import ExposedSkill


class OrgConfigError(ValueError):
    """Raised when org/config.yaml is malformed or fails validation."""


# THR-175: the reviewer identity is configured per-org. This is the HappyRanch
# code default — an org that never sets ``reviewer_agents`` treats only
# ``code_reviewer`` as a reviewer leg for inline-chain auto-advance gating.
DEFAULT_REVIEWER_AGENTS: tuple[str, ...] = ("code_reviewer",)


@dataclass(frozen=True)
class DreamingConfig:
    enabled: bool = False
    schedule_time: str = "02:00"
    # None means "inherit" — resolved (dreaming.timezone -> org.timezone ->
    # machine-local -> UTC) via ``resolve_dreaming_timezone``. A None here must
    # never reach ``ZoneInfo`` directly.
    timezone: str | None = None
    catch_up_on_startup: bool = True
    agent_mode: str = "all"
    include_agents: list[str] = field(default_factory=list)
    exclude_agents: list[str] = field(default_factory=list)


_WORK_HOURS_MODES = ("windowed", "continuous")
_WORK_HOURS_DAYS = ("mon", "tue", "wed", "thu", "fri", "sat", "sun")
_INTERVAL_RE = re.compile(r"^(\d+)([hm])$")
_HHMM_RE = re.compile(r"^[0-2][0-9]:[0-5][0-9]$")
_DAY_SECONDS = 24 * 60 * 60


@dataclass(frozen=True)
class WorkHoursScheduleLayer:
    """A partial working-hours schedule. Any leaf left ``None`` inherits from a
    lower precedence tier during ``WorkingHoursConfig.resolve_for``."""
    mode: str | None = None
    window_start: str | None = None
    window_end: str | None = None
    timezone: str | None = None
    interval: str | None = None
    days: tuple[str, ...] | None = None
    catch_up_on_startup: bool | None = None


@dataclass(frozen=True)
class WorkHoursSchedule:
    """A fully resolved effective schedule for one agent (all required leaves
    present for its ``mode``)."""
    mode: str
    interval: str
    timezone: str
    catch_up_on_startup: bool
    window_start: str | None = None
    window_end: str | None = None
    days: tuple[str, ...] | None = None


@dataclass(frozen=True)
class WorkingHoursConfig:
    enabled: bool = False
    default: WorkHoursScheduleLayer = field(default_factory=WorkHoursScheduleLayer)
    teams: dict[str, WorkHoursScheduleLayer] = field(default_factory=dict)
    overrides: dict[str, WorkHoursScheduleLayer] = field(default_factory=dict)
    agent_mode: str = "all"
    include_agents: list[str] = field(default_factory=list)
    exclude_agents: list[str] = field(default_factory=list)

    def resolve_for(self, agent_name: str, team: str | None) -> WorkHoursSchedule:
        """Overlay the three tiers (default -> teams.<team> -> overrides.<agent>)
        leaf-by-leaf and validate the resolved effective schedule. Raises
        OrgConfigError if the merged schedule is incomplete or incoherent for
        its mode."""
        leaves = (
            "mode", "window_start", "window_end", "timezone",
            "interval", "days", "catch_up_on_startup",
        )
        merged: dict[str, object | None] = {leaf: None for leaf in leaves}
        layers = [self.default]
        if team is not None and team in self.teams:
            layers.append(self.teams[team])
        if agent_name in self.overrides:
            layers.append(self.overrides[agent_name])
        for layer in layers:
            for leaf in leaves:
                value = getattr(layer, leaf)
                if value is not None:
                    merged[leaf] = value

        where = f"working_hours (resolved for agent {agent_name!r})"
        mode = merged["mode"]
        if mode is None:
            raise OrgConfigError(f"{where}: mode is required (after resolution)")
        timezone = merged["timezone"]
        if timezone is None:
            raise OrgConfigError(f"{where}: a timezone is required (after resolution)")
        interval = merged["interval"]
        if interval is None:
            raise OrgConfigError(f"{where}: interval is required (after resolution)")
        catch_up = merged["catch_up_on_startup"]
        catch_up = True if catch_up is None else bool(catch_up)

        if mode == "continuous":
            # window and days are ignored in continuous mode.
            _check_interval_divides_day(interval, where)
            return WorkHoursSchedule(
                mode="continuous", interval=interval, timezone=timezone,
                catch_up_on_startup=catch_up,
            )

        # windowed: window.{start,end} + days required after resolution.
        window_start = merged["window_start"]
        window_end = merged["window_end"]
        days = merged["days"]
        if window_start is None or window_end is None:
            raise OrgConfigError(
                f"{where}: windowed mode requires window.start and window.end "
                f"(after resolution)"
            )
        if days is None:
            raise OrgConfigError(f"{where}: windowed mode requires days (after resolution)")
        _check_window_and_interval(window_start, window_end, interval, where)
        return WorkHoursSchedule(
            mode="windowed", interval=interval, timezone=timezone,
            catch_up_on_startup=catch_up, window_start=window_start,
            window_end=window_end, days=tuple(days),
        )


@dataclass(frozen=True)
class MemorySearchConfig:
    """THR-032 P4a: memory search defaults."""
    default_limit: int = 20
    include_kb_by_default: bool = False
    include_superseded_by_default: bool = False
    include_evicted_by_default: bool = False


@dataclass(frozen=True)
class MemoryCompactionConfig:
    """THR-032 P3b: memory compaction policy defaults."""
    enabled: bool = False
    salience_floor: int = 10
    stale_days: int = 45
    superseded_grace_days: int = 7
    max_evictions_per_run: int = 25
    # THR-091 WS-D: auto-trigger threshold. 0 = disabled (default).
    # When enabled=True and auto_trigger_entry_count > 0, write_entry
    # invokes compact() inline once entry count >= this threshold.
    auto_trigger_entry_count: int = 0


@dataclass(frozen=True)
class OrgConfig:
    session_timeout_seconds: int | None = None
    # Org-wide local timezone. None (the default) means "inherit machine-local"
    # — resolved via ``resolve_org_timezone``. An explicit value must be a valid
    # IANA name (validated at load).
    timezone: str | None = None
    dreaming: DreamingConfig = field(default_factory=DreamingConfig)
    working_hours: WorkingHoursConfig = field(default_factory=WorkingHoursConfig)
    threads_enabled: bool = True
    threads_default_turn_cap: int = 500
    threads_invocation_timeout_seconds: int | None = None
    # THR-195 / TASK-6036: daemon-managed workspace cleanup scheduler kill
    # switch (enabled by default). Set ``workspace_cleanup.enabled: false``
    # in the org config.yaml to disable the capability for this org. This is
    # an existing daemon/org config mechanism only — no new public
    # API/CLI/UI surface.
    workspace_cleanup_enabled: bool = True
    # Reserved for a later reclamation hook. There is no action consumer yet,
    # so true is inert and does not enable reclamation.
    workspace_cleanup_reclamation_actions_enabled: bool = False
    # THR-032 Phase 2: char budget for the per-task MEMORY-DIGEST push block.
    # Default ~1500 chars ≈ a dozen pointer lines; set to 0 to disable the
    # digest entirely. Must be >= 0.
    memory_digest_budget: int = 1500
    # THR-032 P3b/P4a: memory search and compaction config
    memory_search: MemorySearchConfig = field(default_factory=MemorySearchConfig)
    memory_compaction: MemoryCompactionConfig = field(default_factory=MemoryCompactionConfig)
    # THR-026 seq33: per-slice revise-round budget. When > 0, caps the number
    # of genuine revise cycles (worker-of-record re-delegations) before a
    # deliberate stop-with-best. 0 = disabled (today's behavior unchanged).
    max_revise_rounds: int = 0
    # THR-175: configured reviewer identities. A chain leg whose ``agent`` is
    # in this list is a *reviewer leg* — its verdict gates downstream
    # auto-advance and it MUST declare ``expect_verdict: "APPROVE"``.
    reviewer_agents: tuple[str, ...] = DEFAULT_REVIEWER_AGENTS

    @classmethod
    def load_from_text(cls, text: str, path: str = "<text>") -> "OrgConfig":
        """Parse YAML text directly into OrgConfig. Used in tests and CLI helpers."""
        try:
            data = yaml.safe_load(text) or {}
        except yaml.YAMLError as exc:
            raise OrgConfigError(f"malformed YAML in {path}: {exc}") from exc
        if not isinstance(data, dict):
            raise OrgConfigError(f"{path}: top-level must be a mapping")
        return _build_org_config(data, path)


def _validate_agent_list(
    value: object, name: str, path: str, *, prefix: str = "dreaming.agents",
) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise OrgConfigError(f"{path}: {prefix}.{name} must be a list")
    if not all(isinstance(item, str) for item in value):
        raise OrgConfigError(f"{path}: {prefix}.{name} entries must be strings")
    return list(value)


def _validate_positive_int(
    value: object, name: str, *, min_v: int, max_v: int, path: str,
) -> int:
    if not isinstance(value, int) or isinstance(value, bool):
        raise OrgConfigError(f"{path}: {name} must be an integer, got {value!r}")
    if value < min_v or value > max_v:
        raise OrgConfigError(
            f"{path}: {name} must be in [{min_v}, {max_v}], got {value}"
        )
    return value


def _parse_dreaming(block: dict, path: str) -> DreamingConfig:
    if not isinstance(block, dict):
        raise OrgConfigError(f"{path}: dreaming must be a mapping")

    enabled = block.get("enabled", False)
    if not isinstance(enabled, bool):
        raise OrgConfigError(f"{path}: dreaming.enabled must be a boolean")

    schedule = block.get("schedule", {})
    if schedule is None:
        schedule = {}
    if not isinstance(schedule, dict):
        raise OrgConfigError(f"{path}: dreaming.schedule must be a mapping")
    schedule_time = schedule.get("time", "02:00")
    if not isinstance(schedule_time, str) or not re.match(r"^[0-2][0-9]:[0-5][0-9]$", schedule_time):
        raise OrgConfigError(f"{path}: dreaming.schedule.time must be HH:MM")
    hour = int(schedule_time[:2])
    if hour > 23:
        raise OrgConfigError(f"{path}: dreaming.schedule.time must be HH:MM")
    # Omitted -> None (inherit org.timezone -> machine-local -> UTC at resolve
    # time). An explicit value is validated as a real IANA name.
    timezone = schedule.get("timezone")
    if timezone is not None:
        if not isinstance(timezone, str):
            raise OrgConfigError(f"{path}: dreaming.schedule.timezone must be a string")
        try:
            ZoneInfo(timezone)
        except ZoneInfoNotFoundError as exc:
            raise OrgConfigError(f"{path}: unknown dreaming.schedule.timezone {timezone!r}") from exc
    catch_up = schedule.get("catch_up_on_startup", True)
    if not isinstance(catch_up, bool):
        raise OrgConfigError(f"{path}: dreaming.schedule.catch_up_on_startup must be a boolean")

    agents = block.get("agents", {})
    if agents is None:
        agents = {}
    if not isinstance(agents, dict):
        raise OrgConfigError(f"{path}: dreaming.agents must be a mapping")
    mode = agents.get("mode", "all")
    if mode not in {"all", "whitelist"}:
        raise OrgConfigError(f"{path}: dreaming.agents.mode must be one of ['all', 'whitelist']")

    return DreamingConfig(
        enabled=enabled,
        schedule_time=schedule_time,
        timezone=timezone,
        catch_up_on_startup=catch_up,
        agent_mode=mode,
        include_agents=_validate_agent_list(agents.get("include"), "include", path),
        exclude_agents=_validate_agent_list(agents.get("exclude"), "exclude", path),
    )


def _interval_to_seconds(value: str) -> int:
    """Convert an already-format-validated ``Nh``/``Nm`` interval to seconds."""
    m = _INTERVAL_RE.match(value)
    assert m is not None  # callers validate format first
    return int(m.group(1)) * (3600 if m.group(2) == "h" else 60)


def _hhmm_to_seconds(value: str) -> int:
    return int(value[:2]) * 3600 + int(value[3:]) * 60


def _validate_timezone(value: object, label: str, path: str) -> str:
    if not isinstance(value, str):
        raise OrgConfigError(f"{path}: {label} must be a string")
    try:
        ZoneInfo(value)
    except ZoneInfoNotFoundError as exc:
        raise OrgConfigError(f"{path}: unknown {label} {value!r}") from exc
    return value


def _machine_local_iana() -> str | None:
    """Best-effort IANA zone name for the host, stdlib-only (POSIX).

    Reads the ``/etc/localtime`` symlink and parses its ``zoneinfo/`` suffix —
    how darwin and linux expose the configured zone. Returns None when the link
    is absent/unreadable, unparseable, or names a zone ``ZoneInfo`` can't load.
    """
    try:
        link = os.readlink("/etc/localtime")
    except OSError:
        return None
    marker = "zoneinfo/"
    idx = link.rfind(marker)
    if idx == -1:
        return None
    name = link[idx + len(marker):].strip("/")
    if not name:
        return None
    try:
        ZoneInfo(name)
    except (ZoneInfoNotFoundError, ValueError):
        return None
    return name


def _resolve_timezone(value: str | None) -> tuple[tzinfo, str]:
    """Resolve a timezone string-or-None to an effective ``(tzinfo, display)``.

    Precedence:
      1. explicit IANA name -> ``ZoneInfo(value)``; an invalid value falls
         through gracefully (never crashes);
      2. None -> machine-local: the IANA name from ``/etc/localtime`` when
         derivable, else a fixed offset from ``datetime.now().astimezone()``
         displayed as ``UTC±HH:MM``;
      3. ultimate fallback -> UTC.
    """
    if value is not None:
        try:
            return ZoneInfo(value), value
        except (ZoneInfoNotFoundError, ValueError):
            pass  # graceful fall-through to machine-local
    iana = _machine_local_iana()
    if iana is not None:
        return ZoneInfo(iana), iana
    try:
        local = datetime.now().astimezone()
        offset = local.utcoffset()
        if offset is not None:
            fixed = timezone(offset)
            # timezone.tzname(None) renders "UTC", "UTC+08:00", etc.
            return fixed, fixed.tzname(None)
    except (OSError, ValueError):
        pass
    return timezone.utc, "UTC"


def resolve_timezone_or_local(value: str | None) -> tzinfo:
    """Resolve an explicit-or-None IANA timezone string to an effective tzinfo
    (machine-local then UTC fallback). For call sites that only hold a bare
    timezone string rather than a full ``OrgConfig``."""
    return _resolve_timezone(value)[0]


def resolve_org_timezone(org_config: OrgConfig) -> tzinfo:
    """Effective org timezone as a tzinfo. See ``_resolve_timezone``."""
    return _resolve_timezone(org_config.timezone)[0]


def resolve_org_timezone_display(org_config: OrgConfig) -> tuple[tzinfo, str]:
    """Effective org timezone plus its display name (e.g. ``Asia/Shanghai`` or
    ``UTC+08:00``)."""
    return _resolve_timezone(org_config.timezone)


def resolve_dreaming_timezone(org_config: OrgConfig) -> tzinfo:
    """Effective dreaming timezone as a tzinfo. Precedence: ``dreaming.timezone``
    (explicit) -> ``org.timezone`` -> machine-local -> UTC."""
    effective = org_config.dreaming.timezone
    if effective is None:
        effective = org_config.timezone
    return _resolve_timezone(effective)[0]


def resolve_dreaming_timezone_display(org_config: OrgConfig) -> tuple[tzinfo, str]:
    """Effective dreaming timezone plus its display name. Precedence mirrors
    ``resolve_dreaming_timezone``: ``dreaming.timezone`` (explicit) ->
    ``org.timezone`` -> machine-local -> UTC."""
    effective = org_config.dreaming.timezone
    if effective is None:
        effective = org_config.timezone
    return _resolve_timezone(effective)


def render_current_time_line(
    tz: tzinfo, label: str, now: Callable[[], datetime] | None = None,
) -> str:
    """Render the localized current-time value injected into EVERY agent session
    prompt (task/subtask, wake, thread, dream): ISO-8601 with offset plus the
    zone label, e.g. ``2026-06-27T12:47+08:00 (Asia/Shanghai)`` or, when only an
    offset is derivable, ``2026-06-27T12:47+08:00 (UTC+08:00)``.

    This is the single shared renderer reused by every prompt builder so the
    line is identical across harnesses and session types. ``tz``/``label`` come
    from the caller's effective-timezone resolver
    (``resolve_org_timezone_display`` for task/wake/thread sessions,
    ``resolve_dreaming_timezone_display`` for dreams). ``now`` is injectable so
    prompt snapshot tests can freeze the wall clock; it must return a tz-aware
    UTC datetime (default ``datetime.now(timezone.utc)``)."""
    now_fn = now or (lambda: datetime.now(timezone.utc))
    local = now_fn().astimezone(tz)
    return f"{local.isoformat(timespec='minutes')} ({label})"


def render_compact_skill_index(
    exposed_skills: list[ExposedSkill],
) -> str:
    """Render a compact manifest-only skill index for session prompts.

    Each line includes the spec fields: id, version, description, when_to_use,
    source, and a short how-to-load instruction. Bodies are NOT inlined — they
    load on demand from ``runtime/skills/<slug>/SKILL.md``.

    Entries are sorted by skill id for deterministic output across identical
    registry + config inputs. An empty list produces an empty string (no index
    lines injected).

    Format (per spec):
        - hr:<slug>@<version> — <description>. <when_to_use> Load full
          instructions from <source>/SKILL.md.
    """
    if not exposed_skills:
        return ""

    lines: list[str] = []
    for exposed in sorted(exposed_skills, key=lambda s: s.skill.id):
        skill = exposed.skill
        line = (
            f"- {skill.id}@{skill.version} — {skill.description} "
            f"{skill.when_to_use} "
            f"Load full instructions from {skill.source}/SKILL.md."
        )
        lines.append(line)

    return "\n".join(lines)


def resolve_managed_skills_index(
    *,
    paths: OrgPaths,
    agent_name: str,
) -> str:
    """Resolve the compact managed skill index for a session.

    Loads the on-disk registry + eligibility policy (same path the CLI
    ``skills effective --agent`` uses), resolves exposed skills via the
    two-gate exposure function, and renders the compact index string.

    Gracefully returns an empty string when:
    - The skills directory doesn't exist.
    - The org config has no skills eligibility section.
    - No skills pass both gates.
    - Any load error (missing agent def, etc.).

    This is the SINGLE helper reused by every session-creation path
    (task/subtask, thread, dream, wake).
    """
    skills_root = paths.root / "runtime" / "skills"
    if not skills_root.is_dir():
        return ""

    try:
        from runtime.skills.registry import SkillRegistry
        from runtime.skills.resolver import EligibilityResolver
        from runtime.skills.exposure import resolve_exposed_skills

        registry = SkillRegistry(skills_root=skills_root)
        if not registry.list_all():
            return ""

        # Load eligibility policy from org config YAML (skills section)
        policy: dict = {}
        config_path = paths.org_config_path
        if config_path.is_file():
            try:
                raw = yaml.safe_load(config_path.read_text(encoding="utf-8"))
                if isinstance(raw, dict):
                    policy = raw.get("skills", {})
            except (yaml.YAMLError, OSError):
                pass

        # Determine the agent's team from the agent definition
        team = "engineering"
        try:
            from runtime.orchestrator.prompt_loader import load_agent
            agent_def = load_agent(paths, agent_name)
            if agent_def is not None:
                team = agent_def.team
        except Exception:
            pass

        org_slug = paths.root.name

        resolver = EligibilityResolver(policy)
        exposed = resolve_exposed_skills(
            registry, resolver, org=org_slug, team=team, agent=agent_name,
        )
        return render_compact_skill_index(exposed)

    except Exception:
        return ""


def _validate_window_time(value: object, label: str, path: str) -> str:
    if not isinstance(value, str) or not _HHMM_RE.match(value) or int(value[:2]) > 23:
        raise OrgConfigError(f"{path}: {label} must be HH:MM (hour 00-23)")
    return value


def _validate_interval_format(value: object, label: str, path: str) -> str:
    if not isinstance(value, str):
        raise OrgConfigError(f"{path}: {label} must be a string like '2h' or '30m'")
    m = _INTERVAL_RE.match(value)
    if not m or int(m.group(1)) <= 0:
        raise OrgConfigError(f"{path}: {label} must be Nh or Nm and positive, got {value!r}")
    return value


def _validate_days_list(value: object, label: str, path: str) -> tuple[str, ...]:
    if not isinstance(value, list) or not all(isinstance(d, str) for d in value):
        raise OrgConfigError(f"{path}: {label} must be a list of day names")
    bad = [d for d in value if d not in _WORK_HOURS_DAYS]
    if bad:
        raise OrgConfigError(
            f"{path}: {label} has invalid days {bad}; allowed: {list(_WORK_HOURS_DAYS)}"
        )
    return tuple(value)


def _check_interval_divides_day(interval: str, where: str) -> None:
    if _DAY_SECONDS % _interval_to_seconds(interval) != 0:
        raise OrgConfigError(
            f"{where}: continuous interval {interval!r} must evenly divide 24h"
        )


def _check_window_and_interval(start: str, end: str, interval: str, where: str) -> None:
    if start >= end:
        raise OrgConfigError(f"{where}: window.start must be before window.end")
    window_seconds = _hhmm_to_seconds(end) - _hhmm_to_seconds(start)
    if _interval_to_seconds(interval) > window_seconds:
        raise OrgConfigError(
            f"{where}: interval {interval!r} is longer than the window length"
        )


def _validate_layer_coherence(layer: WorkHoursScheduleLayer, label: str, path: str) -> None:
    """Single-layer cross-leaf checks at load time. Cross-tier effective-schedule
    validation additionally runs in ``WorkingHoursConfig.resolve_for``."""
    where = f"{path}: {label}"
    if layer.window_start is not None and layer.window_end is not None:
        if layer.window_start >= layer.window_end:
            raise OrgConfigError(f"{where}.window.start must be before window.end")
    if layer.mode == "continuous" and layer.interval is not None:
        _check_interval_divides_day(layer.interval, where)
    if (
        layer.mode == "windowed"
        and layer.interval is not None
        and layer.window_start is not None
        and layer.window_end is not None
    ):
        _check_window_and_interval(layer.window_start, layer.window_end, layer.interval, where)


def _parse_schedule_layer(block: object, path: str, label: str) -> WorkHoursScheduleLayer:
    if block is None:
        block = {}
    if not isinstance(block, dict):
        raise OrgConfigError(f"{path}: {label} must be a mapping")

    mode = block.get("mode")
    if mode is not None and mode not in _WORK_HOURS_MODES:
        raise OrgConfigError(
            f"{path}: {label}.mode must be one of {list(_WORK_HOURS_MODES)}, got {mode!r}"
        )

    window = block.get("window")
    window_start = window_end = window_tz = None
    if window is not None:
        if not isinstance(window, dict):
            raise OrgConfigError(f"{path}: {label}.window must be a mapping")
        if "start" in window:
            window_start = _validate_window_time(window["start"], f"{label}.window.start", path)
        if "end" in window:
            window_end = _validate_window_time(window["end"], f"{label}.window.end", path)
        if "timezone" in window:
            window_tz = _validate_timezone(window["timezone"], f"{label}.window.timezone", path)

    # window.timezone wins; a bare ``timezone`` leaf is the continuous-mode form.
    timezone = window_tz
    if timezone is None and "timezone" in block:
        timezone = _validate_timezone(block["timezone"], f"{label}.timezone", path)

    interval = block.get("interval")
    if interval is not None:
        interval = _validate_interval_format(interval, f"{label}.interval", path)

    days = block.get("days")
    if days is not None:
        days = _validate_days_list(days, f"{label}.days", path)

    catch_up = block.get("catch_up_on_startup")
    if catch_up is not None and not isinstance(catch_up, bool):
        raise OrgConfigError(f"{path}: {label}.catch_up_on_startup must be a boolean")

    layer = WorkHoursScheduleLayer(
        mode=mode,
        window_start=window_start,
        window_end=window_end,
        timezone=timezone,
        interval=interval,
        days=days,
        catch_up_on_startup=catch_up,
    )
    _validate_layer_coherence(layer, label, path)
    return layer


def _parse_working_hours(block: object, path: str) -> WorkingHoursConfig:
    if not isinstance(block, dict):
        raise OrgConfigError(f"{path}: working_hours must be a mapping")

    enabled = block.get("enabled", False)
    if not isinstance(enabled, bool):
        raise OrgConfigError(f"{path}: working_hours.enabled must be a boolean")

    default = _parse_schedule_layer(block.get("default"), path, "working_hours.default")

    agents = block.get("agents", {})
    if agents is None:
        agents = {}
    if not isinstance(agents, dict):
        raise OrgConfigError(f"{path}: working_hours.agents must be a mapping")
    mode = agents.get("mode", "all")
    if mode not in {"all", "whitelist"}:
        raise OrgConfigError(
            f"{path}: working_hours.agents.mode must be one of ['all', 'whitelist']"
        )

    teams_block = block.get("teams", {})
    if teams_block is None:
        teams_block = {}
    if not isinstance(teams_block, dict):
        raise OrgConfigError(f"{path}: working_hours.teams must be a mapping")
    teams = {
        name: _parse_schedule_layer(value, path, f"working_hours.teams.{name}")
        for name, value in teams_block.items()
    }

    overrides_block = block.get("overrides", {})
    if overrides_block is None:
        overrides_block = {}
    if not isinstance(overrides_block, dict):
        raise OrgConfigError(f"{path}: working_hours.overrides must be a mapping")
    overrides = {
        name: _parse_schedule_layer(value, path, f"working_hours.overrides.{name}")
        for name, value in overrides_block.items()
    }

    return WorkingHoursConfig(
        enabled=enabled,
        default=default,
        teams=teams,
        overrides=overrides,
        agent_mode=mode,
        include_agents=_validate_agent_list(
            agents.get("include"), "include", path, prefix="working_hours.agents"
        ),
        exclude_agents=_validate_agent_list(
            agents.get("exclude"), "exclude", path, prefix="working_hours.agents"
        ),
    )


def _parse_threads(block: dict, path: str) -> dict:
    """Parse the threads: block and return kwargs for OrgConfig."""
    if not isinstance(block, dict):
        raise OrgConfigError(f"{path}: threads must be a mapping")

    kwargs: dict = {}

    if "enabled" in block:
        enabled = block["enabled"]
        if not isinstance(enabled, bool):
            raise OrgConfigError(f"{path}: threads.enabled must be a boolean, got {enabled!r}")
        kwargs["threads_enabled"] = enabled

    if "default_turn_cap" in block:
        cap = block["default_turn_cap"]
        if not isinstance(cap, int) or isinstance(cap, bool) or cap <= 0:
            raise OrgConfigError(
                f"{path}: threads.default_turn_cap must be a positive int, got {cap!r}"
            )
        kwargs["threads_default_turn_cap"] = cap

    if "invocation_timeout_seconds" in block:
        t = block["invocation_timeout_seconds"]
        if t is not None and (not isinstance(t, int) or isinstance(t, bool) or t <= 0):
            raise OrgConfigError(
                f"{path}: threads.invocation_timeout_seconds must be a positive int or null, "
                f"got {t!r}"
            )
        kwargs["threads_invocation_timeout_seconds"] = t

    return kwargs


def _parse_workspace_cleanup(block: dict, path: str) -> dict:
    """Parse the workspace_cleanup: block and return kwargs for OrgConfig.

    THR-195 / TASK-6036: an enabled-by-default kill switch for the
    daemon-managed workspace cleanup scheduler. ``workspace_cleanup.enabled``
    defaults to True when the block or the key is absent; set it to false to
    disable the capability for the org. The strictly boolean
    ``reclamation_actions_enabled`` key defaults to False and is reserved for
    a later hook; it currently has no action consumer. Existing daemon/org
    config mechanism only (no new public API/CLI/UI surface).
    """
    if not isinstance(block, dict):
        raise OrgConfigError(f"{path}: workspace_cleanup must be a mapping")

    kwargs: dict = {}

    if "enabled" in block:
        enabled = block["enabled"]
        if not isinstance(enabled, bool):
            raise OrgConfigError(
                f"{path}: workspace_cleanup.enabled must be a boolean, got {enabled!r}"
            )
        kwargs["workspace_cleanup_enabled"] = enabled

    if "reclamation_actions_enabled" in block:
        actions_enabled = block["reclamation_actions_enabled"]
        if not isinstance(actions_enabled, bool):
            raise OrgConfigError(
                f"{path}: workspace_cleanup.reclamation_actions_enabled must be a boolean, "
                f"got {actions_enabled!r}"
            )
        kwargs["workspace_cleanup_reclamation_actions_enabled"] = actions_enabled

    return kwargs


def _build_org_config(data: dict, path: str) -> OrgConfig:
    """Build OrgConfig from a parsed YAML dict."""
    timeout = data.get("session_timeout_seconds")
    if timeout is not None:
        if not isinstance(timeout, int) or isinstance(timeout, bool) or timeout <= 0:
            raise OrgConfigError(
                f"{path}: session_timeout_seconds must be a positive integer, "
                f"got {timeout!r}"
            )

    # Top-level org timezone. None (default) -> machine-local at resolve time.
    org_timezone = data.get("timezone")
    if org_timezone is not None:
        org_timezone = _validate_timezone(org_timezone, "timezone", path)

    # feishu_notifications is tolerated but ignored — Feishu was removed
    # (TASK-302/THR-022). Legacy configs with this key load without error.
    _feishu_block = data.get("feishu_notifications")

    dreaming_block = data.get("dreaming")
    dreaming_cfg = DreamingConfig()
    if dreaming_block is not None:
        dreaming_cfg = _parse_dreaming(dreaming_block, path)

    working_hours_block = data.get("working_hours")
    working_hours_cfg = WorkingHoursConfig()
    if working_hours_block is not None:
        working_hours_cfg = _parse_working_hours(working_hours_block, path)

    threads_block = data.get("threads")
    threads_kwargs: dict = {}
    if threads_block is not None:
        threads_kwargs = _parse_threads(threads_block, path)

    # THR-195 / TASK-6036: daemon-managed workspace cleanup scheduler kill
    # switch. Absent block/key -> enabled (default True).
    workspace_cleanup_block = data.get("workspace_cleanup")
    workspace_cleanup_kwargs: dict = {}
    if workspace_cleanup_block is not None:
        workspace_cleanup_kwargs = _parse_workspace_cleanup(
            workspace_cleanup_block, path,
        )

    # THR-032 Phase 2: memory_digest_budget — char budget for per-task
    # MEMORY-DIGEST push block. Default 1500; 0 disables the digest.
    digest_budget = data.get("memory_digest_budget", 1500)
    if not isinstance(digest_budget, int) or isinstance(digest_budget, bool):
        raise OrgConfigError(
            f"{path}: memory_digest_budget must be an integer, got {digest_budget!r}"
        )
    if digest_budget < 0:
        raise OrgConfigError(
            f"{path}: memory_digest_budget must be >= 0, got {digest_budget}"
        )

    # THR-026 seq33: max_revise_rounds — per-slice revise-round budget.
    # Default 0 (disabled, today's behavior unchanged).
    max_revise = data.get("max_revise_rounds", 0)
    if not isinstance(max_revise, int) or isinstance(max_revise, bool):
        raise OrgConfigError(
            f"{path}: max_revise_rounds must be an integer, got {max_revise!r}"
        )
    if max_revise < 0:
        raise OrgConfigError(
            f"{path}: max_revise_rounds must be >= 0, got {max_revise}"
        )

    # THR-175: reviewer identities. A non-empty list of non-empty strings.
    # Omitted -> DEFAULT_REVIEWER_AGENTS (code_reviewer).
    reviewer_agents = data.get("reviewer_agents")
    reviewer_agents_tuple = DEFAULT_REVIEWER_AGENTS
    if reviewer_agents is not None:
        if not isinstance(reviewer_agents, list) or not reviewer_agents:
            raise OrgConfigError(
                f"{path}: reviewer_agents must be a non-empty list"
            )
        if not all(isinstance(n, str) and n.strip() for n in reviewer_agents):
            raise OrgConfigError(
                f"{path}: reviewer_agents entries must be non-empty strings"
            )
        reviewer_agents_tuple = tuple(reviewer_agents)

    # THR-032 P4a: memory search config
    search_cfg = MemorySearchConfig()
    search_block = data.get("memory_search")
    if search_block is not None:
        if not isinstance(search_block, dict):
            raise OrgConfigError(f"{path}: memory_search must be a mapping")
        search_cfg = MemorySearchConfig(
            default_limit=_validate_positive_int(
                search_block.get("default_limit", 20), "memory_search.default_limit",
                min_v=1, max_v=200, path=path,
            ),
            include_kb_by_default=bool(search_block.get("include_kb_by_default", False)),
            include_superseded_by_default=bool(search_block.get("include_superseded_by_default", False)),
            include_evicted_by_default=bool(search_block.get("include_evicted_by_default", False)),
        )

    # THR-032 P3b: memory compaction config
    comp_cfg = MemoryCompactionConfig()
    comp_block = data.get("memory_compaction")
    if comp_block is not None:
        if not isinstance(comp_block, dict):
            raise OrgConfigError(f"{path}: memory_compaction must be a mapping")
        comp_cfg = MemoryCompactionConfig(
            enabled=bool(comp_block.get("enabled", False)),
            salience_floor=_validate_positive_int(
                comp_block.get("salience_floor", 10), "memory_compaction.salience_floor",
                min_v=0, max_v=100, path=path,
            ),
            stale_days=_validate_positive_int(
                comp_block.get("stale_days", 45), "memory_compaction.stale_days",
                min_v=1, max_v=3650, path=path,
            ),
            superseded_grace_days=_validate_positive_int(
                comp_block.get("superseded_grace_days", 7), "memory_compaction.superseded_grace_days",
                min_v=1, max_v=3650, path=path,
            ),
            max_evictions_per_run=_validate_positive_int(
                comp_block.get("max_evictions_per_run", 25), "memory_compaction.max_evictions_per_run",
                min_v=1, max_v=10000, path=path,
            ),
            auto_trigger_entry_count=_validate_positive_int(
                comp_block.get("auto_trigger_entry_count", 0), "memory_compaction.auto_trigger_entry_count",
                min_v=0, max_v=100000, path=path,
            ),
        )

    # THR-107: the legacy per-org executor_profiles block is NO LONGER
    # parsed — custom executor profiles live exclusively in the
    # machine-global runtime store (runtime_executor_store.py). A lingering
    # block in config.yaml is treated like any other unknown key (ignored
    # here); the one-shot startup migration lifts and loudly deprecates it.

    return OrgConfig(
        session_timeout_seconds=timeout,
        timezone=org_timezone,
        dreaming=dreaming_cfg,
        working_hours=working_hours_cfg,
        memory_digest_budget=digest_budget,
        max_revise_rounds=max_revise,
        reviewer_agents=reviewer_agents_tuple,
        memory_search=search_cfg,
        memory_compaction=comp_cfg,
        **threads_kwargs,
        **workspace_cleanup_kwargs,
    )


def load_org_config(paths: OrgPaths) -> OrgConfig:
    """Load <runtime>/org/config.yaml. Missing file -> empty OrgConfig."""
    path = paths.org_config_path
    if not path.exists():
        return OrgConfig()

    try:
        data = yaml.safe_load(path.read_text()) or {}
    except yaml.YAMLError as exc:
        raise OrgConfigError(f"malformed YAML in {path}: {exc}") from exc
    if not isinstance(data, dict):
        raise OrgConfigError(f"{path}: top-level must be a mapping")

    return _build_org_config(data, str(path))


# ------------------------------------------------------------------
# ALLOW-LIST keys that the Settings GUI can mutate via PUT /settings/org.
# Every other top-level key in org/config.yaml is carried through verbatim
# (feishu_notifications, unknown future keys, etc.).
# ------------------------------------------------------------------

_ORG_WRITABLE_KEYS = {
    "dreaming",
    "threads",
    "session_timeout_seconds",
    "working_hours",  # THR-035: Work-Hours Config UI write surface (TASK-967)
    "reviewer_agents",  # THR-175: configured reviewer identities
}


def _deep_merge(base: dict, overrides: dict) -> dict:
    """Recursively merge *overrides* into *base*.

    Dictionaries are merged recursively — sibling keys in *base* survive
    unless explicitly overridden. All other types (scalars, lists, None)
    are replaced outright by the override value. A ``None`` override clears
    the key so nullable fields (e.g. ``session_timeout_seconds``) can revert
    to default.
    """
    result = dict(base)
    for key, value in overrides.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def save_org_config(paths: OrgPaths, patch: dict) -> None:
    """Atomically deep-merge *patch* into org/config.yaml for allow-listed keys.

    THR-095: the 4 web-writable knobs (dreaming, threads, session_timeout_seconds,
    working_hours) are NO LONGER persisted to config.yaml — the DB-backed
    org_settings table is the single authoritative store.  This function strips
    those keys before the file write while still deep-merging them for validation,
    so a bad patch is still rejected.

    The file write is additive-only: non-writable keys (timezone, memory_*,
    max_revise_rounds) remain file-persisted.
    """
    config_path = paths.org_config_path

    # 1. Read current raw dict
    if config_path.exists():
        try:
            raw = yaml.safe_load(config_path.read_text()) or {}
        except yaml.YAMLError as exc:
            raise OrgConfigError(f"malformed YAML in {config_path}: {exc}") from exc
        if not isinstance(raw, dict):
            raise OrgConfigError(f"{config_path}: top-level must be a mapping")
    else:
        raw = {}

    # 2. Deep-merge only allow-listed keys
    raw = dict(raw)  # shallow copy to avoid mutating the parsed object
    for key in _ORG_WRITABLE_KEYS:
        if key in patch:
            if isinstance(patch[key], dict) and isinstance(raw.get(key), dict):
                raw[key] = _deep_merge(raw[key], patch[key])
            else:
                raw[key] = patch[key]

    # 3. Validate candidate via the authoritative validator
    try:
        _build_org_config(raw, str(config_path))
    except OrgConfigError:
        raise  # re-raise so the route can return 422

    # 4. Strip web-writable keys before writing to file (THR-095: DB is the
    #    single authoritative store for these knobs).
    for key in _ORG_WRITABLE_KEYS:
        raw.pop(key, None)

    # 5. Atomic write
    config_path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(
        prefix=".org-config.", suffix=".yaml", dir=str(config_path.parent)
    )
    try:
        with os.fdopen(fd, "w") as fh:
            yaml.safe_dump(raw, fh, sort_keys=False)
        os.replace(tmp, config_path)
    except Exception:
        try:
            os.unlink(tmp)
        except FileNotFoundError:
            pass
        raise



# ── Executor profile config write (THR-052 PR-2) ───────────────────────
# ── Org Settings seed (THR-095) ───────────────────────────────────────
#
# One-shot migration: read the 4 writable knobs from org/config.yaml and
# write them into the org_settings DB table EXACTLY ONCE per org.  After
# the seed, config.yaml is NO LONGER the read source for these keys — the
# DB is the single authoritative store.

_ORG_SETTINGS_SEED_SENTINEL = ".org_settings_seeded"


def seed_org_settings_from_config(
    paths: OrgPaths,
    db,  # Database, forward-ref
) -> dict[str, str]:
    """One-shot: copy 4 writable knob values from config.yaml → org_settings DB.

    Returns {section: value_json} for the seeded keys (empty dict when already
    seeded or config.yaml absent).

    Idempotent: a sentinel file (``.org_settings_seeded``) in the org directory
    gates the operation.  Once the sentinel exists, this function is a no-op.
    """
    sentinel = paths.root / _ORG_SETTINGS_SEED_SENTINEL
    if sentinel.exists():
        return {}

    seeded: dict[str, str] = {}

    # Read current config.yaml values for the 4 writable keys.
    org_cfg = load_org_config(paths)

    # dreaming: store in the same shape as config.yaml so the PATCH deep-merge
    # works correctly.  Note: catch_up_on_startup lives under schedule in YAML.
    dreaming = org_cfg.dreaming
    dreaming_json = json.dumps(
        {"enabled": dreaming.enabled,
         "schedule": {"time": dreaming.schedule_time,
                      "timezone": dreaming.timezone,
                      "catch_up_on_startup": dreaming.catch_up_on_startup},
         "agents": {"mode": dreaming.agent_mode,
                    "include": list(dreaming.include_agents),
                    "exclude": list(dreaming.exclude_agents)}},
    )
    db.upsert_org_setting("dreaming", dreaming_json)
    seeded["dreaming"] = dreaming_json

    # threads: three flat fields.
    threads_json = json.dumps({
        "enabled": org_cfg.threads_enabled,
        "default_turn_cap": org_cfg.threads_default_turn_cap,
        "invocation_timeout_seconds": org_cfg.threads_invocation_timeout_seconds,
    })
    db.upsert_org_setting("threads", threads_json)
    seeded["threads"] = threads_json

    # session_timeout_seconds: scalar, but stored as JSON for uniform access.
    sto_json = json.dumps(org_cfg.session_timeout_seconds)
    db.upsert_org_setting("session_timeout_seconds", sto_json)
    seeded["session_timeout_seconds"] = sto_json

    # working_hours: store in config.yaml nested shape.
    wh = org_cfg.working_hours
    wh_json = json.dumps({
        "enabled": wh.enabled,
        "agents": {"mode": wh.agent_mode,
                   "include": list(wh.include_agents),
                   "exclude": list(wh.exclude_agents)},
        "default": _working_hours_layer_to_dict(wh.default),
        "teams": {name: _working_hours_layer_to_dict(layer) for name, layer in wh.teams.items()},
        "overrides": {name: _working_hours_layer_to_dict(layer) for name, layer in wh.overrides.items()},
    })
    db.upsert_org_setting("working_hours", wh_json)
    seeded["working_hours"] = wh_json

    # THR-175: reviewer identities (5th writable knob). Validated against the
    # live roster — an unknown name is never persisted (fail-closed default).
    reviewer_json = json.dumps(_persistable_reviewer_agents(paths, org_cfg.reviewer_agents))
    db.upsert_org_setting("reviewer_agents", reviewer_json)
    seeded["reviewer_agents"] = reviewer_json

    # One-time strip the writable keys from config.yaml so the
    # git-tracked seed file no longer carries stale values.
    _strip_writable_keys_from_config(paths)

    # Write the sentinel so this never runs again.
    sentinel.write_text("")
    return seeded


def backfill_reviewer_agents_setting(paths: OrgPaths, db) -> str | None:
    """Idempotent: ensure a ``reviewer_agents`` org_settings row exists (THR-175).

    The 4-knob seed above is gated by ``.org_settings_seeded``; orgs deployed
    before THR-175 already fired that sentinel and therefore never received a
    ``reviewer_agents`` row.  This backfill persists the org's configured
    ``reviewer_agents`` from config.yaml (or the code default) WITHOUT
    re-running the 4-knob seed and WITHOUT weakening the sentinel.

    It NEVER overwrites an existing row — an explicit valid setting always
    wins, and an org in a shared deployment with no config override gets the
    code default (there is no family/sibling inheritance).

    Returns the persisted ``value_json``, or None when a row already existed
    (no-op).
    """
    if db.get_org_setting("reviewer_agents") is not None:
        return None
    org_cfg = load_org_config(paths)
    # THR-175: persist only names that are real active agents (fail-closed to
    # the code default when the config names an unknown agent).
    value_json = json.dumps(_persistable_reviewer_agents(paths, org_cfg.reviewer_agents))
    db.upsert_org_setting("reviewer_agents", value_json)
    return value_json


def _working_hours_layer_to_dict(layer) -> dict:
    """Serialize a WorkHoursScheduleLayer into a JSON-safe dict
    matching the config.yaml nested shape."""
    d: dict = {}
    if layer.mode is not None:
        d["mode"] = layer.mode
    # window is a nested dict with only non-None leaves.
    window: dict = {}
    if layer.window_start is not None:
        window["start"] = layer.window_start
    if layer.window_end is not None:
        window["end"] = layer.window_end
    # windowed mode: timezone lives inside the window dict.
    # continuous mode: preserve the bare timezone leaf so the seed
    # round-trips today's effective working_hours.
    if layer.timezone is not None:
        if layer.window_start is not None or layer.window_end is not None:
            window["timezone"] = layer.timezone
        else:
            d["timezone"] = layer.timezone
    if window:
        d["window"] = window
    if layer.interval is not None:
        d["interval"] = layer.interval
    if layer.days is not None:
        d["days"] = list(layer.days)
    if layer.catch_up_on_startup is not None:
        d["catch_up_on_startup"] = layer.catch_up_on_startup
    return d


def _strip_writable_keys_from_config(paths: OrgPaths) -> None:
    """One-time: remove the 4 web-writable keys from org/config.yaml.

    Called ONLY from seed_org_settings_from_config (guarded by sentinel).
    After this, the file retains only non-migrated fields (timezone,
    memory_*, max_revise_rounds).
    """
    config_path = paths.org_config_path
    if not config_path.exists():
        return
    try:
        raw = yaml.safe_load(config_path.read_text()) or {}
    except yaml.YAMLError:
        return
    if not isinstance(raw, dict):
        return
    changed = False
    for key in _ORG_WRITABLE_KEYS:
        if key in raw:
            del raw[key]
            changed = True
    if not changed:
        return
    fd, tmp = tempfile.mkstemp(
        prefix=".org-config.", suffix=".yaml", dir=str(config_path.parent)
    )
    try:
        with os.fdopen(fd, "w") as fh:
            yaml.safe_dump(raw, fh, sort_keys=False)
        os.replace(tmp, config_path)
    except Exception:
        try:
            os.unlink(tmp)
        except FileNotFoundError:
            pass
        raise


# ── THR-106 one-shot skill-id rename: hr:review → hr:reflection ────────
#
# The managed self-reflection skill was renamed (id ``hr:review`` →
# ``hr:reflection``, slug ``review`` → ``reflection``).  Skill eligibility
# policy is persisted ONLY in each deployed org's org/config.yaml (there is
# no DB storage for it), so a bare catalog rename would strand every org
# whose config still lists the old id — an unknown-skill-id validation
# warning and the skill silently dropped from every effective set.

_HR_REVIEW_RENAME_SENTINEL = ".hr_review_renamed"
_HR_REVIEW_OLD_ID = "hr:review"
_HR_REVIEW_NEW_ID = "hr:reflection"

# Token-exact match: never rewrite longer ids sharing the prefix
# (e.g. a hypothetical ``hr:review-notes``).
_HR_REVIEW_TOKEN_RE = re.compile(
    r"(?<![\w-])" + re.escape(_HR_REVIEW_OLD_ID) + r"(?![\w-])"
)


def migrate_hr_review_skill_id(paths: OrgPaths) -> str:
    """One-shot: rewrite ``hr:review`` → ``hr:reflection`` in the persisted
    org/config.yaml skills eligibility section (allow AND deny lists, at
    org/team/agent scope).

    Idempotent: a durable sentinel file (``.hr_review_renamed``) in the org
    root gates the operation — mirroring the ``.agent_yaml_consumed``
    pattern.  Once the sentinel exists this function is a no-op forever,
    even if the old id is later reintroduced.

    The rewrite is TEXTUAL and scoped to the top-level ``skills:`` block so
    unrelated config — comments and formatting included — is preserved
    byte-for-byte.  The result is parse-validated before the atomic write.

    Raises ``OrgConfigError`` (sentinel NOT written, file untouched) when
    the existing config cannot be parsed — the next startup retries.

    Returns an outcome string for startup logging.
    """
    sentinel = paths.root / _HR_REVIEW_RENAME_SENTINEL
    if sentinel.exists():
        return "skipped (already migrated)"

    config_path = paths.org_config_path
    if not config_path.exists():
        # Lock now: any config.yaml written later comes from the renamed
        # seed template and can never carry the old id legitimately.
        sentinel.write_text("")
        return "locked (no config.yaml)"

    text = config_path.read_text(encoding="utf-8")

    # Parse guard — never rewrite a file we cannot parse.
    try:
        raw = yaml.safe_load(text) or {}
    except yaml.YAMLError as exc:
        raise OrgConfigError(
            f"THR-106 skill-id rename: malformed YAML in {config_path}: {exc}"
        ) from exc
    if not isinstance(raw, dict) or "skills" not in raw:
        sentinel.write_text("")
        return "locked (no skills section)"

    # Locate the top-level ``skills:`` block textually: from the column-0
    # ``skills:`` line up to (not including) the next column-0 key.  Blank
    # lines and comments inside the block stay inside.  When the document
    # is a single flow-style mapping (no column-0 ``skills:`` line), fall
    # back to a whole-file token replace — skill ids appear nowhere else
    # in a flow-only config.
    lines = text.splitlines(keepends=True)
    start: int | None = None
    end = len(lines)
    for i, line in enumerate(lines):
        if start is None:
            if re.match(r"^(?:\"skills\"|'skills'|skills)\s*:", line):
                start = i
        elif re.match(r"^[^\s#]", line):
            end = i
            break
    if start is None:
        start, end = 0, len(lines)

    section = "".join(lines[start:end])
    new_section, replaced = _HR_REVIEW_TOKEN_RE.subn(_HR_REVIEW_NEW_ID, section)
    if replaced == 0:
        sentinel.write_text("")
        return "locked (no hr:review references)"

    new_text = "".join(lines[:start]) + new_section + "".join(lines[end:])

    # Post-rewrite validation: the result must still parse.
    try:
        yaml.safe_load(new_text)
    except yaml.YAMLError as exc:  # pragma: no cover — token swap keeps YAML valid
        raise OrgConfigError(
            f"THR-106 skill-id rename produced unparseable YAML for "
            f"{config_path}: {exc}"
        ) from exc

    # Atomic write (same pattern as the other config.yaml writers).
    fd, tmp = tempfile.mkstemp(
        prefix=".org-config.", suffix=".yaml", dir=str(config_path.parent)
    )
    try:
        with os.fdopen(fd, "w") as fh:
            fh.write(new_text)
        os.replace(tmp, config_path)
    except Exception:
        try:
            os.unlink(tmp)
        except FileNotFoundError:
            pass
        raise

    sentinel.write_text("")
    return f"renamed ({replaced} occurrence(s))"


# ── Resolution helpers (THR-095) ──────────────────────────────────────
#
# These resolve a single section's effective value from the DB → code-default
# ladder.  Every consumer site that formerly read a field off load_org_config()
# MUST use the appropriate helper so the DB override always wins.


def _resolve_org_setting_json(db, section: str) -> str | None:
    """Return the raw value_json for *section* from org_settings, or None."""
    return db.get_org_setting(section)


def resolve_org_setting_dreaming(db, *, code_default) -> "DreamingConfig":
    """DB → code-default resolved DreamingConfig."""
    raw = db.get_org_setting("dreaming")
    if raw is None:
        return code_default
    data = json.loads(raw)
    from runtime.orchestrator.org_config import DreamingConfig
    schedule = data.get("schedule", {})
    agents = data.get("agents", {})
    return DreamingConfig(
        enabled=data.get("enabled", code_default.enabled),
        schedule_time=schedule.get("time", code_default.schedule_time),
        timezone=schedule.get("timezone", code_default.timezone),
        catch_up_on_startup=schedule.get("catch_up_on_startup", code_default.catch_up_on_startup),
        agent_mode=agents.get("mode", code_default.agent_mode),
        include_agents=tuple(agents.get("include", [])),
        exclude_agents=tuple(agents.get("exclude", [])),
    )


def resolve_org_setting_threads(db, *, code_default) -> dict:
    """DB → code-default resolved threads settings.

    Returns a dict with keys: enabled, default_turn_cap, invocation_timeout_seconds.
    """
    raw = db.get_org_setting("threads")
    if raw is None:
        return {
            "enabled": code_default.threads_enabled,
            "default_turn_cap": code_default.threads_default_turn_cap,
            "invocation_timeout_seconds": code_default.threads_invocation_timeout_seconds,
        }
    data = json.loads(raw)
    return {
        "enabled": data.get("enabled", code_default.threads_enabled),
        "default_turn_cap": data.get("default_turn_cap", code_default.threads_default_turn_cap),
        "invocation_timeout_seconds": data.get("invocation_timeout_seconds", code_default.threads_invocation_timeout_seconds),
    }


def resolve_org_setting_session_timeout(db, *, code_default: int | None) -> int | None:
    """DB → code-default resolved session_timeout_seconds."""
    raw = db.get_org_setting("session_timeout_seconds")
    if raw is None:
        return code_default
    return json.loads(raw)


def resolve_org_setting_working_hours(db, *, code_default) -> "WorkingHoursConfig":
    """DB → code-default resolved WorkingHoursConfig."""
    raw = db.get_org_setting("working_hours")
    if raw is None:
        return code_default
    data = json.loads(raw)
    from runtime.orchestrator.org_config import WorkingHoursConfig, WorkHoursScheduleLayer
    agents = data.get("agents", {})
    return WorkingHoursConfig(
        enabled=data.get("enabled", code_default.enabled),
        agent_mode=agents.get("mode", code_default.agent_mode),
        include_agents=tuple(agents.get("include", [])),
        exclude_agents=tuple(agents.get("exclude", [])),
        default=_dict_to_working_hours_layer(data.get("default")),
        teams={name: _dict_to_working_hours_layer(v) for name, v in data.get("teams", {}).items()},
        overrides={name: _dict_to_working_hours_layer(v) for name, v in data.get("overrides", {}).items()},
    )


def resolve_known_agent_names(paths: OrgPaths) -> frozenset[str]:
    """The live active-agent roster (excludes ``_pending/`` and ``_terminated/``).

    This is the single source of truth for "is this agent name real in this
    org" — the same file-based registry the settings routes already use via
    ``prompt_loader.list_agents``.  Used to validate ``reviewer_agents``
    against actually-deployed agents rather than a hardcoded allowlist.
    """
    from runtime.orchestrator.prompt_loader import list_agents
    return frozenset(agent.name for agent in list_agents(paths))


def _persistable_reviewer_agents(
    paths: OrgPaths, configured: tuple[str, ...],
) -> list[str]:
    """The ``reviewer_agents`` list that is safe to persist (THR-175 fail-closed).

    The configured value is persisted only when EVERY name is a real active
    agent in this org.  An unknown name (e.g. ``ghost_agent``) means the
    config is stale relative to the live roster — fall back to the code
    default so an unknown reviewer string can never silently turn
    ``code_reviewer`` into a non-reviewer leg.
    """
    known = resolve_known_agent_names(paths)
    if (
        configured
        and len(set(configured)) == len(configured)
        and known
        and all(name in known for name in configured)
    ):
        return list(configured)
    return list(DEFAULT_REVIEWER_AGENTS)


def resolve_org_setting_reviewer_agents(
    db,
    *,
    code_default: tuple[str, ...] = DEFAULT_REVIEWER_AGENTS,
    known_agents: frozenset[str] | set[str],
) -> tuple[str, ...]:
    """DB → code-default resolved reviewer identities (THR-175).

    The ``reviewer_agents`` org_settings row (a JSON list of agent names) is
    the single authoritative source of which chain legs are reviewer legs
    whose verdicts gate downstream auto-advance.  A malformed row (non-list,
    empty, non-string entries) falls back to the code default rather than
    raising — resolution must never break the read path.

    A row naming an UNKNOWN agent (one outside ``known_agents``, the live
    active-agent roster) also falls back to the code default — a persisted
    reviewer string that names no real agent must never be trusted to define
    which legs are reviewer legs, or it would silently demote ``code_reviewer``
    to a non-reviewer and re-open the QA auto-advance hole.
    """
    raw = db.get_org_setting("reviewer_agents")
    if raw is None:
        return tuple(code_default)
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, TypeError, ValueError):
        return tuple(code_default)
    if not isinstance(data, list):
        return tuple(code_default)
    if not data or not all(isinstance(n, str) and n.strip() for n in data):
        return tuple(code_default)
    names = tuple(data)
    if len(set(names)) != len(names):
        return tuple(code_default)
    if any(n not in known_agents for n in names):
        return tuple(code_default)
    return names


def _dict_to_working_hours_layer(d: dict | None):
    from runtime.orchestrator.org_config import WorkHoursScheduleLayer
    if not d:
        return WorkHoursScheduleLayer()
    window = d.get("window", {}) or {}
    # F3 fix: timezone may be bare (continuous-mode) or inside window (windowed).
    timezone = window.get("timezone")
    if timezone is None:
        timezone = d.get("timezone")
    return WorkHoursScheduleLayer(
        mode=d.get("mode"),
        window_start=window.get("start"),
        window_end=window.get("end"),
        timezone=timezone,
        interval=d.get("interval"),
        days=tuple(d["days"]) if "days" in d else None,
        catch_up_on_startup=d.get("catch_up_on_startup"),
    )


# ── DB-backed settings write (THR-095) ──────────────────────────────────
#
# Replaces the former save_org_config (config.yaml) write path for the
# 4 web-writable knobs.  Each section is written to the org_settings DB
# table with its config:<section> audit row in ONE transaction.


def write_org_setting_to_db(
    paths: OrgPaths,
    db,
    patch: dict,
    *,
    actor: str = "founder",
) -> None:
    """Partial-update the 4 web-writable knobs in the org_settings DB.

    1. For each patched section: resolve the current full effective value
       (DB override → code default), deep-merge patch, validate, write to DB
       with its config:<section> audit row.
    2. Also calls save_org_config to strip writable keys from config.yaml.

    Raises OrgConfigError on validation failure."""
    org_cfg = load_org_config(paths)

    # Helper to get the full effective value for a section in config.yaml shape.
    def _effective_dict(key: str) -> dict:
        raw = db.get_org_setting(key)
        if raw is not None:
            return json.loads(raw)
        # Fall back to code defaults serialized in config.yaml shape.
        if key == "dreaming":
            return {
                "enabled": org_cfg.dreaming.enabled,
                "schedule": {
                    "time": org_cfg.dreaming.schedule_time,
                    "timezone": org_cfg.dreaming.timezone,
                    "catch_up_on_startup": org_cfg.dreaming.catch_up_on_startup,
                },
                "agents": {
                    "mode": org_cfg.dreaming.agent_mode,
                    "include": list(org_cfg.dreaming.include_agents),
                    "exclude": list(org_cfg.dreaming.exclude_agents),
                },
            }
        elif key == "threads":
            return {
                "enabled": org_cfg.threads_enabled,
                "default_turn_cap": org_cfg.threads_default_turn_cap,
                "invocation_timeout_seconds": org_cfg.threads_invocation_timeout_seconds,
            }
        elif key == "working_hours":
            wh = org_cfg.working_hours
            return {
                "enabled": wh.enabled,
                "agents": {
                    "mode": wh.agent_mode,
                    "include": list(wh.include_agents),
                    "exclude": list(wh.exclude_agents),
                },
                "default": _working_hours_layer_to_dict(wh.default),
                "teams": {name: _working_hours_layer_to_dict(layer) for name, layer in wh.teams.items()},
                "overrides": {name: _working_hours_layer_to_dict(layer) for name, layer in wh.overrides.items()},
            }
        return {}

    for key in _ORG_WRITABLE_KEYS:
        if key not in patch:
            continue
        patch_val = patch[key]

        # Read current full effective value as before.
        if key == "session_timeout_seconds":
            raw = db.get_org_setting(key)
            before = json.loads(raw) if raw is not None else org_cfg.session_timeout_seconds
        elif key == "reviewer_agents":
            before = list(resolve_org_setting_reviewer_agents(
                db, known_agents=resolve_known_agent_names(paths),
            ))
        else:
            before = _effective_dict(key)

        # Deep-merge patch into current effective value.
        if isinstance(patch_val, dict) and isinstance(before, dict):
            merged = _deep_merge(dict(before), patch_val)
        else:
            merged = patch_val  # scalar replacement (session_timeout_seconds, reviewer_agents)

        # Validate by building a full OrgConfig candidate.
        candidate = _current_raw_dict_from_config(paths)
        candidate.pop(key, None)
        candidate[key] = merged
        _build_org_config(candidate, str(paths.org_config_path))

        # THR-175: a reviewer_agents write must name only real active agents
        # (defense-in-depth — the PUT route already rejects unknown names with
        # a HARD REJECT; this guards any direct write_org_setting_to_db caller).
        if key == "reviewer_agents" and isinstance(merged, list):
            known = resolve_known_agent_names(paths)
            if len(set(merged)) != len(merged):
                raise OrgConfigError("reviewer_agents entries must be unique")
            unknown = sorted(set(merged) - known)
            if unknown:
                raise OrgConfigError(
                    "reviewer_agents references unknown agent(s): "
                    + ", ".join(unknown)
                )

        # Build before/after audit dicts.
        if key == "session_timeout_seconds":
            before_audit = {"value": before} if before is not None else {}
            after_audit = {"value": merged}
        elif key == "reviewer_agents":
            before_audit = {"value": before}
            after_audit = {"value": merged}
        else:
            before_audit = before if isinstance(before, dict) else {}
            after_audit = merged if isinstance(merged, dict) else {}

        # Write to DB with audit (transactional — single commit).
        db.upsert_org_setting(
            section=key,
            value_json=json.dumps(merged if isinstance(merged, dict) else merged),
            before=before_audit,
            after=after_audit,
            actor=actor,
        )

    # THR-095 F1 fix: no longer mutate config.yaml on every PUT.
    # Validation happens in-memory above; the DB is the single authoritative
    # store for the 4 web-writable knobs.  Non-migrated fields (timezone,
    # memory_*) stay untouched in config.yaml.


def _current_raw_dict_from_config(paths: OrgPaths) -> dict:
    """Read the current raw dict from org/config.yaml (or {} if absent)."""
    if paths.org_config_path.exists():
        try:
            raw = yaml.safe_load(paths.org_config_path.read_text()) or {}
        except yaml.YAMLError:
            return {}
        if isinstance(raw, dict):
            return dict(raw)
    return {}


# ── Skills eligibility config write (THR-092 Phase 3a) ──────────────────
#
# A dedicated helper for adding/removing a single skills eligibility rule
# for a SINGLE agent + SINGLE skill. This is deliberately separate from
# save_org_config (the master-bearer settings PATCH path) so the skills
# eligibility section is NOT writable through the generic settings surface.
# Only the scoped POST /agents/{agent_id}/skills/{skill_id}/assign route
# calls this.


def write_skill_eligibility_entry(
    paths: OrgPaths,
    *,
    agent: str,
    skill_id: str,
    action: str,
) -> None:
    """Atomically add or remove a single skills eligibility rule
    for ``agent`` / ``skill_id`` in org/config.yaml.

    ``action`` must be one of ``"allow"`` or ``"remove"``.

    1. Read the current raw dict from disk.
    2. Deep-merge the single rule into
       ``raw["skills"]["agents"][agent]["allow"]``, appending ``skill_id``
       to the list (idempotent — no duplicate). For ``remove``, remove
       ``skill_id`` from the allow list. All other keys (org/teams/other
       agents/other skills) are carried through verbatim.
    3. Validate the candidate via ``_build_org_config``.
       If invalid, raise ``OrgConfigError``.
    4. Atomic write via temp file + ``os.replace``.

    This function never adds ``skills`` to ``_ORG_WRITABLE_KEYS`` —
    it is the ONLY write path for skills eligibility.
    """
    if action not in ("allow", "remove"):
        raise ValueError(f"action must be 'allow' or 'remove', got {action!r}")

    config_path = paths.org_config_path

    # 1. Read current raw dict
    if config_path.exists():
        try:
            raw = yaml.safe_load(config_path.read_text()) or {}
        except yaml.YAMLError as exc:
            raise OrgConfigError(f"malformed YAML in {config_path}: {exc}") from exc
        if not isinstance(raw, dict):
            raise OrgConfigError(f"{config_path}: top-level must be a mapping")
    else:
        raw = {}

    # 2. Deep-merge the single rule
    raw = dict(raw)
    skills = dict(raw.get("skills", {}))
    agents = dict(skills.get("agents", {}))
    agent_rules = dict(agents.get(agent, {}))

    if action == "allow":
        # Append skill_id to the allow list (idempotent)
        allow_list = list(agent_rules.get("allow", []))
        if skill_id not in allow_list:
            allow_list.append(skill_id)
        agent_rules["allow"] = allow_list
    else:
        # Remove skill_id from the allow list
        allow_list = [x for x in agent_rules.get("allow", []) if x != skill_id]
        if allow_list:
            agent_rules["allow"] = allow_list
        else:
            agent_rules.pop("allow", None)

    agents[agent] = agent_rules
    skills["agents"] = agents
    raw["skills"] = skills

    # 3. Validate candidate via the authoritative validator
    try:
        _build_org_config(raw, str(config_path))
    except OrgConfigError:
        raise  # re-raise so the route can return 422

    # 4. Atomic write
    config_path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(
        prefix=".org-config.", suffix=".yaml", dir=str(config_path.parent)
    )
    try:
        with os.fdopen(fd, "w") as fh:
            yaml.safe_dump(raw, fh, sort_keys=False)
        os.replace(tmp, config_path)
    except Exception:
        try:
            os.unlink(tmp)
        except FileNotFoundError:
            pass
        raise
