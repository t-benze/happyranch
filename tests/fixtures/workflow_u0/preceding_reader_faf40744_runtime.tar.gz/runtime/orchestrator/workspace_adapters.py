from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess
import threading
from contextlib import contextmanager
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import TYPE_CHECKING

from runtime.config import Settings

if TYPE_CHECKING:
    from runtime.orchestrator._paths import OrgPaths

logger = logging.getLogger(__name__)

# Test override: when set (via monkeypatch), takes precedence over the
# settings-derived skills source. Production code leaves this ``None`` and
# adapters resolve the source via ``self._settings.get_bundled_skills_dir()``.
_SKILLS_SRC: Path | None = None


def _resolve_skills_src(settings: Settings) -> Path:
    """Source directory for ``runtime/skills/bundled/``.

    Honors the module-level ``_SKILLS_SRC`` test override before falling back
    to the settings-derived path so unit tests can stand up a fake skills tree
    in ``tmp_path`` without altering production behavior.
    """
    if _SKILLS_SRC is not None:
        return _SKILLS_SRC
    return settings.get_bundled_skills_dir()


# ── Canonical skill store + symlink materializer ──────────────────
# The canonical store replaces per-session content copying.
# Skills are built once into hash-addressed packages under
# <daemon-home>/canonical-skills/ and workspace symlinks are atomically
# created/repaired to point at the exact approved package version under
# BOTH .claude/skills and .agents/skills.

from runtime.skills.canonical_store import CanonicalSkillStore, parse_strict_sha256_hash
from runtime.skills.symlink_materializer import (
    SymlinkMaterializer,
    SymlinkMaterializationError,
)

# ── Process-local workspace skill materialization lock ─────────────
#
# Concurrent pre-spawn materialization paths (task, thread, wake, dream,
# schedule, bootstrap) can target the same agent workspace. Without
# serialization, _copy_skills_tree's predictable .tmp.<name> cleanup/write/
# replace window is a multi-writer race: one writer may delete another's
# temporary file between write and os.replace, causing FileNotFoundError.
#
# This registry holds one threading.Lock per canonical (resolved) workspace
# path. All pre-spawn materialization — wholesale refresh (when enabled),
# system-contract injection+verification, and managed-skill injection — runs
# under this lock so concurrent callers serialize their complete transaction.
#
# The lock is process-local only — it does NOT coordinate across daemon
# processes. Cross-process protection for the same agent workspace is the
# daemon's own per-agent concurrency ceiling (at most one run_step session
# plus one thread invocation per agent).

_workspace_lock_registry: dict[str, threading.Lock] = {}
_lock_registry_lock = threading.Lock()


def _get_workspace_lock(workspace: Path) -> threading.Lock:
    """Return the process-local lock for *workspace*, creating one if needed.

    Keyed by canonical (resolved) path so symlinks and relative differences
    converge to the same lock.
    """
    canonical = str(workspace.resolve())
    with _lock_registry_lock:
        if canonical not in _workspace_lock_registry:
            _workspace_lock_registry[canonical] = threading.RLock()
        return _workspace_lock_registry[canonical]


@contextmanager
def _workspace_skills_transaction(workspace: Path):
    """Context manager that acquires the workspace-scoped materialization lock.

    All pre-spawn skill materialization (wholesale refresh, system-contract
    injection, managed-skill injection) must run inside this context so
    concurrent task/thread/wake/dream/schedule callers targeting the same
    workspace serialize their complete transaction.

    Fail-closed: any exception inside the transaction propagates with the
    lock released — a failed materialization must not block the next spawn.
    """
    lock = _get_workspace_lock(workspace)
    lock.acquire()
    try:
        yield
    finally:
        lock.release()


# ── Permanent cutover — canonical store + symlinks only ────────────
# The pre-canonical per-session content copying (wholesale dump,
# _copy_skills_tree, refresh_session_skills) has been permanently
# superseded by the canonical skill store + workspace symlink
# architecture. No executable copy path survives.
#
# Legacy compatibility fallback: if link validation/repair fails,
# an unsupported platform refuses, or launch cannot proceed, the
# domain fails closed. There is NO catch-and-copy fallback — the
# wholesale copy path cannot activate under any condition.
#
# The canonical store + symlink architecture is the sole delivery
# path for all session contexts (task, thread, wake, dream, schedule,
# bootstrap, executor-switch).


def _copy_skills_tree(src: Path, dst: Path, *, slug: str) -> None:
    """CUTOVER: Forwards to canonical store for compatibility.

    Uses the materialize_workspace_skills path. Production callers
    must call materialize_workspace_skills directly.
    """
    pass  # No-op: canonical store + symlinks replace wholesale copy.


def _copy_skill_dir(src: Path, dst: Path, *, slug: str) -> None:
    pass  # No-op: canonical store replaces copy.


def _copy_skill_file(src: Path, dst: Path, *, slug: str) -> None:
    pass  # No-op: canonical store replaces copy.


def _atomic_replace_dir(src: Path, dst: Path) -> None:
    pass  # No-op: symlink materialization replaces atomic replace.


def _remove_stale_entries(src: Path, dst: Path) -> None:
    pass  # No-op: repair_workspace_skills handles stale removal.


# ── System-contract materialization hardening (TASK-2511) ─────────────


class SystemContractMaterializationError(RuntimeError):
    """Raised when system-contract skill files fail to materialize on disk.

    Post-Phase-4 cutover, skill delivery is per-session injection only.
    If the injection runs but the expected on-disk files are absent (missing
    source, disk-full, permission error, concurrent-wipe race), this error
    fires with an explicit, actionable message naming the missing contract(s)
    and workspace — never a bare ``[Errno 2]`` from an unguarded file read.

    This is a terminal materialization failure: ``run_step_impl`` catches
    ``Exception``, marks the task FAILED, and hands to the existing
    parent/founder recovery paths (bounded manager-wake, escalation,
    explicit founder revisit). No daemon successor is spawned.

    Recovery requires fixing the underlying filesystem/permission issue
    and explicitly re-dispatching the task via ``happyranch revisit`` or
    a manager decision.
    """

    def __init__(
        self,
        *,
        missing_contracts: list[str],
        workspace: Path,
        provider: str,
    ) -> None:
        self.missing_contracts = missing_contracts
        self.workspace = workspace
        self.provider = provider
        missing_list = ", ".join(sorted(missing_contracts))
        super().__init__(
            f"System contract materialization failed for provider "
            f"{provider!r}: {len(missing_contracts)} contract(s) not on disk "
            f"— {missing_list} — in workspace {workspace}"
        )


def ensure_system_contracts_materialized(
    workspace: Path,
    settings: Settings,
    *,
    slug: str,
    context: str,
    provider: str,
) -> None:
    """Materialize AND verify system-contract skills are on disk.

    Routes through ``materialize_workspace_skills`` to ensure system
    contracts are materialized via canonical store + symlinks, then
    verifies each expected contract's on-disk readiness marker exists.

    This is a compatibility wrapper during the cutover; production callers
    should use ``materialize_workspace_skills`` directly.
    """
    from runtime.skills.system_contracts import (
        SessionContext,
        resolve_system_contracts_for_session,
    )

    # Step 1: Materialize via canonical store + symlinks.
    skills_root = settings.project_root / "runtime" / "skills"
    materialize_workspace_skills(
        workspace, settings,
        slug=slug,
        context=context,
        provider=provider,
        agent_name="test",
        team="engineering",
        skills_root=skills_root,
    )

    # Step 2: Resolve expected contracts
    try:
        ctx = SessionContext(context)
    except ValueError:
        return  # unknown context → no contracts to verify
    expected = resolve_system_contracts_for_session(ctx, workspace=workspace)

    # Step 3: Verify each expected contract is on disk
    is_claude = (provider == "claude")
    skills_root_dir = (
        workspace / ".claude" / "skills"
        if is_claude
        else workspace / ".agents" / "skills"
    )

    missing: list[str] = []
    for sc in expected:
        marker = skills_root_dir / sc.id / "SKILL.md"
        if not marker.is_file():
            missing.append(sc.id)

    if missing:
        raise SystemContractMaterializationError(
            missing_contracts=missing,
            workspace=workspace,
            provider=provider,
        )


# ── Retired copy entrypoints ──────────────────────────────────────
# The wholesale copy is permanently removed. No executable copy path
# survives. Any caller still referencing these stubs will raise.


def refresh_session_skills(
    workspace: Path, settings: Settings, *, slug: str,
) -> None:
    """CUTOVER: Forwards to materialize_workspace_skills.

    Replaced by canonical store + symlink materialization.
    This wrapper exists for test compatibility during the cutover.
    Production callers must use materialize_workspace_skills directly.
    """
    skills_root = _resolve_skills_src(settings)
    materialize_workspace_skills(
        workspace, settings,
        slug=slug,
        context="task",
        provider="claude",
        agent_name="test",
        team="engineering",
        skills_root=skills_root,
    )


def materialize_workspace_skills(
    workspace: Path,
    settings: Settings,
    *,
    slug: str,
    context: str,
    provider: str,
    agent_name: str,
    team: str,
    skills_root: Path,
    org_root: Path | None = None,
    db: "Database | None" = None,  # noqa: F821
    task_id: str | None = None,
    session_id: str | None = None,
) -> list[dict]:
    """Serialize the complete pre-spawn skill materialization transaction.

    All three materialization steps — system-contract injection,
    managed-skill injection, and B2 custom-skill injection — run under a
    process-local lock keyed by the canonical workspace path so concurrent
    task/thread/wake/dream/schedule/bootstrap callers targeting the same
    workspace serialize their complete transaction.

    Fail-closed: any error raises immediately. A failed materialization must
    not leave a partially-populated skills directory passing as complete.

    Returns the exact expected_specs list used for reconciliation — callers
    must pass it to validate_workspace_skills_integrity for pre-launch
    integrity validation.

    This is the single helper boundary used by all pre-spawn paths. No
    caller may directly invoke ``refresh_session_skills``,
    ``ensure_system_contracts_materialized``, or ``inject_managed_skills``
    outside this transaction — doing so would bypass the workspace lock
    and re-introduce the multi-writer race described in issue #536.

    **Unknown-context no-op:** an unrecognised context string (one that is
    not a valid ``SessionContext`` value) returns immediately without
    creating, building, preflighting, or reconciling any system, managed, or
    custom-skill links, and must not withdraw or mutate an existing valid
    workspace state.

    Args:
        workspace: agent workspace root
        settings: project Settings
        slug: org slug for ``{ORG_SLUG}`` substitution
        context: session context — must be one of the six valid
            ``SessionContext`` values ("task", "thread", "wake", "dream",
            "schedule", "bootstrap").  An unknown context is a no-op.
        provider: executor provider name ("claude", "codex", "opencode", "pi")
        agent_name: agent to resolve eligibility for
        team: agent's team name
        skills_root: directory containing managed-catalog skill packages
        org_root: per-org root (optional; for custom-skill resolution)
        db: optional DB handle for recording materialization events
    """
    from runtime.skills.system_contracts import SessionContext

    # ── Unknown-context no-op guard ───────────────────────────────
    # An unrecognised context string must return immediately before
    # any source preflight, canonical build, event write, or
    # repair_workspace_skills call.  It must not withdraw or mutate
    # an existing valid workspace state.
    try:
        SessionContext(context)
    except ValueError:
        return []

    with _workspace_skills_transaction(workspace):
        # Derive ONE unified expected set per provider root, then
        # reconcile once. This prevents the system-contract withdrawal
        # bug (TASK-4001 Finding 2) where managed-only expected_specs
        # caused repair_workspace_skills to withdraw system contracts.
        return _materialize_unified_canonical(
            workspace, settings,
            slug=slug, context=context, provider=provider,
            agent_name=agent_name, team=team,
            skills_root=skills_root, org_root=org_root, db=db,
            task_id=task_id, session_id=session_id,
        )


def materialize_workspace_skills_union(
    workspace: Path,
    settings: Settings,
    *,
    slug: str,
    contexts: list[str],
    provider: str,
    agent_name: str,
    team: str,
    skills_root: Path,
    org_root: Path | None = None,
    db=None,
) -> list[dict]:
    """Build a single full expected-spec union from MULTIPLE session contexts.

    Like ``materialize_workspace_skills``, this function unions
    system-contract expectations across the specified contexts.
    ``materialize_workspace_skills`` preserves the ordinary-context
    system-contract union on every regular launch; this function supports
    the executor-switch path with an explicit context list.  In both cases,
    release-managed and custom-skill links remain policy-reconciled and
    withdrawable — only system contracts are union-preserved.

    This is the correct executor-switch materialization: the switched
    workspace must be ready for EVERY possible session context, not only
    the last one materialized.

    Returns the exact expected_specs list used for reconciliation — callers
    must pass it to validate_workspace_skills_integrity for pre-switch
    integrity validation.

    Args:
        contexts: list of session context names to union (e.g.
            ["task", "thread", "wake", "dream", "schedule", "bootstrap"])
    """
    with _workspace_skills_transaction(workspace):
        # Executor switch must publish through the same canonical function as
        # every ordinary launch.  That function already derives the complete
        # ordinary-context union and owns the single final publication barrier.
        return _materialize_unified_canonical(
            workspace, settings,
            slug=slug, context="bootstrap", provider=provider,
            agent_name=agent_name, team=team,
            skills_root=skills_root, org_root=org_root, db=db,
        )


def _preflight_system_contract_sources(
    contract_ids: set[str],
    src_root: Path,
    *,
    workspace: Path,
    provider: str,
) -> None:
    """Preflight: verify ALL required system-contract source directories exist.

    Called BEFORE any canonical package build or workspace link reconciliation.
    A missing required source must raise BEFORE any store mutation — earlier
    contracts must not be built if a later one is absent.

    Raises:
        SystemContractMaterializationError: one or more required source
            directories are absent, each identified by contract id, source
            path, workspace, and provider.
    """
    missing: list[tuple[str, Path]] = []
    for cid in sorted(contract_ids):
        src_dir = src_root / cid
        if not src_dir.is_dir():
            missing.append((cid, src_dir))
    if missing:
        raise SystemContractMaterializationError(
            missing_contracts=[cid for cid, _ in missing],
            workspace=workspace,
            provider=provider,
        )


def _materialize_context_union(
    workspace: Path,
    settings: Settings,
    *,
    slug: str,
    contexts: list[str],
    provider: str,
    agent_name: str,
    team: str,
    skills_root: Path,
    org_root: Path | None = None,
    db=None,
) -> list[dict]:
    """Core union logic: build expected_specs from all contexts, repair once.

    Preflight: validates every mandatory system-contract source required by
    the full context union BEFORE building any canonical package or
    reconciling either workspace root. A missing required source raises
    SystemContractMaterializationError — never silently continues.

    Returns the exact expected_specs list used for reconciliation so
    callers can pass it to validate_workspace_skills_integrity.
    """
    from runtime.skills.system_contracts import (
        SessionContext,
        resolve_system_contracts_for_session,
    )
    from runtime.skills.registry import SkillRegistry
    from runtime.skills.resolver import EligibilityResolver
    from runtime.skills.exposure import resolve_exposed_skills

    store = CanonicalSkillStore(settings=settings)
    materializer = SymlinkMaterializer(store)
    src_root = _resolve_skills_src(settings)

    # ── 0. PREFLIGHT: collect ALL required system-contract ids ──────
    seen_system_contracts: set[str] = set()
    for ctx_name in contexts:
        try:
            ctx = SessionContext(ctx_name)
        except ValueError:
            continue
        contracts = resolve_system_contracts_for_session(ctx, workspace=workspace)
        for contract in contracts:
            seen_system_contracts.add(contract.id)

    # Validate ALL sources before any build.
    _preflight_system_contract_sources(
        seen_system_contracts, src_root,
        workspace=workspace, provider=provider,
    )

    # ── 1. Union system contracts from ALL contexts ─────────────────
    expected_specs: list[dict] = []

    for cid in sorted(seen_system_contracts):
        src_dir = src_root / cid
        content_hash = _compute_dir_hash(src_dir)
        store.build_from_source(
            cid, "system", content_hash, src_dir,
            verify_source_hash=content_hash,
        )
        expected_specs.append({
            "slug": cid,
            "version": "system",
            "content_hash": content_hash,
        })

    # ── 2. Release-managed catalog skills (once) ───────────────────
    if skills_root.is_dir():
        release_registry = SkillRegistry(skills_root=skills_root)
        release_entries: dict = {}
        for entry in release_registry.list_all():
            release_entries[entry.id] = entry

        if release_entries:
            union_registry = SkillRegistry(skills_root=skills_root)
            for entry in release_entries.values():
                union_registry._entries[entry.id] = entry

            policy: dict = {}
            if org_root is not None:
                config_path = org_root / "org" / "config.yaml"
            else:
                config_path = settings.project_root / "org" / "config.yaml"
            if config_path.is_file():
                import yaml
                try:
                    raw = yaml.safe_load(config_path.read_text(encoding="utf-8"))
                    if isinstance(raw, dict):
                        policy = raw.get("skills", {})
                except (yaml.YAMLError, OSError):
                    pass

            resolver = EligibilityResolver(policy)
            exposed = resolve_exposed_skills(
                union_registry, resolver, org=slug, team=team, agent=agent_name,
            )

            for es in exposed:
                skill_id_slug = es.skill.slug
                if es.skill.source == "user_authored" and org_root is not None:
                    src_dir = org_root / "skills" / skill_id_slug
                else:
                    src_dir = skills_root / skill_id_slug
                if not src_dir.is_dir():
                    continue

                content_hash = _compute_dir_hash(src_dir)
                store.build_from_source(
                    skill_id_slug, es.skill.version or "0", content_hash, src_dir,
                    verify_source_hash=content_hash,
                )
                expected_specs.append({
                    "slug": skill_id_slug,
                    "version": es.skill.version or "0",
                    "content_hash": content_hash,
                })

                if db is not None:
                    db.insert_skill_validation_event(
                        skill_id=es.skill.id,
                        slug=skill_id_slug,
                        agent=agent_name,
                        source="materialization",
                        severity="info",
                        ok=True,
                        version=es.skill.version,
                    )

    # ── 3. B2 custom skills ─────────────────────────────────────────
    if db is not None and org_root is not None:
        custom_specs = _build_custom_skill_canonical_specs(
            store=store, org_root=org_root, db=db, slug=slug,
            agent_name=agent_name, team=team, task_id=None,
            session_id=None, session_context="bootstrap",
        )
        expected_specs.extend(custom_specs)

    return _publish_canonical_specs(
        materializer=materializer, expected_specs=expected_specs,
        workspace=workspace, slug=slug, org_root=org_root, db=db,
    )


def _publish_canonical_specs(
    *, materializer: SymlinkMaterializer, expected_specs: list[dict],
    workspace: Path, slug: str, org_root: Path | None, db,
) -> list[dict]:
    """Authoritatively filter and publish one canonical spec set."""
    # Lock order is workspace transaction -> org publication barrier -> DB
    # reads. Purge takes the same org barrier before its SQLite transaction.
    # Candidate building and session launch stay outside this narrow block;
    # the final authoritative read and both repairs are one lexical unit.
    if db is not None and org_root is not None:
        from runtime.skills.custom import service

        conn = getattr(db, "_conn", db)
        with service.canonical_publication_barrier(slug):
            current_custom = {
                row["slug"]: row
                for row in conn.execute(
                    "SELECT slug, current_version_id, purged_at "
                    "FROM custom_skills WHERE org_slug=?",
                    (slug,),
                ).fetchall()
            }
            expected_specs = [
                spec for spec in expected_specs
                if spec["slug"] not in current_custom
                or (
                    current_custom[spec["slug"]]["purged_at"] is None
                    and str(current_custom[spec["slug"]]["current_version_id"])
                    == str(spec["version"])
                )
            ]
            for subdir in (".claude/skills", ".agents/skills"):
                materializer.repair_workspace_skills(
                    expected_specs, workspace, subdir,
                )
    else:
        for subdir in (".claude/skills", ".agents/skills"):
            materializer.repair_workspace_skills(
                expected_specs, workspace, subdir,
            )
    return expected_specs


def _materialize_unified_canonical(
    workspace: Path,
    settings: Settings,
    *,
    slug: str,
    context: str,
    provider: str,
    agent_name: str,
    team: str,
    skills_root: Path,
    org_root: Path | None = None,
    db=None,
    task_id: str | None = None,
    session_id: str | None = None,
) -> list[dict]:
    """Derive one full expected set per provider root, reconcile once.

    Unified expected set = system contracts (union across ALL ordinary
    session contexts) + release-managed catalog + PUBLISHED/active
    B2 custom skills. This single set is reconciled via
    repair_workspace_skills ONCE.

    System contracts are unioned across all six ordinary SessionContext
    values (task, thread, wake, dream, schedule, bootstrap) so a later
    single-context materialization never withdraws a valid system-contract
    link belonging to another ordinary context. The per-context resolver
    remains authoritative for session guidance; the workspace is an
    intentionally safe superset.

    Returns the exact expected_specs list used for reconciliation so
    callers can pass it to validate_workspace_skills_integrity.

    Fail-closed: any error raises immediately.
    """
    from runtime.skills.system_contracts import (
        SessionContext,
        resolve_system_contracts_for_session,
    )
    from runtime.skills.registry import SkillRegistry
    from runtime.skills.resolver import EligibilityResolver
    from runtime.skills.exposure import resolve_exposed_skills

    store = CanonicalSkillStore(settings=settings)
    materializer = SymlinkMaterializer(store)
    src_root = _resolve_skills_src(settings)
    skills_subdir = ".claude/skills" if provider == "claude" else ".agents/skills"

    # ── 0. PREFLIGHT: union system-contract ids across ALL
    #    ordinary session contexts (task, thread, wake, dream,
    #    schedule, bootstrap).  This prevents cross-context
    #    withdrawal where a later single-context materialization
    #    removes a valid link belonging to another context.
    #    The per-context resolver remains authoritative for
    #    session guidance; the workspace is a safe superset.
    _ORDINARY_CONTEXTS = (
        "task", "thread", "wake", "dream", "schedule", "bootstrap"
    )
    contract_ids: set[str] = set()
    contracts_by_id: dict[str, object] = {}  # SystemContract
    for ctx_name in _ORDINARY_CONTEXTS:
        try:
            ctx = SessionContext(ctx_name)
        except ValueError:
            continue
        for contract in resolve_system_contracts_for_session(ctx, workspace=workspace):
            if contract.id not in contracts_by_id:
                contracts_by_id[contract.id] = contract
            contract_ids.add(contract.id)

    # Validate ALL sources before any build.
    _preflight_system_contract_sources(
        contract_ids, src_root,
        workspace=workspace, provider=provider,
    )

    # ── Build unified expected_specs ────────────────────────────
    expected_specs: list[dict] = []

    # 1. System-contract skills (union across all ordinary contexts)
    for contract_id in sorted(contracts_by_id):
        contract = contracts_by_id[contract_id]
        src_dir = src_root / contract.id
        content_hash = _compute_dir_hash(src_dir)
        store.build_from_source(
            contract.id, "system", content_hash, src_dir,
            verify_source_hash=content_hash,
        )
        # Org context is carried via session/task metadata, not
        # literal {ORG_SLUG} substitution in canonical bytes.
        expected_specs.append({
            "slug": contract.id,
            "version": "system",
            "content_hash": content_hash,
        })

    # 2. Release-managed catalog skills
    if skills_root.is_dir():
        release_registry = SkillRegistry(skills_root=skills_root)
        release_entries: dict = {}
        for entry in release_registry.list_all():
            release_entries[entry.id] = entry

        if release_entries:
            union_registry = SkillRegistry(skills_root=skills_root)
            for entry in release_entries.values():
                union_registry._entries[entry.id] = entry

            policy: dict = {}
            if org_root is not None:
                config_path = org_root / "org" / "config.yaml"
            else:
                config_path = settings.project_root / "org" / "config.yaml"
            if config_path.is_file():
                import yaml
                try:
                    raw = yaml.safe_load(config_path.read_text(encoding="utf-8"))
                    if isinstance(raw, dict):
                        policy = raw.get("skills", {})
                except (yaml.YAMLError, OSError):
                    pass

            resolver = EligibilityResolver(policy)
            exposed = resolve_exposed_skills(
                union_registry, resolver, org=slug, team=team, agent=agent_name,
            )

            for es in exposed:
                skill_id_slug = es.skill.slug
                if es.skill.source == "user_authored" and org_root is not None:
                    src_dir = org_root / "skills" / skill_id_slug
                else:
                    src_dir = skills_root / skill_id_slug
                if not src_dir.is_dir():
                    continue

                content_hash = _compute_dir_hash(src_dir)
                store.build_from_source(
                    skill_id_slug, es.skill.version or "0", content_hash, src_dir,
                    verify_source_hash=content_hash,
                )
                expected_specs.append({
                    "slug": skill_id_slug,
                    "version": es.skill.version or "0",
                    "content_hash": content_hash,
                })

                if db is not None:
                    db.insert_skill_validation_event(
                        skill_id=es.skill.id,
                        slug=skill_id_slug,
                        agent=agent_name,
                        source="materialization",
                        severity="info",
                        ok=True,
                        version=es.skill.version,
                    )

    # 3. B2 custom skills
    if db is not None and org_root is not None:
        custom_specs = _build_custom_skill_canonical_specs(
            store=store, org_root=org_root, db=db, slug=slug,
            agent_name=agent_name, team=team, task_id=task_id,
            session_id=session_id, session_context=context,
        )
        expected_specs.extend(custom_specs)

    return _publish_canonical_specs(
        materializer=materializer, expected_specs=expected_specs,
        workspace=workspace, slug=slug, org_root=org_root, db=db,
    )


def _build_custom_skill_canonical_specs(
    *,
    store: CanonicalSkillStore,
    org_root: Path,
    db,
    slug: str,
    agent_name: str,
    team: str,
    task_id: str | None,
    session_id: str | None,
    session_context: str,
) -> list[dict]:
    """Build visible B2 custom skills through the canonical-store path.

    Each visible skill is independent: an artifact/build fault is persisted as
    a failed materialization for an identified task session and does not block
    system, managed, or sibling custom skills.
    """
    import hashlib
    import tempfile

    from runtime.infrastructure.artifact_store import ArtifactStore
    from runtime.orchestrator._paths import OrgPaths
    from runtime.skills.custom import service
    from runtime.skills.eligibility import (
        EligibilityRecipient,
        EligibilityRule,
        SkillEligibilityState,
        resolve_custom_skill_eligibility,
    )

    conn = getattr(db, "_conn", db)
    rows = conn.execute(
        """SELECT s.id, s.slug, s.retired_at, s.purged_at, v.id AS version_id,
                  v.content_hash, v.content_artifact_key, v.validation_state
           FROM custom_skills s
           JOIN custom_skill_versions v ON v.id = s.current_version_id
           WHERE s.org_slug = ?""",
        (slug,),
    ).fetchall()
    artifact_store = ArtifactStore(OrgPaths(org_root).artifacts_dir)
    recipient = EligibilityRecipient(agent_name, (team,))
    specs: list[dict] = []
    recordable = (
        session_id is not None
        and session_context in {"task", "thread", "wake", "dream"}
        and (session_context != "task" or task_id is not None)
    )

    for row in rows:
        rules = conn.execute(
            """SELECT scope_type, scope_target, effect
               FROM custom_skill_eligibility_rules
               WHERE skill_id = ? AND superseded_at IS NULL""",
            (row["id"],),
        ).fetchall()
        decision = resolve_custom_skill_eligibility(
            SkillEligibilityState(
                bool(row["retired_at"]), row["validation_state"], bool(row["purged_at"])
            ),
            [EligibilityRule(**dict(rule)) for rule in rules],
            recipient,
        )
        if not decision.visible:
            continue

        try:
            artifact_key = row["content_artifact_key"]
            if not artifact_key:
                raise ValueError("No content_artifact_key")
            content = artifact_store.read(artifact_key)
            actual_hash = hashlib.sha256(content).hexdigest()
            if actual_hash != row["content_hash"]:
                raise ValueError(
                    "Artifact hash mismatch: expected "
                    f"{row['content_hash'][:16]}..., got {actual_hash[:16]}..."
                )
            with tempfile.TemporaryDirectory() as temporary_dir:
                source_dir = Path(temporary_dir)
                (source_dir / "SKILL.md").write_bytes(content)
                tree_hash = _compute_dir_hash(source_dir)
                store.build_from_source(
                    row["slug"], str(row["version_id"]), row["content_hash"],
                    source_dir, verify_source_hash=tree_hash,
                )
            # Selection and package construction may be expensive. Re-read the
            # authoritative row at the publication seam so a purge committed
            # during that window cannot publish a stale canonical spec or a
            # new link in either provider root. Existing canonical bytes are
            # retained by the logical-purge contract.
            current = conn.execute(
                "SELECT current_version_id, purged_at FROM custom_skills "
                "WHERE id=? AND org_slug=?",
                (row["id"], slug),
            ).fetchone()
            if (
                current is None
                or current["purged_at"] is not None
                or current["current_version_id"] != row["version_id"]
            ):
                continue
            specs.append({
                "slug": row["slug"],
                "version": str(row["version_id"]),
                "content_hash": row["content_hash"],
                "tree_hash": tree_hash,
            })
            if recordable:
                service.record_materialization(
                    conn, skill_id=row["id"], agent_name=agent_name,
                    task_id=task_id, session_context=session_context,
                    session_id=session_id, version_id=row["version_id"],
                    content_hash=row["content_hash"], success=True,
                )
                conn.commit()
        except Exception as exc:
            if recordable:
                service.record_materialization(
                    conn, skill_id=row["id"], agent_name=agent_name,
                    task_id=task_id, session_context=session_context,
                    session_id=session_id, version_id=row["version_id"],
                    content_hash=row["content_hash"], success=False,
                    error_message=str(exc),
                )
                conn.commit()

    return specs


def _compute_dir_hash(src_dir: Path) -> str:
    """Compute a deterministic SHA-256 for a source tree."""
    import hashlib

    digest = hashlib.sha256()
    for path in sorted(src_dir.rglob("*")):
        if path.is_file():
            digest.update(str(path.relative_to(src_dir)).encode())
            digest.update(b"\x00")
            digest.update(path.read_bytes())
            digest.update(b"\x00")
    return digest.hexdigest()


# ── Pre-launch integrity validation ────────────────────────────────
# Before every executor launch, validate that workspace skill links
# resolve to the expected canonical packages and that canonical package
# integrity (tree hashes and B2 custom-skill artifact hashes) is
# intact. The executor and daemon share the same OS identity — a
# same-UID process can mutate canonical targets between checks.
# Detection-only: no automatic repair from same-UID local sources.
# Recovery: FIRST manual authoritative external re-sync/redeploy
# of release/custom artifacts; ONLY THEN:
# (a) for link-only faults — `happyranch set-executor <agent>
#     --executor <current-executor>` (non-destructive re-materialize);
# (b) for corrupted canonical bytes — `happyranch skills recover
#     <slug> <version> <content_hash>` then restart the daemon.
# Local same-UID sources are not automatically repaired or trusted.


class WorkspaceIntegrityError(Exception):
    """Raised when workspace skill integrity validation fails.

    Terminal — no executor launch proceeds. Recovery: FIRST manual
    authoritative external re-sync/redeploy of release/custom
    artifacts; ONLY THEN existing verified link repair / skills
    recover / restart as applicable. Local same-UID sources are not
    automatically repaired or trusted.
    """

    def __init__(
        self,
        code: str,
        detail: str,
        findings: list[str] | None = None,
        recovery_command: str | None = None,
    ) -> None:
        self.code = code
        self.detail = detail
        self.findings = findings or []
        self.recovery_command = recovery_command
        msg = f"[{code}] {detail}"
        if self.recovery_command:
            msg += f"\nRecovery: {self.recovery_command}"
        if self.findings:
            msg += f"\nFindings: {', '.join(self.findings)}"
        super().__init__(msg)


def validate_workspace_skills_integrity(
    workspace: Path,
    expected_specs: list[dict],
    *,
    settings: "Settings | None" = None,  # noqa: F821
    db: "Database | None" = None,  # noqa: F821
    agent_name: str | None = None,
    task_id: str | None = None,
) -> None:
    """Validate workspace skill links and canonical package integrity.

    For EVERY expected spec, validates:
    - The canonical package exists and is non-empty
    - The canonical tree hash matches the expected value computed from
      B2-declared member hashes or the source tree hash
      (system contracts)
    - Workspace symlinks at BOTH ``.claude/skills`` and ``.agents/skills``
      point to the correct canonical target
    - No ordinary directories at expected symlink positions (hostile state)
    - No unexpected entries in either skills root

    On ANY mismatch: emits a durable ``skill_validation_events`` row with
    ``severity="error"``, ``source="integrity_check"``, ``ok=False``, then
    raises ``WorkspaceIntegrityError``. If the audit write itself fails,
    also raises (fail-closed — no launch proceeds unrecorded).

    This is a DETECTIVE control, not a preventive security boundary.
    The executor and daemon share the same OS identity, so an
    agent-controlled executor can mutate canonical targets through
    workspace links between checks. The integrity check detects
    tampering at the next launch attempt and refuses the session.
    Recovery: FIRST manual authoritative external re-sync/redeploy
    of release/custom artifacts; ONLY THEN (a) for link-only faults
    — `happyranch set-executor <agent> --executor <current-executor>`
    (never repairs bytes); (b) for corrupted canonical bytes —
    `happyranch skills recover <slug> <version> <content_hash>`
    then restart daemon. Local same-UID sources are not automatically
    repaired or trusted.

    Args:
        workspace: Agent workspace root
        expected_specs: List of {slug, version, content_hash, tree_hash}
            dicts from materialization. Must be the SAME list that was
            used to materialize — never a separately-derived list that
            can drift.
        settings: Project Settings (for canonical store construction)
        db: Database handle for persisting audit events
        agent_name: Agent name for audit attribution
        task_id: Task ID for audit attribution

    Raises:
        WorkspaceIntegrityError: On any mismatch, missing package, broken
            link, ordinary directory, unexpected entry, or audit-write failure.
    """
    from runtime.skills.canonical_store import CanonicalSkillStore, CanonicalStoreError
    from runtime.platform.isolation import (
        detect_platform_isolation,
        PlatformIsolationError,
    )

    isolation = detect_platform_isolation()
    store = CanonicalSkillStore(
        settings=settings,
        isolation=isolation,
    )

    # No specs → nothing to validate (e.g., agent with no skills).
    if not expected_specs:
        return

    findings: list[str] = []
    skill_roots = [".claude/skills", ".agents/skills"]
    expected_slugs = {spec["slug"] for spec in expected_specs}

    # ── Validate each expected spec ────────────────────────────
    for spec in expected_specs:
        slug = spec["slug"]
        version = spec["version"]
        content_hash = spec["content_hash"]

        # 1. Verify canonical package exists and is non-empty.
        try:
            store.verify_package(slug, version, content_hash)
        except CanonicalStoreError as exc:
            findings.append(
                f"Canonical package missing/empty for {slug}@{version}: {exc}"
            )
            continue

        # 1b. Verify package tree hash matches the expected value.
        #     The executor shares the daemon's OS identity and can
        #     chmod+mutate+restore canonical targets, so we validate
        #     actual content integrity via tree hash.
        expected_tree_hash = spec.get("tree_hash", content_hash)
        actual_tree_hash = store.compute_tree_hash(slug, version, content_hash)
        if actual_tree_hash != expected_tree_hash:
            findings.append(
                f"Package tree hash mismatch for {slug}@{version}: "
                f"expected {expected_tree_hash[:16]}..., "
                f"got {actual_tree_hash[:16]}..."
            )
            continue

        canonical_target = store.canonical_path(slug, version, content_hash)

        # 2. Verify workspace symlinks in BOTH roots
        for subdir in skill_roots:
            link_path = workspace / subdir / slug
            if not link_path.exists(follow_symlinks=False):
                findings.append(
                    f"Missing workspace link: {link_path} "
                    f"(expected → {canonical_target})"
                )
                continue

            if not link_path.is_symlink():
                if link_path.is_dir():
                    findings.append(
                        f"Ordinary directory at symlink position: {link_path} "
                        f"(expected symlink → {canonical_target}). "
                        f"This is a potentially hostile state — refused."
                    )
                else:
                    findings.append(
                        f"Non-symlink at link position: {link_path} "
                        f"(expected symlink → {canonical_target})"
                    )
                continue

            if not isolation.verify_workspace_link(
                link_path, canonical_target, store.root,
            ):
                try:
                    actual_target = os.readlink(str(link_path))
                except OSError:
                    actual_target = "<unreadable>"
                findings.append(
                    f"Wrong/mismatched workspace link: {link_path} → "
                    f"{actual_target} (expected → {canonical_target})"
                )

    # ── Check for unexpected entries in workspace skill dirs ──
    for subdir in skill_roots:
        skills_dir = workspace / subdir
        if not skills_dir.is_dir():
            continue
        for entry in sorted(skills_dir.iterdir()):
            if entry.name.startswith(".tmp."):
                continue
            if entry.name not in expected_slugs:
                if entry.is_symlink():
                    findings.append(
                        f"Unexpected symlink in {subdir}: {entry.name} "
                        f"→ {os.readlink(str(entry))}. "
                        f"Not in expected skill set."
                    )
                elif entry.is_dir():
                    findings.append(
                        f"Unexpected ordinary directory in {subdir}: {entry.name}"
                    )
                else:
                    findings.append(
                        f"Unexpected entry in {subdir}: {entry.name}"
                    )

    # ── If no findings, validation passed ─────────────────────
    if not findings:
        logger.debug(
            "Workspace skills integrity validation passed for %s "
            "(%d expected specs, agent=%s)",
            workspace, len(expected_specs), agent_name or "?",
        )
        return

    # ── Emit durable audit event(s) ────────────────────────────
    audit_failed = False
    if db is not None:
        for finding in findings:
            try:
                db.insert_skill_validation_event(
                    skill_id="hr:workspace-integrity",
                    slug="workspace-integrity",
                    agent=agent_name,
                    source="integrity_check",
                    severity="error",
                    ok=False,
                    version=None,
                    findings=[finding],
                    reason_codes=["integrity_mismatch"],
                )
            except Exception as exc:
                logger.error(
                    "Failed to persist integrity violation audit event: %s",
                    exc,
                )
                audit_failed = True
                findings.append(
                    f"Audit persistence failure: {exc}. "
                    f"Launch refused per fail-closed policy."
                )
                break

    # ── Fail closed ────────────────────────────────────────────
    # Recovery guidance:
    # - Broken/missing/wrong workspace links → re-materialize via
    #   executor switch (happyranch set-executor) which rebuilds links
    #   from the canonical store (links ONLY — does NOT recover
    #   corrupted canonical bytes).
    # - Corrupted canonical bytes (hash mismatch, tampered content) →
    #   set-executor CANNOT recover bytes — it only repairs links.
    #   Recovery is manual, operator-invoked: `happyranch skills
    #   recover <slug> <version> <content_hash>`. Validates B2 provenance
    #   provenance and member hashes before deletion; refuses already-
    #   valid targets. Next materialization rebuilds from ArtifactStore.
    #   There is NO automatic same-UID local source repair and
    #   NO automatic recovery from any local same-UID source.
    recovery = (
        "FIRST manual authoritative external re-sync/redeploy "
        "of release/custom artifacts; ONLY THEN: "
        "for link-only faults — happyranch set-executor <agent> "
        "--executor <current-executor> (non-destructive re-materialize); "
        "for corrupted canonical bytes — happyranch skills recover "
        "<slug> <version> <content_hash> then restart daemon. "
        "Local same-UID sources are not automatically repaired or trusted."
    )

    raise WorkspaceIntegrityError(
        code="integrity_mismatch" if not audit_failed else "audit_write_failed",
        detail=(
            f"Workspace skills integrity validation failed for {workspace} "
            f"(agent={agent_name or '?'}, "
            f"expected_specs={len(expected_specs)}, "
            f"findings={len(findings)})."
        ),
        findings=findings,
        recovery_command=recovery,
    )


def inject_system_contracts(
    workspace: Path,
    settings: Settings,
    *,
    slug: str,
    context: str,
) -> None:
    """CUTOVER: Forwards to materialize_workspace_skills for compatibility.

    This wrapper exists only for test compat during the cutover window.
    Production callers must use materialize_workspace_skills directly.
    """
    # Derive minimal parameters for the unified call
    skills_root = settings.project_root / "runtime" / "skills"
    materialize_workspace_skills(
        workspace, settings,
        slug=slug,
        context=context,
        provider="claude",
        agent_name="test",
        team="engineering",
        skills_root=skills_root,
    )


def inject_managed_skills(
    workspace: Path,
    settings: Settings,
    *,
    slug: str,
    agent_name: str,
    team: str,
    skills_root: Path,
    org_root: Path | None = None,
    db: "Database | None" = None,  # noqa: F821
) -> None:
    """CUTOVER: Forwards to canonical store for compatibility.

    Managed-catalog and B2 custom skills are now resolved via
    materialize_workspace_skills / _materialize_unified_canonical.
    """
    materialize_workspace_skills(
        workspace, settings,
        slug=slug,
        context="task",
        provider="claude",
        agent_name=agent_name,
        team=team,
        skills_root=skills_root,
        org_root=org_root,
        db=db,
    )


def _memory_bootstrap_section(workspace: Path) -> list[str]:
    """Returns the 'Persistent Files' + 'Your Memory' block.

    Branches on workspace state: legacy flat learnings.md vs migrated memory/.
    """
    flat = workspace / "learnings.md"
    memory_dir = workspace / "memory"
    index = memory_dir / "_index.md"

    if memory_dir.exists() and index.exists():
        index_body = index.read_text()
        return [
            "## Persistent Files\n",
            "- `memory/_index.md` -- index of your operational memory",
            "  (full bodies via `happyranch memory get`)",
            "- `task_history.md` -- read-only, updated by orchestrator\n",
            "## Your Memory\n",
            index_body,
            "\nFetch any entry's body:",
            "```",
            "happyranch memory get --org <slug> --agent <you> <MEM-NNN-or-slug>",
            "```",
            "Write a new memory item (file payload with slug/title/topic/tags/body):",
            "```",
            "happyranch memory add --org <slug> --agent <you> --from-file <path>",
            "```",
            "Update an existing memory item:",
            "```",
            "happyranch memory update --org <slug> --agent <you> <MEM-NNN> --from-file <path>",
            "```",
            "Promote a durable cross-agent rule to the shared KB (one-way):",
            "```",
            "happyranch memory promote --org <slug> --agent <you> <MEM-NNN> --kb-slug <slug>",
            "```\n",
            "_Old `LRN-` ids and `happyranch learning …` still resolve "
            "(`learning` is a deprecated alias of `memory`)._\n",
        ]
    if flat.exists():
        flat_body = flat.read_text()
        return [
            "## Persistent Files\n",
            "- `learnings.md` -- your accumulated operational memory (legacy flat-file format)",
            "- `task_history.md` -- read-only, updated by orchestrator\n",
            "## Your Memory\n",
            flat_body + "\n",
            "Append a new line via `happyranch memory --agent <you> --text \"...\"`.",
            "_The structured per-entry format is available once this workspace is migrated._\n",
        ]
    # Brand-new workspace, ensure() should have created memory/ already.
    return [
        "## Persistent Files\n",
        "- `memory/_index.md` -- index of your operational memory (empty)",
        "- `task_history.md` -- read-only, updated by orchestrator\n",
    ]


def _shared_artifacts_section() -> list[str]:
    return [
        "## Shared Artifacts (org-wide)\n",
        "Path: `<runtime>/orgs/<slug>/artifacts/`. Drop persistent files your work",
        "produces — generated reports, exports, screenshots, PDFs, images. Files",
        "here survive across tasks and are visible to every agent in this org.\n",
        "Use cases: a generated PDF report another agent needs to attach to a",
        "customer reply; a CSV export the founder will want to review; a screenshot",
        "captured during QA that the bug-triage agent should see.\n",
        "**Not** the KB. KB is for durable cross-agent *knowledge* (rules,",
        "references, founder rulings). Artifacts are for *files and binary blobs*.",
        "Don't put scratch work here — use your workspace `repos/`, learning",
        "entries, or task output for transient state.\n",
        "All access is via `happyranch`. Direct filesystem reads/writes won't work",
        "uniformly across executors — use the CLI:\n",
        "```",
        "happyranch artifacts put <local-path> --agent <you> [--name <name>]",
        "happyranch artifacts list",
        "happyranch artifacts get <name> --output <local-path>",
        "```\n",
        "Naming convention: prefix with your agent name + ISO date for",
        "traceability, e.g. `dev_agent-YYYY-MM-DD-perf-report.pdf`. Names may",
        "use '/' as a path separator for logical folders. Each segment must",
        "match `[A-Za-z0-9._-]+`; max 200 chars total. Per-file size cap: 10 MB.\n",
    ]


def _thread_talk_dispatch_doctrine_section() -> list[str]:
    """System-injected doctrine: dispatch from a thread is self-only.

    Surfaces the structural rule enforced at `/threads/{id}/dispatch`
    so every agent reads it at bootstrap rather than discovering it via a
    403 response. The rule itself is mechanical (route rejects
    `effective_target != dispatcher` with `thread_dispatch_must_be_self`);
    this section is the *why* and the recommended pattern. Spec:
    `docs/superpowers/specs/2026-05-28-thread-talk-self-dispatch-only-design.md`.

    Keep the prose tight — every agent in every org reads this on every
    session. If this grows past ~25 lines it has become docs, not a prompt.
    """
    return [
        "## Thread Dispatch is Self-Only\n",
        "When you are inside a **thread invocation** (reply / bootstrap), the",
        "runtime only lets you dispatch tasks to **yourself**. Any attempt to",
        "target another agent returns 403 with `thread_dispatch_must_be_self`.\n",
        "This is the doctrine the rule encodes:",
        "- **Threads** exist for founder-visible coordination and cross-team",
        "  handoffs. They are messaging surfaces.",
        "- **Task trees** exist for iterative work. Managers drive sub-tasks",
        "  through the manager-decision loop; workers do bounded work and",
        "  report back. They are execution surfaces.\n",
        "When you need to do task-shaped work from inside a thread:",
        "- **Self-dispatch a root task.** Omit `target_agent` (or set it to",
        "  your own name). If you are a manager and the work has multiple",
        "  steps, the manager-decision loop handles internal sub-task",
        "  spawning on its own. The thread sees a single `task_completed`",
        "  system message at the end and a single TASK_FOLLOWUP turn where",
        "  you report back.",
        "- **Do not** thread-dispatch another agent. Instead, open or extend",
        "  a thread with `happyranch threads compose --to <other-agent>` and",
        "  let them decide whether to take the work on. Cross-team handoffs",
        "  always route through compose, not dispatch.\n",
        "If you find yourself wanting to dispatch a SECOND task from the same",
        "thread, that is the signal that you should have dispatched a single",
        "self-managed root the first time.\n",
    ]


def _skills_directory_readonly_section(skills_dir: str, agent_name: str) -> list[str]:
    """System-injected operational guidance: do not edit managed skill links.

    Skill entries under BOTH ``.claude/skills`` and ``.agents/skills`` are
    daemon-materialized from the canonical skill store. This section
    directs agents NOT to edit these managed links and to use the B2
    custom-skill workflow instead.

    **IMPORTANT:** This is operational guidance, NOT enforcement. The
    executor and daemon share the same OS identity — there is NO OS-level
    security boundary. Integrity validation detects a mismatch, records a
    durable visible integrity/operations event, and refuses launch; there
    is NO local automatic recovery/autoheal. Recovery requires FIRST
    manual authoritative external re-sync/redeploy of release/custom
    artifacts; ONLY THEN existing verified link repair / skills recover /
    restart as applicable. Local same-UID sources are not automatically
    repaired or trusted. Do NOT call the target immutable, protected, or
    claim write/chmod/ACL denial, OS-enforced isolation, or automatic
    same-UID repair.
    """
    lines = [
        "## Skills Directory (do not edit)\n",
        "`.claude/skills/` and `.agents/skills/` are materialized by the ",
        "daemon from the canonical skill store under BOTH managed roots. ",
        "DO NOT author, edit, move, or delete anything under either ",
        "directory, even if a task seems to call for it. Treat them as ",
        "read-only.\n",
        "The executor and daemon share the same OS identity — the ",
        "filesystem CAN be written through these symlinks; there is no ",
        "OS-enforced security boundary. Integrity validation detects a ",
        "mismatch, records a durable visible integrity/operations event, ",
        "and refuses launch — there is NO local automatic ",
        "recovery/autoheal. Recovery requires FIRST manual authoritative ",
        "external re-sync/redeploy of release/custom ",
        "artifacts; ONLY THEN existing verified link repair / ",
        "skills recover / restart as applicable. Local same-UID "
        "sources are not automatically repaired or trusted. Do not "
        "rely on this as a security control or treat it as "
        "OS-enforced protection.\n",
    ]
    lines.extend([
        "If a new custom skill is needed, every verified agent can use the B2 ",
        "create-skill workflow directly; there is no pilot roster or slug restriction. ",
        "It remains bound to this session. The response includes the editable custom ",
        "skill, immutable version, default-hidden reason, and verified agent/task/session ",
        "provenance:\n",
        "```",
        "happyranch skills create --from-file <path> --session-id <your-session-id>",
        "```\n",
    ])
    return lines


def _non_stop_command_warning_section() -> list[str]:
    """Persistent warning: never run a non-returning command synchronously.

    A `bash` tool call that doesn't return blocks the session until the
    executor's wall-clock timeout fires (default 1800s). The orchestrator
    marks the task terminal FAILED under normal failure handling — no
    automatic successor is spawned and no retries are attempted. The
    session completes no useful work in the meantime and consumes one
    session budget.

    Recovery requires explicit manager or founder action (``happyranch
    revisit`` or a manager re-delegation).

    The remedy is the `jobs` skill: the daemon spawns the subprocess
    out-of-process, the agent's session continues, and the agent polls
    `happyranch jobs tail|wait|stop` for status.
    """
    return [
        "## Long-running and non-stop commands\n",
        "**Never** run a command synchronously via `bash` if it doesn't return on its",
        "own. Examples that will block your session until the wall-clock timeout",
        "kills it. The task is marked terminal FAILED under normal failure",
        "handling — no automatic retries or successor tasks are spawned. The",
        "session completes no useful work and consumes one budget.\n",
        "- Dev servers: `npm run dev`, `python -m http.server`, `cargo watch`",
        "- Log/file watchers: `tail -f`, `fswatch`, `entr`",
        "- Polling loops: `while true; do …; sleep N; done`",
        "- Long builds you don't need to wait on: full-image Docker builds, large",
        "  cross-compile runs, multi-hour migrations",
        "- Anything that needs founder credentials your `allow_rules` block",
        "  (`aws`, `stripe`, `ssh`, `sudo`, blocked `gh` verbs)\n",
        "Submit a **job** instead — the daemon runs the subprocess, your session",
        "continues, and you check on it with `happyranch jobs tail|wait|stop` when",
        "ready. See the **jobs** skill (available",
        "to you under your workspace's skills directory) for the form fields, the",
        "two policy flags (`review_required`, `persistent`), and how to self-block",
        "when founder review is required.\n",
        "If you're uncertain whether a command will return, submit it as a job",
        "with `persistent: true` — cheaper to be wrong than to lose a session.\n",
    ]


# H2 headers that the system emits into every assembled bootstrap doc.
# An agent's ``.md`` body must NOT use any of these as a section header,
# because the assembled prompt would then carry two sections with the
# same heading (the agent body's section above the agent-body cutline, and
# the system-injected section below). Confusing for the agent, and a
# maintenance hazard: each agent file becomes a place where system content
# can quietly drift.
#
# Keep this set synchronized with the ``## <Header>`` lines emitted by
# ``_build_sections`` and the ``_*_section`` helpers above.
_RESERVED_AGENT_BODY_HEADERS: frozenset[str] = frozenset({
    "Available Repositories",
    "Persistent Files",
    "Your Learnings",
    "Knowledge Base (shared across agents)",
    "Shared Artifacts (org-wide)",
    "Thread Dispatch is Self-Only",
    "Skills Directory (do not edit)",
    "Long-running and non-stop commands",
    "Task Completion Format",
    "Task Recall",
    "Workflow",
    "[RESERVED] Active Team Escalation Policy",
})


class ReservedHeaderInAgentBody(ValueError):
    """Raised when an agent's ``.md`` body uses a reserved H2 header that
    collides with a system-injected section in the assembled bootstrap doc.
    """


def _assert_no_reserved_headers_in_body(agent_name: str, body: str) -> None:
    """Block the bootstrap-doc write if the agent body collides with a
    system-injected H2 header.

    Boundary contract: the agent ``.md`` file owns who-the-agent-is content
    (role, authority, escalation, accountability). The system owns
    how-to-interact-with-the-orchestrator content (the headers in
    ``_RESERVED_AGENT_BODY_HEADERS`` above). If an agent file authors one of
    the reserved headers, the assembled CLAUDE.md / AGENTS.md will carry
    two sections with the same name and the system's section becomes
    duplicated, contradicted, or drifted.

    Surfaced at write time so the founder sees the violation BEFORE a
    session spawns against a broken assembled doc. Only the offending
    agent's workspace setup fails; the rest of the org keeps running.
    """
    offenders: list[str] = []
    for line in body.splitlines():
        if line.startswith("## "):
            heading = line[3:].strip()
            if heading in _RESERVED_AGENT_BODY_HEADERS:
                offenders.append(heading)
    if offenders:
        offenders_list = ", ".join(repr(h) for h in offenders)
        raise ReservedHeaderInAgentBody(
            f"agent {agent_name!r}: the agent .md body uses H2 header(s) "
            f"{offenders_list}, which the system also emits into the "
            f"assembled bootstrap doc. Rename or remove these headers in "
            f"the agent file. Reserved headers are owned by the system "
            f"(see _RESERVED_AGENT_BODY_HEADERS in workspace_adapters.py)."
        )
    try:
        from runtime.orchestrator.active_authority_policy import assert_no_reserved_team_policy_header
        assert_no_reserved_team_policy_header(body, source=f"agent body {agent_name}")
    except Exception as exc:
        from runtime.orchestrator.active_authority_policy import ActiveAuthorityPolicyError
        if isinstance(exc, ActiveAuthorityPolicyError):
            raise ReservedHeaderInAgentBody(str(exc)) from exc
        raise


def _task_completion_format_section() -> list[str]:
    """System-injected reminder of the completion contract.

    Replaces the per-agent ``## Task Completion Format`` stubs that lived in
    agent ``.md`` files. Request models and transition handlers own the
    completion contract. The ``start-task`` skill's *Report completion* step
    explains the payload, including the owner-only ``decision`` block.
    This section points at that skill and lists the prose-``summary`` items
    that apply regardless of role, so individual agent files don't have to
    restate (and slowly drift from) the contract.
    """
    return [
        "## Task Completion Format\n",
        "Every task ends with a `happyranch report-completion --from-file <path>`",
        "callback driven by the **start-task** skill. The skill's *Report",
        "completion* step carries the canonical JSON payload shape — fields,",
        "the manager-only `decision` block, and the blocked-path variant.",
        "Do **not** restate it here; consult the skill.\n",
        "In the prose `summary` field, include:",
        "- What was done — or, for a blocker, what is in the way.",
        "- Findings, risks, or concerns the founder or a downstream reviewer",
        "  should know about.",
        "- Items that need founder decision (call them out explicitly).",
        "- Follow-up work the next task should pick up.\n",
        "Role-specific items your output should mention (artifact paths, PR",
        "numbers, verdicts, tokens added, etc.) come from your role — name",
        "them concretely; do not leave the reader to infer.\n",
    ]


def _format_allow_rule(prefix: str, *, cli: bool) -> str:
    """Render a Bash prefix in one of the two equivalent permission syntaxes.

    Settings.json uses ``Bash(<cmd>:*)``; the ``--allowedTools`` CLI flag uses
    ``Bash(<cmd> *)``. Both prefix-match the same invocations in Claude Code,
    but the project has historically used different separators in the two
    surfaces and we preserve that to minimize diff noise against prior tests
    and released workspaces.
    """
    sep = " " if cli else ":"
    return f"Bash({prefix}{sep}*)"


def allow_rules_for_agent(
    paths: "OrgPaths", agent_name: str | None, *, cli: bool,
) -> list[str]:
    """Build the Bash allow-rule list for ``agent_name``.

    Baseline ``happyranch`` is always included (the agent-callback channel).
    Additional prefixes come from the agent's ``allow_rules`` frontmatter
    field in ``<runtime>/org/agents/<name>.md``.
    """
    from runtime.orchestrator import prompt_loader
    rules = [_format_allow_rule("happyranch", cli=cli)]
    if agent_name is None:
        return rules
    for prefix in prompt_loader.allow_rules_for_agent(paths, agent_name):
        rules.append(_format_allow_rule(prefix, cli=cli))
    return rules


def bash_allow_prefixes_for_agent(
    paths: "OrgPaths", agent_name: str | None,
) -> list[str]:
    """Return raw Bash allow-rule prefixes (no syntax wrapping).

    Used by ``OpencodeWorkspaceAdapter`` to build ``opencode.json``, where
    each prefix is rendered as ``"<prefix> *": "allow"`` rather than
    ``Bash(<prefix>:*)`` (settings.json) or ``Bash(<prefix> *)``
    (Claude ``--allowedTools``). Source of truth (the per-agent
    ``allow_rules`` frontmatter) is the same; only the rendering differs.
    """
    from runtime.orchestrator import prompt_loader
    prefixes = ["happyranch"]
    if agent_name is None:
        return prefixes
    for prefix in prompt_loader.allow_rules_for_agent(paths, agent_name):
        prefixes.append(prefix)
    return prefixes


def build_settings_json(
    paths: "OrgPaths",
    repo_names: list[str],
    agent_name: str | None = None,
) -> dict:
    """Build .claude/settings.json for a workspace.

    ``repo_names`` is accepted for signature stability but no longer feeds a
    PreToolUse pull hook — repo freshness moved daemon-side (THR-103): the
    orchestrator fast-forward-pulls every cloned repo at session spawn via
    ``refresh_workspace_repos``, uniformly for all executors.
    """
    return {
        "permissions": {
            "allow": allow_rules_for_agent(paths, agent_name, cli=False),
        },
        "hooks": {},
    }


@dataclass(slots=True)
class PersistentWorkspaceSetup:
    """Shared workspace files that every provider keeps up to date."""

    settings: Settings

    def ensure(self, workspace: Path, agent_name: str) -> list[str]:
        """Create persistent files and return detected cloned repo names."""
        workspace.mkdir(parents=True, exist_ok=True)

        # Migrate legacy recent_tasks.md → task_history.md in place so no
        # history is lost on workspaces created before the rename.
        legacy = workspace / "recent_tasks.md"
        renamed = workspace / "task_history.md"
        if legacy.exists() and not renamed.exists():
            legacy.rename(renamed)

        # task_history.md: always ensure
        history_path = workspace / "task_history.md"
        if not history_path.exists():
            history_path.write_text(f"# Task History: {agent_name}\n\n")

        # memory: state-aware, idempotent, lazy learnings/ -> memory/ migration
        # (THR-032 Phase R) + _index.md safety. Lazy imports avoid a hard infra
        # dep at module top.
        from runtime.infrastructure.learnings_store import MemoryStore
        from runtime.infrastructure.memory_migration import migrate_workspace

        # Idempotent + lossless: moves a legacy learnings/ dir to memory/ if
        # present, no-op once memory/ exists, leaves flat learnings.md alone.
        migrate_workspace(workspace)

        flat_path = workspace / "learnings.md"
        memory_dir = workspace / "memory"
        if memory_dir.exists():
            # Migrated or natively-new layout: idempotently ensure _index.md.
            store = MemoryStore(memory_dir)
            if not (memory_dir / "_index.md").exists():
                store.regenerate_index()
        elif flat_path.exists():
            # Pre-migration legacy flat-file workspace: leave untouched.
            pass
        else:
            # Brand-new workspace: create memory/ on the new layout.
            memory_dir.mkdir(parents=True, exist_ok=True)
            MemoryStore(memory_dir).regenerate_index()

        return self.detect_repo_names(workspace)

    @staticmethod
    def detect_repo_names(workspace: Path) -> list[str]:
        repos_dir = workspace / "repos"
        if not repos_dir.exists():
            return []
        return sorted(
            d.name for d in repos_dir.iterdir()
            if d.is_dir() and (d / ".git").exists()
        )


def refresh_workspace_repos(workspace: Path) -> dict[str, bool]:
    """Fast-forward-refresh every cloned repo under ``workspace/repos/``.

    Called by the orchestrator on EVERY session spawn, before the executor
    subprocess starts, so all executors (claude, codex, opencode, pi) get
    fresh repo state (THR-103). This replaces the Claude-only PreToolUse
    settings hook that previously ran the same pull.

    Failure semantics: NEVER raises and never blocks a spawn. Offline,
    dirty-tree, non-fast-forward, or conflicted pulls exit non-zero, which
    ``subprocess.run`` without ``check=True`` does not raise for — the
    returncode is recorded in the returned mapping. Hung fetches are bounded
    by a per-repo 30s timeout; one repo's failure does not stop its siblings.

    Only already-cloned repos are refreshed (``detect_repo_names`` filters to
    dirs with a ``.git``); first-time cloning stays in the bootstrap path
    (``context_builder.clone_repo``). The returned mapping records whether
    each detected repo fast-forwarded cleanly; scan failures return an empty
    mapping.
    """
    try:
        repo_names = PersistentWorkspaceSetup.detect_repo_names(workspace)
    except OSError as exc:
        logger.debug("repo refresh: could not scan %s: %s", workspace, exc)
        return {}
    results: dict[str, bool] = {}
    for name in repo_names:
        repo_dir = workspace / "repos" / name
        try:
            result = subprocess.run(
                ["git", "pull", "--ff-only"],
                cwd=str(repo_dir),
                capture_output=True,
                timeout=30,
            )
            results[name] = result.returncode == 0
        except (subprocess.TimeoutExpired, subprocess.SubprocessError, OSError) as exc:
            logger.info("repo refresh: git pull skipped for %s: %s", repo_dir, exc)
            results[name] = False
    return results


def format_repo_refresh_note(results: dict[str, bool]) -> str:
    """Render the session-visible status for a fail-open repo refresh."""
    if not results:
        return "Repository freshness at session start: no cloned repositories were refreshed."
    stale_repos = sorted(name for name, fresh in results.items() if not fresh)
    if stale_repos:
        return (
            "Repository freshness at session start: "
            f"{', '.join(stale_repos)} did not fast-forward cleanly; their code may be stale."
        )
    return "Repository freshness at session start: all cloned repositories fast-forwarded cleanly."


# ── Canonical instruction pair (THR-262 Slice B / founder seq59) ──────
# Every generated agent and system-assistant workspace converges
# non-destructively on one regular ``AGENTS.md`` plus a raw relative
# ``CLAUDE.md -> AGENTS.md`` symlink. This module owns the shared
# classifier/writer used by the built-in workspace adapters and the
# read-only startup readiness gate. It never writes through a symlink and
# never mutates an external target.

CANONICAL_AGENTS_NAME = "AGENTS.md"
CANONICAL_CLAUDE_NAME = "CLAUDE.md"
CANONICAL_CLAUDE_LINK_TARGET = "AGENTS.md"


class InstructionPairOperation(StrEnum):
    """Closed caller-visible classifications for canonical-pair failures."""

    INPUT_INSPECTION = "input inspection failed"
    PRESERVATION_COPY = "preservation copy failed"
    CANONICAL_WRITE = "canonical write failed"
    LINK_CREATION = "link creation failed"


class InstructionPairCompensationOperation(StrEnum):
    """Closed caller-visible classifications for pair compensation failures."""

    RESTORE_PATH = "Failed to restore instruction path"


@dataclass(frozen=True)
class InstructionPairCompensationFailure:
    """Structured pair rollback failure with raw detail reserved for logs."""

    operation: InstructionPairCompensationOperation
    owned_relative_path: str
    cause: Exception

    def caller_diagnostic(self) -> str:
        """Return only stable classification and an owned relative name."""
        return f"{self.operation.value} {self.owned_relative_path}"

    def raw_diagnostic(self) -> str:
        """Return full operator detail, including the original exception."""
        return f"{self.caller_diagnostic()}: {self.cause}"


class InstructionPairConflict(RuntimeError):
    """Raised when the canonical instruction pair cannot be converged safely.

    The pair-wide preservation barrier guarantees that when this is raised
    after preflight, both instruction paths are byte/type/raw-link identical
    to their pre-state (any completed preservation copy is retained and only
    an owned incomplete copy is removed).
    """

    def __init__(
        self,
        path: Path,
        reason: str,
        *,
        operation: InstructionPairOperation,
        compensation_failures: list[InstructionPairCompensationFailure] | None = None,
    ) -> None:
        self.path = Path(path)
        self.reason = reason
        self.operation = operation
        self.compensation_failures = tuple(compensation_failures or ())
        super().__init__(self.caller_diagnostic())

    def caller_diagnostic(self, *, max_compensation_failures: int = 4) -> str:
        """Return bounded caller-safe context without paths or exception text."""
        diagnostic = (
            f"instruction pair conflict at {self.path.name}: "
            f"{self.operation.value}"
        )
        if not self.compensation_failures:
            return diagnostic

        visible = self.compensation_failures[:max_compensation_failures]
        if len(self.compensation_failures) > max_compensation_failures:
            visible = self.compensation_failures[:max_compensation_failures - 1]
        nested = [failure.caller_diagnostic() for failure in visible]
        omitted = len(self.compensation_failures) - len(visible)
        if omitted > 0:
            nested.append(f"... and {omitted} more compensation failure(s)")
        return f"{diagnostic}; nested compensation incomplete: {'; '.join(nested)}"

    def raw_diagnostic(self) -> str:
        """Return complete operator detail for daemon logs only."""
        diagnostic = (
            f"instruction pair conflict at {self.path}: "
            f"{self.operation.value}: {self.reason}"
        )
        if self.compensation_failures:
            nested = "; ".join(
                failure.raw_diagnostic()
                for failure in self.compensation_failures
            )
            diagnostic = f"{diagnostic}; pair rollback failed: {nested}"
        return diagnostic


@dataclass(frozen=True)
class _InstructionPathState:
    kind: str  # absent | regular | symlink | unsupported
    data: bytes | None = None
    mode: int | None = None
    uid: int | None = None
    raw_link: str | None = None
    detail: str | None = None


def _classify_instruction_path(path: Path) -> _InstructionPathState:
    """Classify one instruction path with ``lstat`` and never follow links."""
    import stat as _stat

    try:
        st = os.lstat(path)
    except FileNotFoundError:
        return _InstructionPathState(kind="absent")
    except OSError as exc:
        return _InstructionPathState(kind="unsupported", detail=f"lstat failed: {exc}")
    if _stat.S_ISLNK(st.st_mode):
        try:
            raw = os.readlink(path)
        except OSError as exc:
            return _InstructionPathState(
                kind="unsupported", detail=f"readlink failed: {exc}"
            )
        return _InstructionPathState(
            kind="symlink",
            mode=st.st_mode & 0o7777,
            uid=st.st_uid,
            raw_link=raw,
        )
    if _stat.S_ISREG(st.st_mode):
        try:
            data = path.read_bytes()
        except OSError as exc:
            return _InstructionPathState(kind="unsupported", detail=f"read failed: {exc}")
        return _InstructionPathState(
            kind="regular",
            data=data,
            mode=st.st_mode & 0o7777,
            uid=st.st_uid,
        )
    return _InstructionPathState(kind="unsupported", detail="not a regular file")


def _timestamp_suffix() -> str:
    from datetime import datetime, timezone

    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")


def _reserve_sibling(directory: Path, stem: str) -> Path:
    """Reserve a collision-safe owned name in *directory* via ``O_EXCL``."""
    candidate = directory / stem
    counter = 0
    while True:
        try:
            fd = os.open(candidate, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            counter += 1
            candidate = directory / f"{stem}-{counter}"
            continue
        os.close(fd)
        return candidate


def _write_preservation_copy(path: Path, state: _InstructionPathState) -> Path:
    """Write and verify one collision-safe preservation copy.

    Returns the retained backup path. On failure the incomplete owned copy is
    removed and ``OSError`` is raised; a pre-existing collided/foreign path is
    never removed because reservation used ``O_EXCL``.
    """
    backup = _reserve_sibling(
        path.parent, f"{path.name}.happyranch-{_timestamp_suffix()}.bak"
    )
    assert state.data is not None
    try:
        with open(backup, "wb") as fh:
            fh.write(state.data)
        os.chmod(backup, state.mode or 0o644)
        if backup.read_bytes() != state.data:
            raise OSError("preservation copy byte verification failed")
        if (backup.stat().st_mode & 0o7777) != ((state.mode or 0o644) & 0o7777):
            raise OSError("preservation copy mode verification failed")
    except OSError:
        try:
            backup.unlink()
        except OSError:
            pass
        raise
    return backup


def _atomic_write_regular(path: Path, data: bytes, mode: int = 0o644) -> None:
    """Write *data* to a same-directory temp then atomically ``os.replace``."""
    temp = _reserve_sibling(
        path.parent, f"{path.name}.happyranch-{_timestamp_suffix()}.tmp"
    )
    try:
        with open(temp, "wb") as fh:
            fh.write(data)
        os.chmod(temp, mode)
        os.replace(temp, path)
    except OSError:
        try:
            temp.unlink()
        except OSError:
            pass
        raise


def _restore_instruction_path(path: Path, state: _InstructionPathState) -> None:
    """Restore one snapshotted instruction path without following links.

    Restoration uses a same-directory owned sibling plus ``os.replace`` for
    regular files and symlinks. An absent pre-state removes only the live path
    written by this attempt. Any unexpected non-regular live object fails
    closed; external link targets are never opened or mutated.
    """
    current = _classify_instruction_path(path)
    if current == state:
        return

    if state.kind == "absent":
        if current.kind == "absent":
            return
        if current.kind not in {"regular", "symlink"}:
            raise OSError(
                f"refusing to remove unexpected {current.kind} at {path}"
            )
        path.unlink()
    elif state.kind == "regular":
        assert state.data is not None
        staged = _reserve_sibling(
            path.parent, f"{path.name}.happyranch-{_timestamp_suffix()}.restore.tmp"
        )
        try:
            with open(staged, "wb") as fh:
                fh.write(state.data)
            os.chmod(staged, state.mode if state.mode is not None else 0o644)
            if state.uid is not None and state.uid != os.getuid():
                os.chown(staged, state.uid, -1)
            os.replace(staged, path)
        except Exception:
            try:
                staged.unlink()
            except OSError:
                pass
            raise
    elif state.kind == "symlink":
        assert state.raw_link is not None
        staged: Path | None = None
        for _ in range(64):
            candidate = path.parent / (
                f"{path.name}.happyranch-{_timestamp_suffix()}.restore.lnk"
            )
            try:
                os.symlink(state.raw_link, candidate)
            except FileExistsError:
                continue
            staged = candidate
            break
        if staged is None:
            raise OSError("could not reserve an owned instruction-link restore name")
        try:
            if state.uid is not None and state.uid != os.getuid():
                os.lchown(staged, state.uid, -1)
            os.replace(staged, path)
        except Exception:
            try:
                staged.unlink()
            except OSError:
                pass
            raise
    else:  # unsupported input is rejected before the preservation barrier
        raise OSError(f"cannot restore unsupported instruction state at {path}")

    restored = _classify_instruction_path(path)
    if restored != state:
        raise OSError(
            f"instruction-path restore verification failed at {path}: "
            f"expected {state!r}, got {restored!r}"
        )


def _restore_instruction_pair(
    agents: Path,
    agents_state: _InstructionPathState,
    claude: Path,
    claude_state: _InstructionPathState,
) -> list[InstructionPairCompensationFailure]:
    """Best-effort exact compensation for a caught post-barrier failure."""
    errors: list[InstructionPairCompensationFailure] = []
    # Restore CLAUDE.md first so a captured reverse AGENTS.md -> CLAUDE.md
    # never temporarily resolves through the new canonical link.
    for path, state in ((claude, claude_state), (agents, agents_state)):
        try:
            _restore_instruction_path(path, state)
        except Exception as exc:
            errors.append(
                InstructionPairCompensationFailure(
                    InstructionPairCompensationOperation.RESTORE_PATH,
                    path.name,
                    exc,
                )
            )
    return errors


def _claude_link_is_canonical(workspace: Path, state: _InstructionPathState) -> bool:
    """True when *state* is exactly raw relative ``CLAUDE.md -> AGENTS.md``.

    The raw link text must be exactly ``AGENTS.md`` and its resolution must
    equal a regular same-directory ``AGENTS.md``.
    """
    import stat as _stat

    if state.kind != "symlink" or state.raw_link != CANONICAL_CLAUDE_LINK_TARGET:
        return False
    agents = workspace / CANONICAL_AGENTS_NAME
    try:
        if not _stat.S_ISREG(os.lstat(agents).st_mode):
            return False
        return os.path.realpath(workspace / CANONICAL_CLAUDE_NAME) == os.path.realpath(
            agents
        )
    except OSError:
        return False


def instruction_pair_refusal(workspace: Path) -> str | None:
    """Return the refusal reason for a non-canonical pair, else ``None``.

    Read-only: classifies both paths with ``lstat`` and never follows,
    creates, repairs or mutates anything. Startup uses this before launch.
    """
    import stat as _stat

    agents = workspace / CANONICAL_AGENTS_NAME
    claude = workspace / CANONICAL_CLAUDE_NAME
    try:
        agents_st = os.lstat(agents)
    except FileNotFoundError:
        return f"{CANONICAL_AGENTS_NAME} is missing"
    except OSError as exc:
        return f"{CANONICAL_AGENTS_NAME} cannot be inspected: {exc}"
    if not _stat.S_ISREG(agents_st.st_mode):
        return f"{CANONICAL_AGENTS_NAME} is not a regular file"
    try:
        claude_st = os.lstat(claude)
    except FileNotFoundError:
        return f"{CANONICAL_CLAUDE_NAME} is missing"
    except OSError as exc:
        return f"{CANONICAL_CLAUDE_NAME} cannot be inspected: {exc}"
    if not _stat.S_ISLNK(claude_st.st_mode):
        return f"{CANONICAL_CLAUDE_NAME} is not a symlink to {CANONICAL_AGENTS_NAME}"
    try:
        raw = os.readlink(claude)
    except OSError as exc:
        return f"{CANONICAL_CLAUDE_NAME} link text cannot be read: {exc}"
    if raw != CANONICAL_CLAUDE_LINK_TARGET:
        return (
            f"{CANONICAL_CLAUDE_NAME} link text is {raw!r}, expected "
            f"{CANONICAL_CLAUDE_LINK_TARGET!r}"
        )
    try:
        if os.path.realpath(claude) != os.path.realpath(agents):
            return f"{CANONICAL_CLAUDE_NAME} does not resolve to {CANONICAL_AGENTS_NAME}"
    except OSError as exc:
        return f"{CANONICAL_CLAUDE_NAME} cannot be resolved: {exc}"
    return None


def canonical_instruction_pair_ok(workspace: Path) -> bool:
    """True when the workspace holds the accepted canonical instruction pair."""
    return instruction_pair_refusal(workspace) is None


def write_canonical_instruction_pair(workspace: Path, content: str) -> None:
    """Converge *workspace* on the canonical instruction pair (non-destructive).

    Preflight classifies both paths without following links. Every required
    preservation copy for both paths is written and verified before either
    path is mutated. ``AGENTS.md`` becomes the regular canonical file holding
    *content*; ``CLAUDE.md`` becomes the raw relative link ``AGENTS.md``.
    Raises :class:`InstructionPairConflict` on unreadable/unsupported input or
    a preservation-copy failure, leaving both paths unchanged.
    """
    workspace.mkdir(parents=True, exist_ok=True)
    data = content.encode("utf-8")
    agents = workspace / CANONICAL_AGENTS_NAME
    claude = workspace / CANONICAL_CLAUDE_NAME
    agents_state = _classify_instruction_path(agents)
    claude_state = _classify_instruction_path(claude)

    if agents_state.kind == "unsupported":
        raise InstructionPairConflict(
            agents,
            agents_state.detail or "unsupported input",
            operation=InstructionPairOperation.INPUT_INSPECTION,
        )
    if claude_state.kind == "unsupported":
        raise InstructionPairConflict(
            claude,
            claude_state.detail or "unsupported input",
            operation=InstructionPairOperation.INPUT_INSPECTION,
        )

    # ── Preservation barrier: ALL required copies for BOTH paths first ──
    if agents_state.kind == "regular" and agents_state.data != data:
        try:
            _write_preservation_copy(agents, agents_state)
        except OSError as exc:
            raise InstructionPairConflict(
                agents,
                str(exc),
                operation=InstructionPairOperation.PRESERVATION_COPY,
            )
    if claude_state.kind == "regular" and claude_state.data != data:
        try:
            _write_preservation_copy(claude, claude_state)
        except OSError as exc:
            # A completed AGENTS.md copy (if any) is retained and identified;
            # only an owned incomplete CLAUDE.md copy is removed.
            raise InstructionPairConflict(
                claude,
                str(exc),
                operation=InstructionPairOperation.PRESERVATION_COPY,
            )

    # ── Live pair transaction: compensate BOTH paths on caught failure ──
    failure_path = agents
    failure_operation = InstructionPairOperation.CANONICAL_WRITE
    try:
        # AGENTS.md: regular canonical file.
        if agents_state.kind == "absent":
            _atomic_write_regular(agents, data)
        elif agents_state.kind == "regular":
            if agents_state.data != data:
                _atomic_write_regular(agents, data, agents_state.mode or 0o644)
        else:  # symlink — atomic replace, never write through it
            _atomic_write_regular(agents, data)

        # CLAUDE.md: raw relative link to AGENTS.md.
        failure_path = claude
        failure_operation = InstructionPairOperation.LINK_CREATION
        if not _claude_link_is_canonical(workspace, claude_state):
            _replace_with_canonical_claude_link(claude)
    except Exception as exc:
        rollback_errors = _restore_instruction_pair(
            agents, agents_state, claude, claude_state,
        )
        raise InstructionPairConflict(
            failure_path,
            str(exc),
            operation=failure_operation,
            compensation_failures=rollback_errors,
        ) from exc


def _stage_canonical_claude_link(workspace: Path) -> Path:
    """Create an owned sibling raw relative ``CLAUDE.md -> AGENTS.md`` link.

    Returns the staging path. The staging name is reserved collision-safely via
    ``os.symlink`` (``FileExistsError`` retries); the caller owns and must
    clean up the returned sibling if it is not moved into place.
    """
    for _ in range(64):
        candidate = workspace / (
            f"{CANONICAL_CLAUDE_NAME}.happyranch-{_timestamp_suffix()}.lnk"
        )
        try:
            os.symlink(CANONICAL_CLAUDE_LINK_TARGET, candidate)
        except FileExistsError:
            continue
        return candidate
    raise OSError("could not reserve an owned instruction-link staging name")


def _replace_with_canonical_claude_link(claude: Path) -> None:
    """Atomically replace *claude* with the canonical raw relative link.

    The new link is fully created under an owned sibling first and only then
    ``os.replace``d into place (``rename(2)``), so no unlink-before-success
    window exists: a failed creation or replacement leaves the pre-existing
    path — regular file, foreign link or absent — exactly as it was. On any
    ``OSError`` the owned staging sibling is removed and the error propagates.
    """
    staged: Path | None = None
    try:
        staged = _stage_canonical_claude_link(claude.parent)
        os.replace(staged, claude)
    except OSError:
        if staged is not None:
            try:
                staged.unlink()
            except OSError:
                pass
        raise


class ClaudeWorkspaceAdapter:
    """Bootstrap and maintain Claude Code workspaces."""

    provider_name = "claude"

    def __init__(self, settings: Settings, paths: "OrgPaths", *, slug: str) -> None:
        self._settings = settings
        self._paths = paths
        self._slug = slug
        self._persistent = PersistentWorkspaceSetup(settings)

    def write_settings_json(
        self,
        workspace: Path,
        repo_names: list[str] | None = None,
        agent_name: str | None = None,
    ) -> None:
        """Write .claude/settings.json to workspace."""
        claude_dir = workspace / ".claude"
        claude_dir.mkdir(parents=True, exist_ok=True)
        settings_data = build_settings_json(
            self._paths, repo_names or [], agent_name=agent_name,
        )
        (claude_dir / "settings.json").write_text(
            json.dumps(settings_data, indent=2) + "\n"
        )

    def write_claude_md(
        self,
        workspace: Path,
        agent_name: str,
        system_prompt: str,
        repo_names: list[str] | None = None,
    ) -> None:
        """Write the canonical instruction pair with system prompt and pointers.

        The active-executor content is written to the regular canonical
        ``AGENTS.md``; ``CLAUDE.md`` becomes the raw relative link
        ``AGENTS.md``. ``repo_names`` is accepted for API compatibility but is
        not listed inline — the canonical file points at the agent's
        authoritative ``org/agents/<name>.md`` frontmatter (``AgentDef.repos``)
        so the repo list doesn't drift between the two files.
        """
        _assert_no_reserved_headers_in_body(agent_name, system_prompt)
        workspace.mkdir(parents=True, exist_ok=True)
        sections = self._build_sections(
            agent_name,
            system_prompt,
            workspace=workspace,
            include_start_task=True,
            repo_refresh_note=(
                "repositories cloned under `repos/`. The daemon fast-forward-"
                "refreshes each cloned repo at session spawn, before your "
                "session starts."
            ),
            callback_note=(
                "The `--from-file` form is mandatory here — multi-line `happyranch` "
                "invocations are blocked by the `Bash(happyranch:*)` permission rule."
            ),
            workflow_section=[
                "Every task arrives via the orchestrator's prompt. Use the **start-task** skill",
                "(in `.claude/skills/start-task/`) to parse parameters and report completion via",
                "`happyranch report-completion`. Mid-task memory items go through `happyranch memory`.\n",
            ],
            skills_dir=".claude/skills",
        )
        write_canonical_instruction_pair(workspace, "\n".join(sections))

    def _build_sections(
        self,
        agent_name: str,
        system_prompt: str,
        *,
        workspace: Path,
        include_start_task: bool,
        repo_refresh_note: str,
        callback_note: str,
        workflow_section: list[str],
        skills_dir: str,
    ) -> list[str]:
        sections = [
            f"# Agent: {agent_name}\n",
            "## System Prompt\n",
            system_prompt.strip() + "\n",
            "## Available Repositories\n",
            f"See the `repos` list in your authoritative `org/agents/{agent_name}.md` "
            "frontmatter (`AgentDef.repos`) — bootstrap paths (enrollment/init/"
            "manage-repo) provision missing clones, while session spawn only "
            "fast-forward-pulls existing",
            repo_refresh_note + "\n",
            *_memory_bootstrap_section(workspace),
            "## Knowledge Base (shared across agents)\n",
            "Path: `<runtime>/kb/`. Read: everyone. Write: any agent (via `--from-file`).",
            "Delete: any team manager (audited); founder via `--as-founder`.",
        ]
        if include_start_task:
            sections.extend([
                "The **start-task** skill's *Consult KB* and *Contribute to KB* steps are",
                "mandatory — do not skip them.\n",
            ])
        sections.extend([
            "Read:",
            "```",
            "happyranch kb list [--topic <t>] [--type <label>]",
            "happyranch kb search \"<keywords>\"",
            "happyranch kb get <slug>",
            "```\n",
            "Write (durable, cross-agent knowledge only — regulations, partner-API quirks,",
            "payment flows, founder rulings; **not** task-specific notes):",
            "```",
            "happyranch kb add --agent <you> --from-file /tmp/kb-<slug>.md",
            "happyranch kb update <slug> --agent <you> --from-file /tmp/kb-<slug>.md",
            "```",
            "Payload file needs YAML frontmatter (`slug`, `title`, `type`, `topic`,",
            "optional `tags`, `source_task`) followed by a markdown body. `type` is a",
            "freeform label (e.g. `reference`, `ruling`, `sop`) used for grouping.",
            callback_note + "\n",
            *_shared_artifacts_section(),
            *_thread_talk_dispatch_doctrine_section(),
            *_skills_directory_readonly_section(skills_dir, agent_name),
            *_non_stop_command_warning_section(),
            *_task_completion_format_section(),
            "## Task Recall\n",
            "Past task context (brief, completion summary, output files) is retrievable via:",
            "```",
            "happyranch recall <task_id>                  # brief + final summary",
            "happyranch recall <task_id> --tree           # include the full subtree of child tasks",
            "happyranch recall <task_id> --fetch-output   # inline output file bodies (capped at ~200KB)",
            "```",
            "Use when the current brief references a prior task, when you need to revisit",
            "your own earlier output before reworking, or when a KB entry points to",
            "`source_task: TASK-xyz`. Your own recent activity is also summarized in",
            "`task_history.md` at the workspace root.\n",
            "## Workflow\n",
        ])
        sections.extend(workflow_section)
        return sections

    def ensure_workspace_ready(
        self,
        workspace: Path,
        agent_name: str,
        system_prompt: str,
    ) -> None:
        """Make sure an agent workspace has every file the orchestrator requires."""
        repo_names = self._persistent.ensure(workspace, agent_name)

        # CLAUDE.md, settings.json, and the skills tree are always regenerated
        # so workspaces carried over from older code self-heal.
        self.write_claude_md(workspace, agent_name, system_prompt, repo_names=repo_names)
        self._copy_skills(workspace)
        self.write_settings_json(
            workspace, repo_names=repo_names, agent_name=agent_name,
        )

    def _copy_skills(self, workspace: Path) -> None:
        """No-op: canonical store + symlinks supersede wholesale copy.

        Skills are materialized on every session spawn via
        ``materialize_workspace_skills``, not at bootstrap time.
        """


class CodexWorkspaceAdapter:
    """Bootstrap and maintain Codex workspaces."""

    provider_name = "codex"

    def __init__(self, settings: Settings, paths: "OrgPaths", *, slug: str) -> None:
        self._settings = settings
        self._paths = paths
        self._slug = slug
        self._persistent = PersistentWorkspaceSetup(settings)

    def write_agents_md(
        self,
        workspace: Path,
        agent_name: str,
        system_prompt: str,
        repo_names: list[str] | None = None,
    ) -> None:
        """Write AGENTS.md to workspace with system prompt and context pointers.

        Codex CLI ≥0.125 discovers skills by walking ``.agents/skills/`` from
        the working directory up to the repo root. Canonical materialization
        publishes relative skill links under BOTH ``.claude/skills`` and
        ``.agents/skills``. AGENTS.md points at the **start-task** skill for
        usage instructions; request models and transition handlers enforce
        the completion contract.
        """
        _assert_no_reserved_headers_in_body(agent_name, system_prompt)
        workspace.mkdir(parents=True, exist_ok=True)
        # Shared bootstrap sections (KB, memory, artifacts) are assembled in
        # Claude's _build_sections and flow through here unchanged.
        sections = ClaudeWorkspaceAdapter(self._settings, self._paths, slug=self._slug)._build_sections(
            agent_name,
            system_prompt,
            workspace=workspace,
            include_start_task=True,
            repo_refresh_note=(
                "repositories cloned under `repos/`. The daemon fast-forward-"
                "refreshes each cloned repo at session spawn, before your "
                "session starts; refresh again yourself mid-task if you need "
                "newer state."
            ),
            callback_note=(
                "Use the `--from-file` form to keep the callback contract stable "
                "across executors and avoid shell quoting issues."
            ),
            workflow_section=[
                "Every task arrives via the orchestrator's prompt. Use the **start-task** skill",
                "(in `.agents/skills/start-task/`) to parse parameters and report completion via",
                "`happyranch report-completion`. Mid-task memory items go through `happyranch memory`.\n",
            ],
            skills_dir=".agents/skills",
        )
        write_canonical_instruction_pair(workspace, "\n".join(sections))

    def _copy_skills(self, workspace: Path) -> None:
        """No-op: canonical store + symlinks supersede wholesale copy."""

    def ensure_workspace_ready(
        self,
        workspace: Path,
        agent_name: str,
        system_prompt: str,
    ) -> None:
        """Make sure a Codex workspace has the shared persistent files and bootstrap."""
        self._persistent.ensure(workspace, agent_name)
        self.write_agents_md(workspace, agent_name, system_prompt)
        self._copy_skills(workspace)


class OpencodeWorkspaceAdapter:
    """Bootstrap and maintain opencode workspaces.

    opencode reads ``AGENTS.md`` (with ``CLAUDE.md`` as a fallback) and
    discovers skills under ``.opencode/skills/``, ``.claude/skills/``, or
    ``.agents/skills/``. We use the same ``AGENTS.md`` + ``.agents/skills/``
    layout as Codex so a single workspace shape works for both executors.

    The opencode-specific surface is ``opencode.json``: a structured
    permission file that gates bash by command-prefix glob. We write a
    strict default (``"*": "deny"``) plus per-agent allow rules sourced
    from the same ``allow_rules`` frontmatter Claude reads. No
    ``--dangerously-skip-permissions`` — the file is the enforcement
    surface, and bypassing it would erase the per-prefix discipline that
    CLAUDE.md mandates.
    """

    provider_name = "opencode"

    def __init__(self, settings: Settings, paths: "OrgPaths", *, slug: str) -> None:
        self._settings = settings
        self._paths = paths
        self._slug = slug
        self._persistent = PersistentWorkspaceSetup(settings)
        # AGENTS.md generation is identical to Codex — delegate.
        self._codex_adapter = CodexWorkspaceAdapter(settings, paths, slug=slug)

    def write_agents_md(
        self,
        workspace: Path,
        agent_name: str,
        system_prompt: str,
        repo_names: list[str] | None = None,
    ) -> None:
        """Write AGENTS.md to workspace. Same shape as Codex's AGENTS.md."""
        self._codex_adapter.write_agents_md(
            workspace, agent_name, system_prompt, repo_names=repo_names,
        )

    def write_opencode_json(
        self, workspace: Path, agent_name: str | None = None,
    ) -> None:
        """Write ``opencode.json`` with the agent's bash allow list.

        Default for unmatched bash is ``"deny"`` so an agent attempting an
        unsanctioned command fails fast rather than waiting on an
        interactive prompt that will never arrive in headless mode. The
        sanctioned channel (``happyranch``) is always allowed; per-agent extras
        come from the same ``allow_rules`` frontmatter Claude reads.
        """
        prefixes = bash_allow_prefixes_for_agent(self._paths, agent_name)
        permission_bash: dict[str, str] = {"*": "deny"}
        for prefix in prefixes:
            permission_bash[f"{prefix} *"] = "allow"
        config = {
            "$schema": "https://opencode.ai/config.json",
            "permission": {"bash": permission_bash},
        }
        (workspace / "opencode.json").write_text(
            json.dumps(config, indent=2) + "\n"
        )

    def _copy_skills(self, workspace: Path) -> None:
        """No-op: canonical store + symlinks supersede wholesale copy."""

    def ensure_workspace_ready(
        self,
        workspace: Path,
        agent_name: str,
        system_prompt: str,
    ) -> None:
        """Make sure an opencode workspace has every file the orchestrator requires."""
        self._persistent.ensure(workspace, agent_name)
        self.write_agents_md(workspace, agent_name, system_prompt)
        self._copy_skills(workspace)
        self.write_opencode_json(workspace, agent_name=agent_name)


class PiWorkspaceAdapter:
    """Bootstrap and maintain Pi workspaces.

    Pi reads ``AGENTS.md`` and uses the same shared skill tree layout as
    Codex. Keep this as a named adapter so Pi-specific bootstrap files can be
    added later without changing ContextBuilder's provider contract.
    """

    provider_name = "pi"

    def __init__(self, settings: Settings, paths: "OrgPaths", *, slug: str) -> None:
        self._codex_adapter = CodexWorkspaceAdapter(settings, paths, slug=slug)

    def ensure_workspace_ready(
        self,
        workspace: Path,
        agent_name: str,
        system_prompt: str,
    ) -> None:
        self._codex_adapter.ensure_workspace_ready(workspace, agent_name, system_prompt)
