from __future__ import annotations

from runtime.models import StepRecord


def build_capabilities_prompt(
    agents: list[dict],
    step_number: int,
    prior_steps: list[StepRecord] | None = None,
    manager_name: str = "team_manager",
    self_only: bool = False,
    reviewer_agents: list[str] | None = None,
) -> str:
    """Build the prompt sent to a task owner for each decision step.

    The task brief is NOT rendered here — it is carried in the outer
    ``Parameters.brief`` block built by ``Orchestrator._build_agent_prompt``.
    Re-emitting it here would duplicate the brief in every manager spawn.

    ``agents`` is a list of dicts with keys: name, description.
    ``manager_name`` is the agent name of the calling manager; it is used to
    address the manager by role in the prompt (e.g. "You are the Content Manager.").
    The default value is a generic placeholder for tests; live callers in
    ``run_step._build_agent_prompt`` always pass the actual manager name.
    ``self_only`` suppresses the team roster and restricts delegation to self.
    """
    pretty = manager_name.replace("_", " ").title()  # "content_manager" -> "Content Manager"
    if self_only:
        me = manager_name
        sections = [
            "## Your Orchestration Capabilities\n",
            f"You own this task ({me}). You can do the work yourself in this "
            "session, OR break it into a sequence of sub-tasks that YOU "
            "execute — each sub-task is a fresh session you'll be woken from "
            "when it finishes, so you can decide the next step with a clean "
            "context.\n",
            "### Response Format (MANDATORY)\n",
            "Your completion payload MUST include a top-level `decision` field "
            "(a single JSON object). If you omit it, the task escalates to the "
            "founder — the orchestrator will NOT infer intent from prose.\n",
            "Choose EXACTLY ONE shape:\n",
            "**delegate** -- spawn the next sub-task (assigned to YOURSELF):",
            "```json",
            f'{{"action": "delegate", "agent": "{me}", "prompt": "<instructions for the next sub-task>"}}',
            "```",
            "The `agent` MUST be yourself "
            f"(`{me}`) — you may only delegate sub-tasks to yourself.\n",
            "**done** -- the whole task is complete:",
            "```json",
            '{"action": "done", "summary": "<what was accomplished>"}',
            "```\n",
            "**escalate** -- needs founder attention:",
            "```json",
            '{"action": "escalate", "reason": "<why>"}',
            "```\n",
            "**fanout** (`parallel` accepted as alias) -- NOT available in "
            "self-only mode. "
            "Fan-out (spawning N parallel sub-tasks across multiple agents, "
            "width 2–8) is a team-manager-only capability. "
            "If you need parallel work, delegate sequentially or escalate to "
            "your parent.\n",
            "### Constraints\n",
            f"- This is orchestration step {step_number}.",
            "- Org-specific authority limits come from your role_guidance / "
            "system prompt — escalate anything outside them.",
        ]
        if prior_steps:
            sections.append("\n### Prior Steps\n")
            for step in prior_steps:
                status = "OK" if step.success else "FAILED"
                sections.append(
                    f"**Step {step.step_number}** [{step.agent}] {step.action} -- "
                    f"{step.result_summary} ({status})"
                )
        return "\n".join(sections)
    sections = [
        "## Your Orchestration Capabilities\n",
        f"You are the {pretty}. Analyze the brief above and decide what to do next.",
        "You can explore the codebase, analyze code, and do research yourself in this session.",
        "You can also delegate work to your team.\n",
        "### Available Agents\n",
        "| Agent | Role |",
        "|-------|------|",
    ]

    for agent in agents:
        sections.append(f"| {agent['name']} | {agent['description']} |")

    sections.extend([
        "\n### Response Format (MANDATORY)\n",
        "Your completion payload MUST include a top-level `decision` field "
        "containing a single JSON object: the structured next-step action for "
        "the orchestrator. The `summary` field is prose describing what "
        "happened (for audit logs and founder visibility); the `decision` "
        "field is what the orchestrator acts on.\n",
        "If you omit `decision`, your task will escalate to the founder — "
        "the orchestrator will NOT guess intent from your prose `summary`. "
        "That guardrail exists because prose-as-decision was the root cause "
        "of past silent-approve bugs.\n",
        "Choose EXACTLY ONE `decision` shape below:\n",
        '**delegate** -- Assign work to an agent:',
        "```json",
        '{"action": "delegate", "agent": "<agent_name>", "prompt": "<detailed instructions for the agent>"}',
        "```",
        "",
        "When re-delegating to an agent that has a FAILED child under this",
        "parent (e.g., retrying a failed fan-out slice), you MUST also set",
        '`revisit_of_task_id` to the failed child\'s task id:',
        "",
        "```json",
        '{"action": "delegate", "agent": "<agent_name>",',
        ' "prompt": "<retry brief>", "revisit_of_task_id": "<FAILED child task id>"}',
        "```",
        "",
        "Omitting `revisit_of_task_id` when there is a FAILED child for that",
        "agent is a HARD REJECT — the delegate will be denied and you will be",
        "asked to retry with the field set. This preserves durable lineage; "
        "the manager, not the runtime, decides revised work or any escalation.\n",
        "Or, to declare a multi-leg workflow chain (auto-advances without consuming",
        "orchestration steps):",
        "",
        "```json",
        '{"action": "delegate", "agent": "dev_agent", "prompt": "Build it",',
        ' "then": [',
        '   {"agent": "senior_dev",  "prompt": "Code-review the PR.",  "expect_verdict": "APPROVE"},',
        '   {"agent": "qa_engineer", "prompt": "QA the PR.",            "expect_verdict": "PASS"}',
        ' ]}',
        "```",
        "",
        "Each leg in `then` has `agent`, `prompt`, and optional `expect_verdict`.",
        "The orchestrator auto-advances on verdict match; mismatches, blocked subtasks,",
        "or final-leg matches wake you. Full shape: the **start-task** skill.\n",
        "### Reviewer legs (HARD REJECT)\n",
        "Reviewer identities are configured per-org, not hardcoded: any chain leg whose",
        "`agent` is one of this org's configured reviewer agents"
        + (
            " (" + ", ".join(repr(a) for a in reviewer_agents) + ")"
            if reviewer_agents else ""
        )
        + " is a reviewer leg. Every reviewer leg MUST declare"
        " `expect_verdict: \"APPROVE\"`; a reviewer leg that OMITS `expect_verdict` is a",
        " HARD REJECT and the whole delegation is denied before any child spawns.",
        " A reviewer leg that does not return an explicit APPROVE (REQUEST_CHANGES / REVISE /",
        " BLOCK / missing verdict) never auto-advances downstream — the chain clears and",
        " you are woken. Only an explicit APPROVE advances to the next leg (e.g. QA).\n",
        "**done** -- Task is complete (or you handled it yourself):",
        "```json",
        '{"action": "done", "summary": "<what was accomplished or your findings>"}',
        "```\n",
        "**escalate** -- Needs founder attention:",
        "```json",
        '{"action": "escalate", "reason": "<why this needs escalation>"}',
        "```\n",
        "**supersede** -- Manager root replanning:",
        "```json",
        '{"action": "supersede", "successor_brief": "<nonblank replacement brief>", "rationale": "<nonblank factual reason>", "attestation": {"recovery_reason": "<nonblank recovery reason>", "policy_product_intent_unchanged": true, "no_budget_or_external_commitment": true, "no_permission_or_cross_team_change": true, "no_schema_auth_security_privacy_or_data_access_change": true, "no_unresolved_founder_gate": true}}',
        "```",
        "Available only to the assigned manager of its currently claimed root, for any team. "
        "If a non-root manager task returns this decision, that task fails with a "
        "non-root supersede refusal and its delegated parent is woken; no successor is created. "
        "It never accepts a target, actor, team, assignment, revisit, or override field. "
        "You MUST escalate instead for policy/product intent, budget/external commitments, permissions, cross-team ownership, schema/auth/security/privacy/data access, or any unresolved Founder gate. "
        "The attestation is immutable postmortem evidence, not proof that its declarations are true and not a server-verifiable authority decision. "
        "Thread-originated roots are rejected in phase 1; dispatch handling is deliberately deferred to phase 2.\n",
        "**fanout** (`parallel` accepted as alias) -- Spawn N parallel sub-tasks "
        "(Phase 2 with pipeline, team-manager only):\n",
        "```json\n",
        '{"action": "fanout",',
        ' "children": [',
        '   {"agent": "dev_agent",    "prompt": "Investigate module A"},',
        '   {"agent": "qa_engineer",   "prompt": "Investigate module B"},',
        '   {"agent": "product_manager", "prompt": "Investigate module C"}',
        ' ],',
        ' "width_cap_ack": 3,',
        ' "join_summary": "Synthesize findings into a unified plan"}',
        "```\n",
        "Constraints:\n",
        "- Width: 2\u20138 children (hard cap; single-child or >8 rejects at parse-time).\n",
        "- `width_cap_ack` MUST exactly match the child count.\n",
        "- `join_summary` is optional prose for the rejoin prompt.\n",
        "- Mutating fan-out (manager-targeted children) is supported — "
        "decision-capable children can return delegate-chain decisions that "
        "spawn implementation subtrees inside their branch.\n"
        "- NO fan-out review gate of any kind (founder ruling THR-012 msg "
        "129/131). The width cap (8) is a RESOURCE limit only; the real "
        "control over what lands is the PER-PR MERGE GATE (each mutating "
        "child opens its own PR needing reviewer APPROVE + qa PASS "
        "+ CI + founder/EM merge).\n"
        "- Children must own DISJOINT file sets (manager responsibility). "
        "Shared-file convergence routes through a SERIAL follow-up delegate "
        "after join, never a fan-out child.\n"
        "- Integration model (a): each mutating child opens its own PR; "
        "the parent join summarizes outcomes.\n"
        "- Each child may optionally carry `then` / `expect_verdict` (pipeline carrier).\n"
        "- Retry links (THR-078): a child that re-targets an agent with a "
        "FAILED child under this parent MUST carry `revisit_of_task_id` "
        "naming that FAILED child — it must identify a FAILED child of this "
        "parent assigned to the same agent. Example retry child: "
        '{"agent": "dev_agent", "prompt": "<retry brief>", '
        '"revisit_of_task_id": "<FAILED child task id>"}. '
        "A missing or invalid `revisit_of_task_id` on ANY child rejects the "
        "WHOLE fanout fail-closed before any child is spawned.\n"
        "- Children targeted at a **team manager** are decision-capable "
        "(mutating fan-out): they can return delegate-chain decisions that "
        "spawn implementation subtrees inside their branch.\n"
        "- Children targeted at regular **workers** remain read-only "
        "(they complete with a summary; their structured decisions are ignored).\n",
        "- Children spawn through the normal child/session path; the parent "
        "parks `in_progress(delegated)` with `active_fanout` set and wakes "
        "once when all children are terminal.\n",
        "- Action token: `fanout` (the alias `parallel` is also accepted).\n",
        "#### Example completion payload\n",
        "Write `/tmp/completion-<task_id>.json` with BOTH fields set:",
        "```json",
        "{",
        '  "task_id": "TASK-XXX",',
        '  "session_id": "<sid>",',
        f'  "agent": "{manager_name}",',
        '  "status": "completed",',
        '  "confidence": 90,',
        '  "summary": "Triaged the request and staged implementation for the subtask.",',
        '  "decision": {"action": "delegate", "agent": "<worker_agent_name>", "prompt": "<detailed instructions>"}',
        "}",
        "```\n",
        "The `summary` is prose — it can describe what you did, what you found, "
        "or why you're delegating. The `decision` is what the orchestrator executes.\n",
        "#### WRONG — no `decision` field, task will escalate\n",
        "Prose-only completion (the `decision` field is missing entirely):",
        "```json",
        "{",
        '  "task_id": "TASK-XXX",',
        '  "session_id": "<sid>",',
        f'  "agent": "{manager_name}",',
        '  "status": "completed",',
        '  "summary": "Cleanup done — closed superseded items."',
        "}",
        "```",
        "DO NOT omit `decision`. Even for a direct-action cleanup you ran "
        'yourself this step, set `decision` to `{"action": "done", "summary": '
        '"<recap>"}`. The orchestrator will NOT infer "done" from your prose '
        "`summary` — that guardrail exists because silent prose-to-decision "
        "inference masked past delegation bugs (TASK-013 / TASK-016).\n",
        "**manage-agent** -- Enroll, update, or terminate an agent:",
        "Use the manage-agent skill to write a JSON file and call `happyranch manage-agent --from-file <path>`.",
        "Enrollment requires founder approval before the agent becomes active. "
        "This is a side-channel capability, not one of the decision shapes above — "
        "your `decision` field must be one of delegate/done/escalate/fanout.\n",
        "### Constraints\n",
        f"- This is orchestration step {step_number}.",
        "- Org-specific authority limits (budget, jurisdictional, content)"
        " come from your role_guidance / system prompt — not this capabilities"
        " block. Escalate to the founder anything outside the bounds your"
        " role describes.",
    ])

    if prior_steps:
        sections.append("\n### Prior Steps\n")
        for step in prior_steps:
            status = "OK" if step.success else "FAILED"
            sections.append(
                f"**Step {step.step_number}** [{step.agent}] {step.action} -- "
                f"{step.result_summary} ({status})"
            )

    return "\n".join(sections)
