"""Aggregations powering GET /api/v1/orgs/{slug}/dashboard/summary.

Pure functions over Database + KbStore. Each function takes an explicit
`now` clock so tests are deterministic.

Spec: docs/superpowers/specs/2026-05-30-dashboard-overhaul-design.md
"""
from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from typing import Literal

from pydantic import BaseModel, Field

from runtime.infrastructure.database import Database
from runtime.orchestrator.escalation_reason import (
    EscalationReason,
    derive_current_escalation_reason,
)


class HeartbeatBucket(BaseModel):
    hour: int
    steps: int
    failed: int
    tier: Literal["ok", "warn", "bad"]


class NarrativeCounts(BaseModel):
    completed_today: int
    failed_today: int
    escalated_open: int
    kb_added_today: int
    agents_active_now: int
    spend_today_usd: float


class EscalationRow(BaseModel):
    task_id: str
    agent: str
    team: str
    question: str
    raised_at: datetime
    age_seconds: int
    # THR-037 Change B §G: a DERIVED display flavor for the single stored
    # `escalated` status, classified from the escalation audit reason. One of
    # "needs-decision" / "exhausted" / "over-budget", or None when the reason
    # is absent/unrecognized (surface falls back to plain "escalated").
    flavor: str | None = None
    # Default preserves compatibility with cached projections composed by an
    # older daemon before the additive current-episode field existed.
    escalation_reason: EscalationReason | None = None


class PendingReviewJobRow(BaseModel):
    id: str
    task_id: str
    agent_name: str
    title: str
    created_at: datetime


class StaleEscalationRow(BaseModel):
    task_id: str
    agent: str
    team: str
    age_seconds: int


class ActiveByTeam(BaseModel):
    team: str
    count: int
    task_ids: list[str]


class ActivityRow(BaseModel):
    timestamp: datetime
    who: str
    event_kind: str
    task_id: str | None
    verdict: Literal["ok", "fail", "warn"] | None
    thread_dream_id: str | None = Field(default=None, serialization_alias="_thread_dream_id")


class UpdateRow(BaseModel):
    marker: Literal["add", "warn", "info"]
    text: str
    meta: str
    timestamp: datetime


class TeamPulse(BaseModel):
    team: str
    acceptance_pct: int
    trend_delta: int
    sparkline: list[float]
    members: int
    lead: str


class DashboardSummaryResponse(BaseModel):
    heartbeat: list[HeartbeatBucket]
    narrative_counts: NarrativeCounts
    escalations: list[EscalationRow]
    # Default preserves compatibility with persisted projections written
    # before approval-required jobs were included in the dashboard.
    pending_review_jobs: list[PendingReviewJobRow] = Field(default_factory=list)
    stale_escalations: list[StaleEscalationRow]
    active_by_team: list[ActiveByTeam]
    recent_activity: list[ActivityRow]
    updates_this_week: list[UpdateRow]
    org_pulse: list[TeamPulse]
    org_age_days: int
    server_now: datetime
    generated_at: datetime | None = Field(
        default=None,
        description=(
            "When the projection was last successfully refreshed "
            "(cache-only: never a synchronous compose). None when no "
            "projection exists yet (cold-start before first refresh)."
        ),
    )


def compute_org_age_days(db: Database, *, now: datetime | None = None) -> int:
    """Days between the earliest audit_log row and `now`. Empty DB → 0."""
    row = db.fetch_one_readonly("SELECT MIN(timestamp) AS first_ts FROM audit_log")
    if not row or not row["first_ts"]:
        return 0
    first = datetime.fromisoformat(row["first_ts"])
    moment = now or datetime.now(timezone.utc)
    if first.tzinfo is None:
        first = first.replace(tzinfo=timezone.utc)
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=timezone.utc)
    return max(0, (moment - first).days)


def _local_midnight(now: datetime) -> datetime:
    """Truncate `now` to local midnight (UTC for our deterministic clock)."""
    return now.replace(hour=0, minute=0, second=0, microsecond=0)


def compute_spend_today(db: Database, *, now: datetime) -> float:
    """Sum estimated USD spend recorded since local midnight.

    The real schema stores per-session cost on ``task_results.estimated_cost``
    (``session_token_usage`` records token counts only). The spec's pseudocode
    references a ``token_usage.cost_usd`` column that does not exist; this
    function implements the intent against the actual table.
    """
    midnight = _local_midnight(now).isoformat()
    row = db.fetch_one_readonly(
        "SELECT COALESCE(SUM(estimated_cost), 0) AS total "
        "FROM task_results WHERE created_at >= ?",
        (midnight,),
    )
    return float(row["total"]) if row else 0.0


def compute_narrative_counts_today(
    db: Database, *, now: datetime, kb_store
) -> NarrativeCounts:
    """Today = local midnight to now. Aggregates over tasks + audit_log +
    task_results + the KB store."""
    midnight = _local_midnight(now).isoformat()

    completed_row = db.fetch_one_readonly(
        "SELECT COUNT(*) AS n FROM tasks "
        "WHERE status = 'completed' AND updated_at >= ?",
        (midnight,),
    )
    completed = int(completed_row["n"]) if completed_row else 0

    failed_row = db.fetch_one_readonly(
        "SELECT COUNT(*) AS n FROM tasks "
        "WHERE status = 'failed' AND updated_at >= ?",
        (midnight,),
    )
    failed = int(failed_row["n"]) if failed_row else 0

    # Path B (THR-037 Change B): escalations are the stored top-level
    # status='escalated' (block_kind cleared), no longer blocked+escalated.
    # Only root tasks (parent_task_id IS NULL) escalate to the founder;
    # non-root tasks fail and hand back to their parent (CLAUDE.md).
    # Match list_roots/TasksPage semantics so the Home 'Waiting on you'
    # badge and narrative count stay coherent.
    escalated_row = db.fetch_one_readonly(
        "SELECT COUNT(*) AS n FROM tasks WHERE status = 'escalated' AND parent_task_id IS NULL",
    )
    escalated = int(escalated_row["n"]) if escalated_row else 0

    # Distinct agents whose most recent session_start (per task_id,agent) is
    # unmatched by a later session_end. Uses a single grouped scan instead of a
    # correlated NOT EXISTS — the old O(n²) query held the per-org SQLite
    # Database._lock for 15+ seconds with 39k audit_log rows, blocking all
    # other org routes (THR-129 / TASK-3878 root cause).
    #
    # Semantics verified by adversarial parity tests:
    #   - An end whose timestamp EQUALS (not >) a start does NOT close it.
    #   - An agent is counted once (DISTINCT agent) regardless of how many
    #     tasks they're active in.
    #   - Restarted/overlapping sessions: only the MAX timestamp per
    #     (task_id, agent) matters — the last open stays open.
    active_rows = db.fetch_all_readonly(
        "SELECT DISTINCT agent FROM audit_log "
        "WHERE action IN ('session_start', 'session_end') "
        "GROUP BY task_id, agent "
        "HAVING MAX(CASE WHEN action = 'session_start' THEN timestamp END) IS NOT NULL "
        "  AND (MAX(CASE WHEN action = 'session_end' THEN timestamp END) IS NULL "
        "       OR MAX(CASE WHEN action = 'session_start' THEN timestamp END) >= "
        "          MAX(CASE WHEN action = 'session_end' THEN timestamp END))"
    )
    active_now = len(active_rows)

    return NarrativeCounts(
        completed_today=completed,
        failed_today=failed,
        escalated_open=escalated,
        kb_added_today=kb_store.count_entries_created_since(_local_midnight(now)),
        agents_active_now=active_now,
        spend_today_usd=compute_spend_today(db, now=now),
    )


def _tier_for_ratio(failed: int, total: int) -> Literal["ok", "warn", "bad"]:
    """Map failed:total ratio to a tier. < 10% = ok, < 30% = warn, else = bad."""
    if total == 0 or failed == 0:
        return "ok"
    ratio = failed / total
    if ratio < 0.10:
        return "ok"
    if ratio < 0.30:
        return "warn"
    return "bad"


def compute_heartbeat_24h(db: Database, *, now: datetime) -> list[HeartbeatBucket]:
    """24 hourly buckets ending at `now`. Steps = session_start +
    completion_report rows. Failed/completed counts come from terminal
    task transitions (``tasks.completed_at`` bucketed by hour) so
    orchestrator-side failures (timeouts, cascade-fail, daemon-restart) are
    counted — agents only self-report ``completed``/``blocked`` via
    ``completion_report``, so audit-log-driven failure counts under-report.
    Tier = ok/warn/bad by failed:(completed+failed) ratio."""
    window_start = (now - timedelta(hours=24)).isoformat()
    rows = db.fetch_all_readonly(
        "SELECT timestamp FROM audit_log "
        "WHERE timestamp >= ? AND action IN ('session_start', 'completion_report') "
        "LIMIT 50000",
        (window_start,),
    )
    steps_by_hour: dict[int, int] = {h: 0 for h in range(24)}
    failed_by_hour: dict[int, int] = {h: 0 for h in range(24)}
    completed_by_hour: dict[int, int] = {h: 0 for h in range(24)}
    for r in rows:
        ts = datetime.fromisoformat(r["timestamp"])
        steps_by_hour[ts.hour] += 1

    # Bucket by ``updated_at`` rather than ``completed_at``: several
    # transition paths set status=failed without populating completed_at
    # (daemon-restart sweep in src/daemon/__main__.py, escalation rejection
    # in src/daemon/routes/tasks.py). ``compute_narrative_counts_today``
    # uses ``updated_at`` for the same query — matching it keeps the bar
    # chart consistent with the "N tasks completed, M failed" narrative.
    terminal_rows = db.fetch_all_readonly(
        "SELECT status, updated_at FROM tasks "
        "WHERE updated_at >= ? AND status IN ('completed', 'failed')",
        (window_start,),
    )
    for r in terminal_rows:
        ts = datetime.fromisoformat(r["updated_at"])
        h = ts.hour
        if r["status"] == "failed":
            failed_by_hour[h] += 1
        else:
            completed_by_hour[h] += 1

    return [
        HeartbeatBucket(
            hour=h,
            steps=steps_by_hour[h],
            failed=failed_by_hour[h],
            tier=_tier_for_ratio(
                failed_by_hour[h], completed_by_hour[h] + failed_by_hour[h],
            ),
        )
        for h in range(24)
    ]


_RECENT_ACTIVITY_KINDS = (
    "session_start", "completion_report", "review_verdict",
    "escalation", "escalation_resolved", "task_dispatched",
    "talk_started", "talk_ended", "learning_promoted",
)

# Free-string review-verdict vocabulary, normalized to its canonical spelling
# (lowercase, separators ``_``/``-`` collapsed to spaces). The established
# workflow spellings resolve case-insensitively and with benign
# whitespace/separator variation at the dashboard/pulse read boundaries.
_APPROVED_VERDICT_FORMS = frozenset({
    "approve", "approved", "accept", "ok", "pass",
})
_NON_APPROVED_VERDICT_FORMS = frozenset({
    "request changes", "revise", "reject", "rejected", "fail",
})


def normalize_review_verdict(
    raw: str | None,
) -> Literal["approve", "reject", "unknown"]:
    """Normalize a free-string review verdict to its dashboard family.

    Returns ``"approve"`` for the approval family (APPROVE / approved /
    approve / ACCEPT / accept / OK / ok / PASS / pass), ``"reject"`` for the
    non-approval family (REQUEST_CHANGES / request changes / request-changes /
    REVISE / REJECT / reject / rejected / FAIL / fail), and ``"unknown"`` for
    anything else — including an explicitly blank or unrecognized verdict,
    which is neither an approval tone nor an acceptance count.

    Legacy stored forms (``approved``, ``accept``, ``ok``, ``request_changes``,
    ``rejected``) remain compatible via the same separator folding.
    """
    if raw is None:
        return "unknown"
    key = " ".join(
        raw.strip().lower().replace("_", " ").replace("-", " ").split(),
    )
    if key in _APPROVED_VERDICT_FORMS:
        return "approve"
    if key in _NON_APPROVED_VERDICT_FORMS:
        return "reject"
    return "unknown"


def _verdict_from_payload(
    action: str, payload_json: str | None
) -> Literal["ok", "fail", "warn"] | None:
    """Extract a normalized verdict from an audit row's payload."""
    payload = json.loads(payload_json or "{}")
    if action == "completion_report":
        status = payload.get("status")
        if status == "completed":
            return "ok"
        if status == "failed":
            return "fail"
        if status == "blocked":
            return "warn"
    if action == "review_verdict":
        family = normalize_review_verdict(payload.get("verdict"))
        if family == "approve":
            return "ok"
        if family == "reject":
            return "fail"
        return None  # unknown / blank — no tone
    return None


def compute_recent_activity(db: Database, *, n: int = 6) -> list[ActivityRow]:
    """Last n audit rows of meaningful kinds, DESC by timestamp.

    Enriches thread-scoped entries (task_id starting with 'THR-') with
    ``_thread_dream_id`` from the threads table for dream-marker rendering
    (A4). Honest read — only adds the field when the thread has a stored
    ``composed_from_dream_id``.
    """
    placeholders = ",".join("?" * len(_RECENT_ACTIVITY_KINDS))
    rows = db.fetch_all_readonly(
        f"SELECT timestamp, task_id, agent, action, payload "
        f"FROM audit_log WHERE action IN ({placeholders}) "
        f"ORDER BY timestamp DESC LIMIT ?",
        (*_RECENT_ACTIVITY_KINDS, n),
    )
    if not rows:
        return []

    # Batch-resolve composed_from_dream_id for THR- task_ids
    thread_ids = [r["task_id"] for r in rows if r["task_id"] and r["task_id"].startswith("THR-")]
    dream_map: dict[str, str | None] = {}
    if thread_ids:
        t_placeholders = ",".join("?" * len(thread_ids))
        t_rows = db.fetch_all_readonly(
            f"SELECT id, composed_from_dream_id FROM threads WHERE id IN ({t_placeholders})",
            tuple(thread_ids),
        )
        dream_map = {
            r["id"]: r["composed_from_dream_id"] if "composed_from_dream_id" in r.keys() else None
            for r in t_rows
        }

    return [
        ActivityRow(
            timestamp=datetime.fromisoformat(r["timestamp"]),
            who=r["agent"],
            event_kind=r["action"],
            task_id=r["task_id"],
            verdict=_verdict_from_payload(r["action"], r["payload"]),
            thread_dream_id=dream_map.get(r["task_id"]) if r["task_id"] else None,
        )
        for r in rows
    ]


def compute_updates_this_week(
    db: Database, *, now: datetime, kb_store, n: int = 12
) -> list[UpdateRow]:
    """Combined feed for the last 7 days: KB entries created + learnings promoted.

    Sources (both honest per the design audit):
      - KB store filesystem (entries with created_at within 7d)
      - audit_log rows with action='learning_promoted' within 7d

    No tier-transition row type — the daemon doesn't audit tier changes yet.
    """
    week_start = now - timedelta(days=7)
    items: list[UpdateRow] = []

    # KB entries created this week (from the KB store, not audit_log).
    # Exclude operational artifact types that agents write for task-state
    # persistence — they are not knowledge contributions.
    _OPERATIONAL_KB_TYPES = {"driver-state", "state"}
    for entry in kb_store.list_entries_created_since(week_start):
        if entry.get("type") in _OPERATIONAL_KB_TYPES:
            continue
        ts = datetime.fromisoformat(entry["created_at"])
        items.append(UpdateRow(
            marker="add",
            text="KB +1",
            meta=entry["slug"],
            timestamp=ts,
        ))

    # Learnings promoted to KB this week
    rows = db.fetch_all_readonly(
        "SELECT timestamp, payload FROM audit_log "
        "WHERE action = 'learning_promoted' AND timestamp >= ? "
        "ORDER BY timestamp DESC",
        (week_start.isoformat(),),
    )
    for r in rows:
        payload = json.loads(r["payload"] or "{}")
        items.append(UpdateRow(
            marker="info",
            text="Learning promoted to KB",
            meta=payload.get("kb_slug", ""),
            timestamp=datetime.fromisoformat(r["timestamp"]),
        ))

    items.sort(key=lambda x: x.timestamp, reverse=True)
    return items[:n]


def classify_escalation_flavor(reason: str | None) -> str | None:
    """THR-037 Change B §G: derive a display sub-label for the single stored
    `escalated` status from the escalation audit reason — NO new stored status,
    NO new column. The three escalation paths all land in one `escalated`
    status; their flavor is recoverable losslessly from the reason text:

      - failure-recovery exhaustion ("failure-round bound (N) exhausted: …")
        → "exhausted"
      - orchestration-budget exhaustion ("max steps (N) exceeded") → "over-budget"
      - a genuine agent escalate (free-text reason) → "needs-decision"

    Best-effort / graceful: an absent or unrecognized-but-empty reason returns
    None so the surface falls back to plain "escalated" (never blanks the badge).
    """
    if not reason:
        return None
    low = reason.lower()
    if "failure-round bound" in low and "exhausted" in low:
        return "exhausted"
    if "max steps" in low and "exceeded" in low:
        return "over-budget"
    if "iteration_budget_exhausted" in low:
        return "budget-stopped"
    return "needs-decision"


def compute_escalations_open(db: Database, *, now: datetime) -> list[EscalationRow]:
    """Currently-escalated tasks with the question text from audit payload.

    Path B (THR-037 Change B): escalations are the stored top-level
    status='escalated' (block_kind cleared)."""
    rows = db.fetch_all_readonly(
        "SELECT id, assigned_agent, team, updated_at FROM tasks "
        "WHERE status = 'escalated' AND parent_task_id IS NULL "
        "ORDER BY updated_at DESC"
    )
    result: list[EscalationRow] = []
    for r in rows:
        episode_rows = db.get_escalation_episode_audit_tail(r["id"])
        current_escalation = next(
            (row for row in episode_rows if row.get("action") == "escalation"),
            None,
        )
        payload = (current_escalation or {}).get("payload") or {}
        stored_reason = payload.get("reason") or payload.get("question") or ""
        projected = derive_current_escalation_reason(
            task_status="escalated", audit_rows=episode_rows,
        )
        assert projected is not None
        reason = projected.primary or projected.secondary or stored_reason
        raised_value = (current_escalation or {}).get("timestamp") or r["updated_at"]
        raised = datetime.fromisoformat(raised_value)
        if raised.tzinfo is None:
            raised = raised.replace(tzinfo=timezone.utc)
        moment = now if now.tzinfo else now.replace(tzinfo=timezone.utc)
        age = int((moment - raised).total_seconds())
        result.append(EscalationRow(
            task_id=r["id"],
            agent=r["assigned_agent"],
            team=r["team"],
            question=reason,
            raised_at=raised,
            age_seconds=max(0, age),
            flavor=classify_escalation_flavor(reason),
            escalation_reason=projected,
        ))
    return result


# Tasks in the stored `escalated` status longer than this are "stale" — they
# look open but the follow-up work has almost certainly moved elsewhere (a
# thread ruling + fresh dispatch). Surfaced as a recurring visible metric so the
# backlog can never silently rot again (THR-018 tier #3, §3c). 24h sits at the
# low end of the spec's 24–48h window so a forgotten escalation shows up within
# a working day.
_STALE_ESCALATION_THRESHOLD_HOURS = 24


def compute_stale_escalations(
    db: Database, *, now: datetime, threshold_hours: int = _STALE_ESCALATION_THRESHOLD_HOURS,
) -> list[StaleEscalationRow]:
    """Tasks in the stored `escalated` status older than `threshold_hours`.

    Path B (THR-037 Change B): a delegating parent is now a healthy
    `in_progress` task, NOT a stale-blocked row, so the old delegated bucketing
    is dropped — only genuine open `escalated` items are stale-worthy.

    Age is measured from ``updated_at`` (the last transition, i.e. when the
    task entered the escalated state). Oldest first. Read-only aggregation."""
    cutoff = (now - timedelta(hours=threshold_hours)).isoformat()
    rows = db.fetch_all_readonly(
        "SELECT id, assigned_agent, team, updated_at FROM tasks "
        "WHERE status = 'escalated' AND parent_task_id IS NULL AND updated_at < ? "
        "ORDER BY updated_at ASC",
        (cutoff,),
    )
    moment = now if now.tzinfo else now.replace(tzinfo=timezone.utc)
    result: list[StaleEscalationRow] = []
    for r in rows:
        updated = datetime.fromisoformat(r["updated_at"])
        if updated.tzinfo is None:
            updated = updated.replace(tzinfo=timezone.utc)
        age = int((moment - updated).total_seconds())
        result.append(StaleEscalationRow(
            task_id=r["id"],
            agent=r["assigned_agent"],
            team=r["team"],
            age_seconds=max(0, age),
        ))
    return result


def compute_active_by_team(db: Database) -> list[ActiveByTeam]:
    """tasks with status='in_progress' grouped by team.

    Path B (THR-037 Change B, ratified #5): `in_progress` now also covers
    parked parents (block_kind delegated/blocked_on_job) — the founder's ruling
    is that a delegating parent IS in-progress, so it belongs in active-by-team."""
    rows = db.fetch_all_readonly(
        "SELECT team, id FROM tasks WHERE status = 'in_progress' "
        "ORDER BY team, updated_at DESC"
    )
    groups: dict[str, list[str]] = {}
    for r in rows:
        groups.setdefault(r["team"], []).append(r["id"])
    return [
        ActiveByTeam(team=team, count=len(ids), task_ids=ids[:10])
        for team, ids in sorted(groups.items())
    ]


def compute_pending_review_jobs(db: Database) -> list[PendingReviewJobRow]:
    """Current founder-gated jobs, newest first with an id tie-breaker."""
    rows = db.fetch_all_readonly(
        "SELECT id, task_id, agent_name, title, created_at FROM jobs "
        "WHERE status = 'pending' AND review_required = 1 "
        "ORDER BY created_at DESC, id DESC",
    )
    return [
        PendingReviewJobRow(
            id=row["id"],
            task_id=row["task_id"],
            agent_name=row["agent_name"],
            title=row["title"],
            created_at=row["created_at"],
        )
        for row in rows
    ]


def _acceptance_pct_for_window(
    db: Database, *, team: str, start: datetime, end: datetime,
) -> tuple[int, int]:
    """Return (approved_count, total_count) of review_verdict rows in window
    where the reviewed task belonged to `team`."""
    rows = db.fetch_all_readonly(
        "SELECT a.payload FROM audit_log a "
        "JOIN tasks t ON t.id = a.task_id "
        "WHERE a.action = 'review_verdict' "
        "  AND t.team = ? "
        "  AND a.timestamp >= ? AND a.timestamp < ?",
        (team, start.isoformat(), end.isoformat()),
    )
    approved = 0
    total = len(rows)
    for r in rows:
        payload = json.loads(r["payload"] or "{}")
        if normalize_review_verdict(payload.get("verdict")) == "approve":
            approved += 1
    return approved, total


def compute_org_pulse_7d(db: Database, *, now: datetime, teams) -> list[TeamPulse]:
    """Per-team 7d acceptance + trend + 12-week sparkline.

    `teams` duck-types TeamsRegistry: needs `.teams() -> list[str]` and
    `.manager_for_team(team) -> TeamManager(name, team, workers)`.
    """
    week_now_start = now - timedelta(days=7)
    week_prior_start = now - timedelta(days=14)

    result: list[TeamPulse] = []
    for team_name in teams.teams():
        mgr = teams.manager_for_team(team_name)
        # Current 7d
        approved_now, total_now = _acceptance_pct_for_window(
            db, team=team_name, start=week_now_start, end=now,
        )
        # Prior 7d (for trend delta)
        approved_prior, total_prior = _acceptance_pct_for_window(
            db, team=team_name, start=week_prior_start, end=week_now_start,
        )
        acceptance = int(round(100 * approved_now / total_now)) if total_now else 0
        prior_acc = int(round(100 * approved_prior / total_prior)) if total_prior else 0
        trend_delta = acceptance - prior_acc

        # 12-week sparkline (oldest first), each value in [0, 1]
        sparkline: list[float] = []
        for i in range(12, 0, -1):
            w_start = now - timedelta(days=i * 7)
            w_end = now - timedelta(days=(i - 1) * 7)
            approved, total = _acceptance_pct_for_window(
                db, team=team_name, start=w_start, end=w_end,
            )
            sparkline.append(approved / total if total else 0.0)

        result.append(TeamPulse(
            team=team_name,
            acceptance_pct=acceptance,
            trend_delta=trend_delta,
            sparkline=sparkline,
            members=len(mgr.workers),
            lead=mgr.name,
        ))
    return result


def compose_dashboard_summary(
    *, db: Database, kb_store, teams, now: datetime,
) -> DashboardSummaryResponse:
    """Top-level: run every aggregation, return the wire-shape response."""
    return DashboardSummaryResponse(
        heartbeat=compute_heartbeat_24h(db, now=now),
        narrative_counts=compute_narrative_counts_today(db, now=now, kb_store=kb_store),
        escalations=compute_escalations_open(db, now=now),
        pending_review_jobs=compute_pending_review_jobs(db),
        stale_escalations=compute_stale_escalations(db, now=now),
        active_by_team=compute_active_by_team(db),
        recent_activity=compute_recent_activity(db, n=6),
        updates_this_week=compute_updates_this_week(db, now=now, kb_store=kb_store, n=12),
        org_pulse=compute_org_pulse_7d(db, now=now, teams=teams),
        org_age_days=compute_org_age_days(db, now=now),
        server_now=now,
    )
