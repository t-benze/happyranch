"""File-based agent loader.

Reads agents from <runtime>/org/agents/<name>.md (active),
<runtime>/org/agents/_pending/<name>.md (awaiting approval), and
<runtime>/org/agents/_terminated/<name>.md (archived, read-only).
"""
from __future__ import annotations

import hashlib
import os
import tempfile
from pathlib import Path

from runtime.orchestrator._paths import OrgPaths
from runtime.orchestrator.agent_def import (
    AgentDef,
    AgentParseError,
    parse_agent_file,
    parse_agent_text,
    render_agent_text,
)


__all__ = [
    "AgentDef",
    "AgentParseError",
    "load_agent",
    "load_agent_with_revision",
    "load_agent_snapshot",
    "list_agents",
    "list_pending",
    "load_pending_agent",
    "write_pending_agent",
    "approve_agent",
    "reject_agent",
    "allow_rules_for_agent",
    "load_terminated_agent",
    "list_terminated",
    "is_terminated",
    "is_name_unavailable",
]


_TERMINATED_DIRNAME = "_terminated"


def _agent_path(paths: OrgPaths, name: str, *, pending: bool) -> Path:
    parent = paths.pending_agents_dir if pending else paths.agents_dir
    return parent / f"{name}.md"


def _terminated_agents_dir(paths: OrgPaths) -> Path:
    return paths.agents_dir / _TERMINATED_DIRNAME


def _terminated_agent_path(paths: OrgPaths, name: str) -> Path:
    return _terminated_agents_dir(paths) / f"{name}.md"


def load_agent(paths: OrgPaths, name: str) -> AgentDef | None:
    """Return the active agent, or None if missing.

    Pending agents are NOT returned by this function — use load_pending_agent.
    """
    loaded = load_agent_with_revision(paths, name)
    return loaded[0] if loaded is not None else None


def load_agent_with_revision(
    paths: OrgPaths, name: str,
) -> tuple[AgentDef, str] | None:
    """Load an active definition and its hash from the same byte snapshot."""
    snapshot = load_agent_snapshot(paths, name)
    return snapshot[:2] if snapshot is not None else None


def load_agent_snapshot(
    paths: OrgPaths, name: str,
) -> tuple[AgentDef, str, bytes] | None:
    """Load an active definition, revision, and exact canonical bytes together."""
    path = _agent_path(paths, name, pending=False)
    try:
        contents = path.read_bytes()
    except FileNotFoundError:
        return None
    return (
        # Match Path.read_text() universal-newline parsing without rereading or
        # changing the exact bytes used for the revision and compensation.
        parse_agent_text(
            contents.decode("utf-8").replace("\r\n", "\n").replace("\r", "\n"),
            expected_name=name,
        ),
        hashlib.sha256(contents).hexdigest(),
        contents,
    )


def agent_revision(paths: OrgPaths, name: str) -> str | None:
    """Return the exact-content revision for an active agent definition."""
    loaded = load_agent_with_revision(paths, name)
    return loaded[1] if loaded is not None else None


def load_pending_agent(paths: OrgPaths, name: str) -> AgentDef | None:
    path = _agent_path(paths, name, pending=True)
    if not path.exists():
        return None
    return parse_agent_file(path)


def _list_dir(directory: Path) -> list[AgentDef]:
    if not directory.exists():
        return []
    out: list[AgentDef] = []
    for entry in sorted(directory.iterdir()):
        if entry.is_file() and entry.suffix == ".md" and not entry.name.startswith("."):
            # A canonical entry can disappear after is_file() but before its
            # parser opens it.  Omit that transient roster entry instead of
            # failing the whole list response.
            try:
                out.append(parse_agent_file(entry))
            except FileNotFoundError:
                continue
    return out


def list_agents(paths: OrgPaths) -> list[AgentDef]:
    """All active agents under <runtime>/org/agents/ (excluding _pending/)."""
    return _list_dir(paths.agents_dir)


def list_pending(paths: OrgPaths) -> list[AgentDef]:
    return _list_dir(paths.pending_agents_dir)


def write_pending_agent(paths: OrgPaths, agent: AgentDef) -> Path:
    """Atomically write a pending agent file. Overwrites if the slug is reused."""
    paths.pending_agents_dir.mkdir(parents=True, exist_ok=True)
    target = _agent_path(paths, agent.name, pending=True)
    fd, tmp = tempfile.mkstemp(prefix=f".{agent.name}.", suffix=".md", dir=str(target.parent))
    try:
        with os.fdopen(fd, "w") as fh:
            fh.write(render_agent_text(agent))
        os.replace(tmp, target)
    except Exception:
        try:
            os.unlink(tmp)
        except FileNotFoundError:
            pass
        raise
    return target


def approve_agent(paths: OrgPaths, name: str) -> AgentDef:
    """Atomically move <name>.md from _pending/ to the active directory.

    Raises:
      FileNotFoundError: if no pending file exists.
      FileExistsError: if an active agent with the same name already exists
        (caller should resolve manually before retrying).
    """
    pending = _agent_path(paths, name, pending=True)
    if not pending.exists():
        raise FileNotFoundError(f"no pending agent: {name}")
    active = _agent_path(paths, name, pending=False)
    if active.exists():
        raise FileExistsError(f"active agent already exists: {name}")
    paths.agents_dir.mkdir(parents=True, exist_ok=True)
    os.replace(pending, active)
    return parse_agent_file(active)


def reject_agent(paths: OrgPaths, name: str) -> None:
    pending = _agent_path(paths, name, pending=True)
    if not pending.exists():
        raise FileNotFoundError(f"no pending agent: {name}")
    pending.unlink()


def load_terminated_agent(paths: OrgPaths, name: str) -> AgentDef | None:
    """Return the archived terminated agent, or None if not archived."""
    path = _terminated_agent_path(paths, name)
    if not path.exists():
        return None
    return parse_agent_file(path)


def list_terminated(paths: OrgPaths) -> list[AgentDef]:
    """All terminated agents under <runtime>/org/agents/_terminated/."""
    return _list_dir(_terminated_agents_dir(paths))


def is_terminated(paths: OrgPaths, name: str) -> bool:
    """True if an archived terminated agent file exists for ``name``."""
    return _terminated_agent_path(paths, name).exists()


def is_name_unavailable(paths: OrgPaths, name: str) -> bool:
    """True if ``name`` is pending, active, or terminated."""
    return (
        load_pending_agent(paths, name) is not None
        or load_agent(paths, name) is not None
        or is_terminated(paths, name)
    )


def allow_rules_for_agent(paths: OrgPaths, name: str) -> tuple[str, ...]:
    """Return the agent's declared Bash allow-rule prefixes (just the prefixes;
    Bash(...) wrapping is added by workspace_adapters._format_allow_rule).

    Returns () for an unknown agent.
    """
    agent = load_agent(paths, name)
    if agent is None:
        return ()
    return agent.allow_rules
