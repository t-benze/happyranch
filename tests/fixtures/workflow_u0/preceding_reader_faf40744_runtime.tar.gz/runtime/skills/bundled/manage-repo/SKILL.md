---
name: manage-repo
description: Add, remove, or update a repository in your AgentDef configuration (org/agents/<name>.md frontmatter). Write a JSON file and call happyranch manage-repo --from-file to keep the invocation single-line.
---

# manage-repo

Manage the repositories cloned into your `repos/` directory. You can **add** a new repo, **remove** an existing one, or **update** the URL of an existing repo (which deletes the old clone and re-clones from the new URL).

## Usage

1. **Write a JSON file** to `/tmp/manage-repo-<unique>.json` using the Write tool:

   **Add a repo:**
   ```json
   {
     "action": "add",
     "agent": "<your_agent_name>",
     "repo_name": "web-app",
     "url": "https://github.com/t-benze/web-app.git"
   }
   ```

   **Remove a repo:**
   ```json
   {
     "action": "remove",
     "agent": "<your_agent_name>",
     "repo_name": "web-app"
   }
   ```

   **Update a repo URL:**
   ```json
   {
     "action": "update",
     "agent": "<your_agent_name>",
     "repo_name": "web-app",
     "url": "https://github.com/t-benze/new-web-app.git"
   }
   ```

2. **Invoke as a single-line command:**

   ```bash
   happyranch manage-repo --org {ORG_SLUG} --from-file /tmp/manage-repo-<unique>.json
   ```

   The `--from-file` form is mandatory for agent sessions. In Claude sessions,
   multi-line bash commands are rejected by the `Bash(happyranch:*)` permission rule
   because newlines count as command separators.

## What happens

- **add**: writes the entry to your `org/agents/<name>.md` frontmatter (`AgentDef.repos`), clones the repo into `repos/<name>/` (or `git pull --ff-only` if a clone already exists), and refreshes executor workspace metadata. Repo freshness is daemon-side (THR-103): the session-spawn `refresh_workspace_repos` fast-forward-pull covers the new repo automatically — no per-workspace git-pull hook is emitted.
- **remove**: deletes the entry from your `org/agents/<name>.md` frontmatter, removes the `repos/<name>/` directory, and refreshes executor workspace metadata.
- **update**: updates the URL in your `org/agents/<name>.md` frontmatter, deletes the old clone, re-clones from the new URL, and refreshes executor workspace metadata.

## Error handling

- If `happyranch` returns non-zero, retry once after 1 second.
- `409` (duplicate repo on add) and `404` (repo not found on remove/update) are not retryable — check your `org/agents/<name>.md` frontmatter and adjust.
