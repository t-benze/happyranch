"""Workspace-to-canonical symlink materializer.

Atomic create-or-repair of workspace symlinks to canonical package targets.
Handles stale, broken, wrong-version, wrong-target, external/malicious,
ordinary-directory, and missing-canonical entries. Safe withdrawal preserves
canonical content while removing workspace links.

Fail-closed: any repair failure surfaces a named materialization error and
prevents executor launch.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from runtime.platform.isolation import (
    PlatformIsolation,
    PlatformIsolationError,
    detect_platform_isolation,
)
from runtime.skills.canonical_store import CanonicalSkillStore, CanonicalStoreError

logger = logging.getLogger("happyranch.skills.symlink_materializer")


class SymlinkMaterializationError(Exception):
    """Raised when workspace link materialization fails.

    Terminal — no executor launch proceeds.
    """

    def __init__(self, code: str, detail: str) -> None:
        self.code = code
        self.detail = detail
        super().__init__(f"[{code}] {detail}")


class SymlinkMaterializer:
    """Creates, repairs, and withdraws workspace symlinks to canonical packages.

    Every expected skill is resolved to its canonical path first. Then:
    - If the workspace link is a valid symlink to the correct canonical target:
      no-op (idempotent).
    - If the link is missing, stale, broken, wrong-target, external, or an
      ordinary directory: atomically remove the old entry and create a fresh
      relative symlink.
    - If the canonical target doesn't exist or is invalid: fail-closed.

    Safe withdrawal: removes workspace links without deleting canonical content.
    Poisoned repair: if repair fails for any reason, the entire materialization
    fails and no executor launches.
    """

    def __init__(
        self,
        store: CanonicalSkillStore,
        isolation: Optional[PlatformIsolation] = None,
    ) -> None:
        self._store = store
        self._isolation = isolation or detect_platform_isolation()

    def materialize_skill(
        self,
        skill_slug: str,
        version: str,
        content_hash: str,
        workspace: Path,
        skills_subdir: str,  # ".claude/skills" or ".agents/skills"
        *,
        canonical_root: Optional[Path] = None,
    ) -> None:
        """Ensure a workspace symlink exists pointing to the canonical package.

        Steps:
        1. Verify canonical package exists and is non-empty.
        2. Resolve workspace link path: <workspace>/<skills_subdir>/<skill_slug>
        3. Compute relative target from link to canonical package dir.
        4. If existing link is valid → no-op.
        5. If existing entry is wrong/broken/stale → safely remove and recreate.
        6. Create validated relative symlink.

        Args:
            skill_slug: Skill directory name
            version: Package version
            content_hash: Content hash identifying the canonical package
            workspace: Agent workspace root
            skills_subdir: Provider-specific skills directory (e.g. ".claude/skills")
            canonical_root: Override canonical store root (for testing)

        Raises:
            SymlinkMaterializationError: on canonical missing, repair failure,
                or malicious entry.
        """
        # Verify canonical package
        try:
            self._store.verify_package(skill_slug, version, content_hash)
        except CanonicalStoreError as exc:
            raise SymlinkMaterializationError(
                "canonical_missing",
                f"Cannot materialize {skill_slug}@{version}: {exc}",
            ) from exc

        canonical_target = self._store.canonical_path(skill_slug, version, content_hash)
        croot = canonical_root or self._store.root
        link_path = workspace / skills_subdir / skill_slug

        # THR-190 PR-B containment: no-follow admission of the provider /
        # nested skills root BEFORE any verify/no-op or write. A pre-
        # positioned symlink at the workspace level (e.g. ``.claude``), the
        # provider root (``.claude/skills`` / ``.agents/skills``), or any
        # nested component is refused — the daemon must never follow an
        # attacker-controlled parent out of the real workspace. The
        # lowest-level link writer re-enforces the same containment
        # immediately before link creation/replacement (defense in depth).
        try:
            fd = self._isolation.admit_skills_directory(
                link_path.parent, workspace_root=workspace,
            )
            if fd is not None:
                # Validation-only admission: the write itself is re-admitted
                # by the lowest-level writer. Nothing is enumerated here.
                os.close(fd)
        except PlatformIsolationError as exc:
            raise SymlinkMaterializationError(
                getattr(exc, "code", None) or "escaped_parent",
                f"Workspace skills root {link_path.parent} refused: {exc}",
            ) from exc

        # Relative target from link to canonical
        try:
            rel_target = Path(os.path.relpath(canonical_target, link_path.parent))
        except ValueError:
            raise SymlinkMaterializationError(
                "relpath_failed",
                f"Cannot compute relative path from {link_path.parent} to {canonical_target}",
            )

        # Check existing entry
        if link_path.exists(follow_symlinks=False):
            if link_path.is_symlink():
                if self._isolation.verify_workspace_link(
                    link_path, canonical_target, croot,
                ):
                    # Already valid — no-op
                    logger.debug(
                        "Workspace link %s → %s already valid",
                        link_path, canonical_target,
                    )
                    return
            elif link_path.is_dir():
                # Ordinary directory at expected link path — hostile state.
                # Must NEVER recursively delete attacker-controlled content.
                # This is a named materialization failure — no executor
                # launch proceeds.
                raise SymlinkMaterializationError(
                    "ordinary_dir_at_link_path",
                    f"Expected symlink at {link_path} but found ordinary directory. "
                    "Refusing to delete — remove manually or use withdraw_skill first "
                    "after verifying the directory does not contain real work.",
                )

        # Create/replace the link ATOMICALLY. The lowest-level link writer
        # performs the write through a no-follow, pinned parent dirfd inside
        # the real workspace: it re-verifies resolved-parent containment
        # immediately before publication and swaps via temp symlink +
        # os.replace so concurrent readers never see a gap (a bare unlink() +
        # symlink() leaves OSError: Invalid argument in between).
        try:
            self._isolation.create_relative_symlink(
                rel_target, link_path, workspace_root=workspace,
            )
            logger.info(
                "Created workspace link %s → %s", link_path, rel_target,
            )
        except SymlinkMaterializationError:
            raise
        except PlatformIsolationError as exc:
            raise SymlinkMaterializationError(
                getattr(exc, "code", None) or "link_creation_failed",
                f"Failed to create symlink {link_path} → {rel_target}: {exc}",
            ) from exc
        except OSError as exc:
            raise SymlinkMaterializationError(
                "link_creation_failed",
                f"Failed to replace symlink {link_path}: {exc}",
            ) from exc

    def withdraw_skill(
        self,
        skill_slug: str,
        workspace: Path,
        skills_subdir: str,
    ) -> None:
        """Safely remove a workspace symlink for a withdrawn/retired skill.

        Does NOT delete canonical content — only removes the workspace link.
        Before removal, verifies the entry is actually a symlink (not an
        ordinary directory with real content).

        Args:
            skill_slug: Skill directory name to remove
            workspace: Agent workspace root
            skills_subdir: Provider-specific skills directory

        Raises:
            SymlinkMaterializationError: if the entry is an ordinary directory
                (possibly containing real data that must not be deleted).
        """
        link_path = workspace / skills_subdir / skill_slug
        # THR-190 PR-B containment: the withdrawal happens through the
        # lowest-level link writer, which performs no-follow admission of
        # the parent chain (rejecting pre-positioned symlinked roots) and
        # unlinks through a pinned no-follow parent dirfd — a symlink swap
        # or escaped parent can never redirect the unlink outside the real
        # workspace.
        try:
            self._isolation.withdraw_workspace_link(
                link_path, workspace_root=workspace,
            )
            logger.info("Withdrew workspace link: %s", link_path)
        except PlatformIsolationError as exc:
            raise SymlinkMaterializationError(
                getattr(exc, "code", None) or "withdraw_failed",
                f"Failed to withdraw link {link_path}: {exc}",
            ) from exc

    def materialize_skills_batch(
        self,
        specs: list[dict],
        workspace: Path,
        skills_subdir: str,
    ) -> list[str]:
        """Materialize a batch of skill specs, returning list of materialized slugs.

        Each spec is a dict with keys: slug, version, content_hash.
        Fail-closed: if any materialization fails, the error propagates.
        """
        materialized: list[str] = []
        for spec in specs:
            self.materialize_skill(
                skill_slug=spec["slug"],
                version=spec["version"],
                content_hash=spec["content_hash"],
                workspace=workspace,
                skills_subdir=skills_subdir,
            )
            materialized.append(spec["slug"])
        return materialized

    def repair_workspace_skills(
        self,
        expected_specs: list[dict],
        workspace: Path,
        skills_subdir: str,
    ) -> tuple[list[str], list[str]]:
        """Materialize expected skills AND withdraw unexpected ones.

        Reconciles the workspace's managed skills directory against the
        expected set. Expected specs are materialized (created or repaired).
        Existing entries NOT in the expected set are safely withdrawn.

        Returns (materialized_slugs, withdrawn_slugs).

        Fail-closed: any failure raises, and partial repairs may leave the
        workspace in an intermediate state — but the error prevents executor
        launch (the fail-closed guarantee).
        """
        skills_dir = workspace / skills_subdir
        expected_slugs = {spec["slug"] for spec in expected_specs}

        # THR-190 PR-B containment: no-follow admission of the provider /
        # nested skills root returns the ADMITTED directory fd, retained open,
        # and the skills root is enumerated ONLY through that fd — the full
        # pathname is never re-resolved after admission. A same-UID swap of an
        # already-admitted ancestor at the post-admission/pre-listing seam
        # cannot redirect the listing to an external directory; the resulting
        # materialize/withdraw mutations are bound to the lowest-level
        # writer's re-admission (fail closed ``escaped_parent``). ``None``
        # means a fresh workspace (skills dir or an ancestor missing) —
        # nothing to list.
        existing_slugs: set[str] = set()
        try:
            skills_dir_fd = self._isolation.admit_skills_directory(
                skills_dir, workspace_root=workspace,
            )
        except PlatformIsolationError as exc:
            raise SymlinkMaterializationError(
                getattr(exc, "code", None) or "escaped_parent",
                f"Workspace skills root {skills_dir} refused: {exc}",
            ) from exc
        try:
            if skills_dir_fd is not None:
                with os.scandir(skills_dir_fd) as it:
                    for entry in it:
                        if entry.name.startswith(".tmp."):
                            continue  # Stale temp dirs from crashed materialization
                        existing_slugs.add(entry.name)
        finally:
            if skills_dir_fd is not None:
                os.close(skills_dir_fd)

        # Materialize expected
        materialized: list[str] = []
        for spec in expected_specs:
            self.materialize_skill(
                skill_slug=spec["slug"],
                version=spec["version"],
                content_hash=spec["content_hash"],
                workspace=workspace,
                skills_subdir=skills_subdir,
            )
            materialized.append(spec["slug"])

        # Withdraw unexpected (safely)
        withdrawn: list[str] = []
        to_withdraw = existing_slugs - expected_slugs
        for slug in sorted(to_withdraw):
            self.withdraw_skill(slug, workspace, skills_subdir)
            withdrawn.append(slug)

        return materialized, withdrawn


# Convenience import
import os  # noqa: E402 (used in relpath call above)
