from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from importlib import resources
from importlib.resources.abc import Traversable
from pathlib import Path
import os
import shutil

import yaml

from pydantic import BaseModel, ConfigDict, Field, ValidationError, model_validator


class AssistantState(StrEnum):
    UNINITIALIZED = "uninitialized"
    CONFIGURED = "configured"
    STALE_OR_BROKEN = "stale_or_broken"


@dataclass(frozen=True)
class SystemAssistantPaths:
    root: Path
    config_path: Path
    workspace: Path
    knowledge_dir: Path
    learnings_dir: Path
    logs_dir: Path


class AssistantConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    selected_executor: str
    selected_command: str
    selected_argv: list[str] = Field(default_factory=list)
    workspace_path: str

    @model_validator(mode="after")
    def _normalize(self) -> AssistantConfig:
        if not self.selected_executor.strip():
            raise ValueError("selected_executor must be a non-empty string")
        if not self.selected_argv:
            self.selected_argv = [self.selected_command]
        return self


class AssistantStatus(BaseModel):
    state: AssistantState
    selected_executor: str | None = None
    workspace_path: str | None = None
    detail: str | None = None


def system_assistant_paths(runtime_root: Path) -> SystemAssistantPaths:
    root = runtime_root / "system" / "assistant"
    workspace = root / "workspace"
    return SystemAssistantPaths(
        root=root,
        config_path=root / "config.json",
        workspace=workspace,
        knowledge_dir=workspace / "happyranch",
        learnings_dir=workspace / "learnings",
        logs_dir=workspace / "logs",
    )


def _managed_dir_entries(paths: SystemAssistantPaths) -> list[tuple[Path, str]]:
    return [
        (paths.root.parent, "assistant system directory"),
        (paths.root, "assistant root"),
        (paths.workspace, "assistant workspace"),
        (paths.knowledge_dir, "assistant knowledge directory"),
        (paths.learnings_dir, "assistant learnings directory"),
        (paths.logs_dir, "assistant logs directory"),
    ]


def _managed_dir_detail(
    paths: SystemAssistantPaths,
    *,
    require_exists: bool,
) -> str | None:
    for path, label in _managed_dir_entries(paths):
        if path.is_symlink():
            return f"{label} must not be a symlink"
        if not path.exists():
            if require_exists:
                return f"{label} is missing"
            continue
        if not path.is_dir():
            return f"{label} is not a directory"
    return None


def load_assistant_config(runtime_root: Path) -> AssistantConfig | None:
    paths = system_assistant_paths(runtime_root)
    managed_detail = _managed_dir_existing_invalid_detail(paths)
    if managed_detail is not None:
        raise ValueError(managed_detail)
    path = paths.config_path
    if path.is_symlink():
        raise ValueError("assistant config must not be a symlink")
    if not path.exists():
        return None
    if not path.is_file():
        raise ValueError("assistant config must be a regular file")
    return AssistantConfig.model_validate_json(path.read_text())


def _managed_dir_existing_invalid_detail(paths: SystemAssistantPaths) -> str | None:
    return _managed_dir_detail(paths, require_exists=False)


def _managed_dir_invalid_detail(paths: SystemAssistantPaths) -> str | None:
    return _managed_dir_detail(paths, require_exists=True)


def _is_canonical_claude_instruction_link(path: Path) -> bool:
    """True when *path* is the raw relative ``CLAUDE.md -> AGENTS.md`` link.

    THR-262 Slice B: the assistant instruction pair admits exactly this one
    same-workspace relative link whose target is a regular file; the generic
    symlink rejection for every other path is unchanged.
    """
    import stat as _stat

    target = path.parent / "AGENTS.md"
    try:
        if os.readlink(path) != "AGENTS.md":
            return False
        if not _stat.S_ISREG(os.lstat(target).st_mode):
            return False
        return os.path.realpath(path) == os.path.realpath(target)
    except OSError:
        return False


def _bootstrap_file_invalid_detail(
    path: Path, filename: str, *, allow_canonical_link: bool = False,
) -> str | None:
    if path.is_symlink():
        if (
            allow_canonical_link
            and filename == "CLAUDE.md"
            and _is_canonical_claude_instruction_link(path)
        ):
            return None
        return f"assistant bootstrap file {filename} must not be a symlink"
    if not path.exists():
        return f"assistant bootstrap file {filename} is missing"
    if not path.is_file():
        return f"assistant bootstrap file {filename} is not a regular file"
    return None


def _learnings_index_invalid_detail(path: Path) -> str | None:
    if path.is_symlink():
        return "assistant learnings index must not be a symlink"
    if not path.exists():
        return None
    if not path.is_file():
        return "assistant learnings index is not a regular file"
    return None


def _knowledge_index_invalid_detail(path: Path) -> str | None:
    if path.is_symlink():
        return "assistant knowledge index must not be a symlink"
    if not path.exists():
        return "assistant knowledge index is missing"
    if not path.is_file():
        return "assistant knowledge index is not a regular file"
    return None


def _ensure_managed_dir(path: Path, symlink_detail: str, non_dir_detail: str) -> None:
    if path.is_symlink():
        raise ValueError(symlink_detail)
    if path.exists() and not path.is_dir():
        raise ValueError(non_dir_detail)
    path.mkdir(parents=True, exist_ok=True)
    if path.is_symlink():
        raise ValueError(symlink_detail)
    if not path.is_dir():
        raise ValueError(non_dir_detail)


def save_assistant_config(runtime_root: Path, config: AssistantConfig) -> None:
    paths = system_assistant_paths(runtime_root)
    managed_detail = _managed_dir_existing_invalid_detail(paths)
    if managed_detail is not None:
        raise ValueError(managed_detail)
    if paths.config_path.is_symlink():
        raise ValueError("assistant config must not be a symlink")
    if paths.config_path.exists() and not paths.config_path.is_file():
        raise ValueError("assistant config must be a regular file")
    _ensure_managed_dir(
        paths.root.parent,
        "assistant system directory must not be a symlink",
        "assistant system directory is not a directory",
    )
    _ensure_managed_dir(
        paths.root,
        "assistant root must not be a symlink",
        "assistant root is not a directory",
    )
    paths.config_path.write_text(config.model_dump_json(indent=2) + "\n")


def classify_assistant_state(runtime_root: Path) -> AssistantStatus:
    paths = system_assistant_paths(runtime_root)
    managed_existing_invalid_detail = _managed_dir_existing_invalid_detail(paths)
    if managed_existing_invalid_detail is not None:
        return AssistantStatus(
            state=AssistantState.STALE_OR_BROKEN,
            detail=managed_existing_invalid_detail,
        )
    try:
        config = load_assistant_config(runtime_root)
    except (OSError, UnicodeDecodeError, ValueError, ValidationError):
        return AssistantStatus(
            state=AssistantState.STALE_OR_BROKEN,
            detail="assistant config is invalid",
        )
    if config is None:
        return AssistantStatus(state=AssistantState.UNINITIALIZED)
    try:
        configured_workspace = (
            Path(config.workspace_path).expanduser().resolve(strict=False)
        )
        expected_workspace = paths.workspace.resolve(strict=False)
    except (OSError, RuntimeError, ValueError):
        return AssistantStatus(
            state=AssistantState.STALE_OR_BROKEN,
            detail="assistant config is invalid",
        )
    if configured_workspace != expected_workspace:
        return AssistantStatus(
            state=AssistantState.STALE_OR_BROKEN,
            selected_executor=config.selected_executor,
            workspace_path=config.workspace_path,
            detail="assistant workspace path does not match runtime",
        )
    if not config.selected_argv or not config.selected_argv[0]:
        return AssistantStatus(
            state=AssistantState.STALE_OR_BROKEN,
            selected_executor=config.selected_executor,
            workspace_path=config.workspace_path,
            detail="assistant selected command is empty",
        )
    if shutil.which(config.selected_argv[0]) is None:
        return AssistantStatus(
            state=AssistantState.STALE_OR_BROKEN,
            selected_executor=config.selected_executor,
            workspace_path=config.workspace_path,
            detail=f"assistant selected command not found: {config.selected_argv[0]}",
        )
    managed_invalid_detail = _managed_dir_invalid_detail(paths)
    if managed_invalid_detail is not None:
        return AssistantStatus(
            state=AssistantState.STALE_OR_BROKEN,
            selected_executor=config.selected_executor,
            workspace_path=config.workspace_path,
            detail=managed_invalid_detail,
        )
    agent_invalid_detail = _bootstrap_file_invalid_detail(
        paths.workspace / "agent.yaml",
        "agent.yaml",
    )
    if agent_invalid_detail is not None:
        return AssistantStatus(
            state=AssistantState.STALE_OR_BROKEN,
            selected_executor=config.selected_executor,
            workspace_path=config.workspace_path,
            detail=(
                "assistant agent.yaml is missing"
                if agent_invalid_detail == "assistant bootstrap file agent.yaml is missing"
                else agent_invalid_detail
            ),
        )
    # THR-262 Slice B: validate the canonical instruction pair for BOTH
    # executor families — regular AGENTS.md plus a raw relative
    # CLAUDE.md -> AGENTS.md resolving to it.
    from runtime.orchestrator.workspace_adapters import instruction_pair_refusal

    pair_refusal = instruction_pair_refusal(paths.workspace)
    if pair_refusal is not None:
        return AssistantStatus(
            state=AssistantState.STALE_OR_BROKEN,
            selected_executor=config.selected_executor,
            workspace_path=config.workspace_path,
            detail=f"assistant instruction pair is not canonical: {pair_refusal}",
        )
    learnings_index_invalid_detail = _learnings_index_invalid_detail(
        paths.learnings_dir / "_index.md",
    )
    if learnings_index_invalid_detail is not None:
        return AssistantStatus(
            state=AssistantState.STALE_OR_BROKEN,
            selected_executor=config.selected_executor,
            workspace_path=config.workspace_path,
            detail=learnings_index_invalid_detail,
        )
    knowledge_index_invalid_detail = _knowledge_index_invalid_detail(
        paths.knowledge_dir / "README.md",
    )
    if knowledge_index_invalid_detail is not None:
        return AssistantStatus(
            state=AssistantState.STALE_OR_BROKEN,
            selected_executor=config.selected_executor,
            workspace_path=config.workspace_path,
            detail=knowledge_index_invalid_detail,
        )
    return AssistantStatus(
        state=AssistantState.CONFIGURED,
        selected_executor=config.selected_executor,
        workspace_path=config.workspace_path,
    )


def _validate_executor(executor: str) -> str:
    value = executor.strip()
    if not value:
        raise ValueError("assistant executor must be a non-empty string")
    return value


def _assistant_prompt() -> str:
    return """# System Assistant

You are the HappyRanch system assistant. Help the founder operate HappyRanch itself:
setup, protocol explanation, runtime health, executor diagnosis, org discovery, and
guided next actions.

Authority boundary:
- Explain, inspect, and diagnose freely.
- Recommend next actions clearly.
- Run mutating HappyRanch commands only after explicit user confirmation.
- Do not silently edit runtime config, org definitions, agent files, or teams.
- Do not act as an org agent, team member, manager, or task worker.

Knowledge:
- Start with `happyranch/README.md` in this workspace.
- Use the copied HappyRanch guides under `happyranch/docs/`, `happyranch/runtime/skills/bundled/`,
  and `happyranch/skills/` as your local source of truth.
- Prefer `happyranch` CLI commands when inspecting or changing a runtime.
"""


def _registration_prompt() -> str:
    return """# Register as the HappyRanch System Assistant

You have been opened in the HappyRanch system assistant workspace, but no
assistant is configured yet. Register yourself so HappyRanch can re-launch you
for future sessions.

Steps:
1. Write a JSON file (for example `register.json`) in this workspace with:
   {
     "executor": "<your CLI name, e.g. claude>",
     "command": "<the command that launches you, e.g. claude>",
     "argv": ["<command>", "<any>", "<args>"]
   }
2. Run this exact single-line command:
   happyranch assistant register --from-file register.json

After registration succeeds, this file is replaced with your operating
instructions.
"""


def _write_assistant_instruction_pair(workspace: Path, prompt: str) -> None:
    """Converge the assistant instruction pair through the shared writer.

    THR-262 Slice B: both assistant registration and bootstrap must use the
    already-approved canonical instruction-pair classifier/writer so divergent
    regular ``AGENTS.md``/``CLAUDE.md`` bytes are never overwritten or unlinked
    without a verified preservation copy, links are never written through, and
    the pair-wide preservation barrier precedes either mutation. The shared
    writer's ``InstructionPairConflict`` is surfaced as ``ValueError`` so the
    assistant routes keep their documented ``assistant_workspace_invalid``
    error contract.
    """
    from runtime.orchestrator.workspace_adapters import (
        InstructionPairConflict,
        write_canonical_instruction_pair,
    )

    try:
        write_canonical_instruction_pair(workspace, prompt)
    except InstructionPairConflict as exc:
        raise ValueError(str(exc)) from exc


def prepare_assistant_registration_workspace(runtime_root: Path) -> None:
    paths = system_assistant_paths(runtime_root)
    _reject_symlink(
        paths.root.parent,
        "assistant system directory must not be a symlink",
    )
    _reject_symlink(paths.root, "assistant root must not be a symlink")
    _reject_symlink(paths.workspace, "assistant workspace must not be a symlink")
    _reject_existing_invalid_bootstrap_file(
        paths.workspace / "AGENTS.md",
        "AGENTS.md",
    )
    _reject_existing_invalid_bootstrap_file(
        paths.workspace / "CLAUDE.md",
        "CLAUDE.md",
    )
    _ensure_managed_dir(
        paths.root.parent,
        "assistant system directory must not be a symlink",
        "assistant system directory is not a directory",
    )
    _ensure_managed_dir(
        paths.root,
        "assistant root must not be a symlink",
        "assistant root is not a directory",
    )
    _ensure_managed_dir(
        paths.workspace,
        "assistant workspace must not be a symlink",
        "assistant workspace is not a directory",
    )
    prompt = _registration_prompt()
    _write_assistant_instruction_pair(paths.workspace, prompt)


def clear_assistant_config(runtime_root: Path) -> None:
    paths = system_assistant_paths(runtime_root)
    if paths.config_path.is_symlink():
        raise ValueError("assistant config must not be a symlink")
    paths.config_path.unlink(missing_ok=True)


def _reject_symlink(path: Path, detail: str) -> None:
    if path.is_symlink():
        raise ValueError(detail)


def _reject_existing_invalid_bootstrap_file(path: Path, filename: str) -> None:
    invalid_detail = _bootstrap_file_invalid_detail(
        path, filename, allow_canonical_link=(filename == "CLAUDE.md"),
    )
    if invalid_detail is None or invalid_detail.endswith(" is missing"):
        return
    raise ValueError(invalid_detail)


_KNOWLEDGE_SOURCES = [
    ("README.md", "README.md"),
    ("docs/agent-guides/project-layout.md", "docs/agent-guides/project-layout.md"),
    (
        "docs/agent-guides/runtime-and-configuration.md",
        "docs/agent-guides/runtime-and-configuration.md",
    ),
    (
        "docs/agent-guides/agent-executors-and-permissions.md",
        "docs/agent-guides/agent-executors-and-permissions.md",
    ),
    (
        "docs/agent-guides/orchestrator-contracts.md",
        "docs/agent-guides/orchestrator-contracts.md",
    ),
    ("docs/agent-guides/web-and-cli.md", "docs/agent-guides/web-and-cli.md"),
    (
        "docs/agent-guides/features-and-invariants.md",
        "docs/agent-guides/features-and-invariants.md",
    ),
    ("skills/happyranch/SKILL.md", "skills/happyranch/SKILL.md"),
]
_KNOWLEDGE_PACKAGE = "runtime.system_knowledge"
_BUNDLED_KNOWLEDGE_SKILLS = ("reflection", "jobs")
_ASSISTANT_SKILL_CONTEXTS = (
    "task",
    "thread",
    "wake",
    "dream",
    "schedule",
    "bootstrap",
)
_ASSISTANT_SKILL_SLUGS = frozenset(
    {"dream", "jobs", "start-task", "thread", "todos", "workspace-cleanup"}
)
_SOURCE_ROOT_MARKERS = (
    "pyproject.toml",
    "docs/agent-guides/runtime-and-configuration.md",
    "runtime/config.py",
)


def _packaged_knowledge_root() -> Traversable | None:
    try:
        root = resources.files(_KNOWLEDGE_PACKAGE)
    except ModuleNotFoundError:
        return None
    if all((root / source_rel).is_file() for source_rel, _ in _KNOWLEDGE_SOURCES):
        return root
    return None


def _source_knowledge_root() -> Path:
    root = Path(__file__).resolve().parent.parent
    if all((root / marker).is_file() for marker in _SOURCE_ROOT_MARKERS):
        return root
    raise ValueError("assistant knowledge sources are unavailable")


def _knowledge_source_root() -> Path | Traversable:
    return _packaged_knowledge_root() or _source_knowledge_root()


def _ensure_safe_child_parent(base: Path, path: Path) -> None:
    try:
        relative_parent = path.parent.relative_to(base)
    except ValueError as exc:
        raise ValueError("assistant knowledge path escapes knowledge directory") from exc
    if any(part == ".." for part in relative_parent.parts):
        raise ValueError("assistant knowledge path escapes knowledge directory")
    if base.is_symlink():
        raise ValueError("assistant knowledge directory must not be a symlink")
    current = base
    for part in relative_parent.parts:
        current = current / part
        if current.is_symlink():
            raise ValueError("assistant knowledge directory must not be a symlink")
        if current.exists() and not current.is_dir():
            raise ValueError("assistant knowledge parent is not a directory")
        current.mkdir(exist_ok=True)
        if current.is_symlink():
            raise ValueError("assistant knowledge directory must not be a symlink")
    base_resolved = base.resolve(strict=True)
    parent_resolved = path.parent.resolve(strict=True)
    if not parent_resolved.is_relative_to(base_resolved):
        raise ValueError("assistant knowledge path escapes knowledge directory")


def _write_file(
    path: Path,
    content: str,
    *,
    base: Path,
    symlink_detail: str,
) -> None:
    _ensure_safe_child_parent(base, path)
    _reject_symlink(path, symlink_detail)
    if path.exists() and not path.is_file():
        raise ValueError(f"assistant knowledge file is not a regular file: {path.name}")
    path.write_text(content)


def _copy_knowledge_file(source: Path | Traversable, destination: Path, *, base: Path) -> bool:
    if not source.is_file():
        return False
    _write_file(
        destination,
        source.read_bytes().decode("utf-8", errors="replace"),
        base=base,
        symlink_detail="assistant knowledge file must not be a symlink",
    )
    return True


def _write_knowledge_pack(paths: SystemAssistantPaths) -> None:
    _reject_symlink(
        paths.knowledge_dir,
        "assistant knowledge directory must not be a symlink",
    )
    _ensure_managed_dir(
        paths.knowledge_dir,
        "assistant knowledge directory must not be a symlink",
        "assistant knowledge directory is not a directory",
    )
    root = _knowledge_source_root()
    copied: list[str] = []
    missing: list[str] = []
    from runtime.skills.sources import bundled_skills_dir

    # Reference copies come from the same release-owned assets as org skills.
    # Do not package a second source tree or use assistant copies for launches.
    sources = [(root / source_rel, dest_rel) for source_rel, dest_rel in _KNOWLEDGE_SOURCES]
    sources.extend(
        (bundled_skills_dir() / slug / "SKILL.md", f"runtime/skills/bundled/{slug}/SKILL.md")
        for slug in _BUNDLED_KNOWLEDGE_SKILLS
    )
    for source, dest_rel in sources:
        destination = paths.knowledge_dir / dest_rel
        if _copy_knowledge_file(source, destination, base=paths.knowledge_dir):
            copied.append(dest_rel)
        else:
            missing.append(dest_rel)
    index = "\n".join(
        [
            "# HappyRanch System Assistant Knowledge",
            "",
            "This directory is a local, runtime-global knowledge pack for the",
            "HappyRanch system assistant. Use these files before answering",
            "questions about HappyRanch setup, protocol, runtime layout, CLI",
            "commands, agent execution, orchestration, knowledge base behavior,",
            "threads, jobs, artifacts, and callbacks.",
            "",
            "Core facts:",
            "- HappyRanch is a multi-agent organization runtime supervised by a founder.",
            "- Runtime containers use schema v2: `<runtime>/orgs/<slug>/...`.",
            "- The system assistant is runtime-global under `<runtime>/system/assistant/`.",
            "- Org agents are discovered from `org/agents/*.md`; the system assistant is not an org agent.",
            "- Prefer the `happyranch` CLI for runtime side effects.",
            "",
            "Read first:",
            "- `docs/agent-guides/runtime-and-configuration.md`",
            "- `docs/agent-guides/web-and-cli.md`",
            "- `docs/agent-guides/agent-executors-and-permissions.md`",
            "- `docs/agent-guides/project-layout.md`",
            "- `skills/happyranch/SKILL.md`",
            "",
            "Copied files:",
            *[f"- `{name}`" for name in copied],
            "",
            "Missing source files at bootstrap time:",
            *([f"- `{name}`" for name in missing] if missing else ["- None"]),
            "",
        ]
    )
    _write_file(
        paths.knowledge_dir / "README.md",
        index,
        base=paths.knowledge_dir,
        symlink_detail="assistant knowledge index must not be a symlink",
    )


def _preflight_assistant_skills(workspace: Path, settings: object) -> None:
    """Read-only validation before assistant workspace bootstrap writes.

    The shared materializer intentionally permits intermediate repairs when a
    later entry refuses. The assistant bootstrap has a stronger transaction
    boundary: inspect the complete six-skill set, both discovery roots, and
    every already-published canonical package before changing the workspace.
    """
    from runtime.orchestrator.workspace_adapters import (
        _compute_dir_hash,
        _preflight_system_contract_sources,
        _resolve_skills_src,
    )
    from runtime.platform.isolation import (
        PlatformIsolationError,
        detect_platform_isolation,
    )
    from runtime.skills.canonical_store import (
        CanonicalSkillStore,
        CanonicalStoreError,
        _get_canonical_store_root,
    )
    from runtime.skills.symlink_materializer import SymlinkMaterializationError
    from runtime.skills.system_contracts import (
        SessionContext,
        resolve_system_contracts_for_session,
    )

    contracts_by_id: dict[str, object] = {}
    for context_name in _ASSISTANT_SKILL_CONTEXTS:
        context = SessionContext(context_name)
        for contract in resolve_system_contracts_for_session(
            context, workspace=workspace,
        ):
            contracts_by_id.setdefault(contract.id, contract)

    actual_slugs = frozenset(contracts_by_id)
    if actual_slugs != _ASSISTANT_SKILL_SLUGS:
        raise SymlinkMaterializationError(
            "assistant_skill_set_mismatch",
            "Assistant system-contract union must be exactly "
            f"{sorted(_ASSISTANT_SKILL_SLUGS)}; got {sorted(actual_slugs)}",
        )

    source_root = _resolve_skills_src(settings)
    _preflight_system_contract_sources(
        set(actual_slugs),
        source_root,
        workspace=workspace,
        provider="system-assistant",
    )
    specs: list[dict[str, str]] = []
    for slug in sorted(actual_slugs):
        content_hash = _compute_dir_hash(source_root / slug)
        specs.append(
            {"slug": slug, "version": "system", "content_hash": content_hash}
        )

    canonical_root = _get_canonical_store_root(settings)
    if canonical_root.exists():
        store = CanonicalSkillStore(root=canonical_root)
        for spec in specs:
            package_path = store.canonical_path(
                spec["slug"], spec["version"], spec["content_hash"],
            )
            if not os.path.lexists(package_path):
                continue
            store.verify_package(
                spec["slug"], spec["version"], spec["content_hash"],
            )
            actual_hash = store.compute_tree_hash(
                spec["slug"], spec["version"], spec["content_hash"],
            )
            if actual_hash != spec["content_hash"]:
                raise CanonicalStoreError(
                    "content_corruption",
                    f"Canonical package {spec['slug']}@system content mismatch "
                    f"(expected {spec['content_hash'][:16]}... "
                    f"got {actual_hash[:16]}...). No automatic repair from "
                    "same-UID local source.",
                )

    isolation = detect_platform_isolation()
    expected_by_slug = {spec["slug"]: spec for spec in specs}
    for skills_subdir in (".claude/skills", ".agents/skills"):
        skills_dir = workspace / skills_subdir
        try:
            directory_fd = isolation.admit_skills_directory(
                skills_dir, workspace_root=workspace,
            )
        except PlatformIsolationError as exc:
            raise SymlinkMaterializationError(
                getattr(exc, "code", None) or "escaped_parent",
                f"Workspace skills root {skills_dir} refused: {exc}",
            ) from exc
        if directory_fd is None:
            continue
        try:
            with os.scandir(directory_fd) as iterator:
                entries = {
                    entry.name: (
                        entry.is_symlink(),
                        entry.is_dir(follow_symlinks=False),
                    )
                    for entry in iterator
                }
        finally:
            os.close(directory_fd)

        unexpected = sorted(set(entries) - set(expected_by_slug))
        if unexpected:
            raise SymlinkMaterializationError(
                "unexpected_skill_entry",
                f"Unexpected entries in {skills_dir}: {unexpected}",
            )

        for slug, (is_symlink, is_directory) in sorted(entries.items()):
            link_path = skills_dir / slug
            if not is_symlink:
                code = (
                    "ordinary_dir_at_link_path"
                    if is_directory
                    else "non_link_at_link_path"
                )
                raise SymlinkMaterializationError(
                    code,
                    f"Expected symlink at {link_path} but found a non-link entry",
                )
            spec = expected_by_slug[slug]
            expected_target = (
                canonical_root
                / slug
                / spec["version"]
                / spec["content_hash"][:16]
            )
            raw_target = Path(os.readlink(link_path))
            if raw_target.is_absolute() or not isolation.verify_workspace_link(
                link_path,
                expected_target,
                canonical_root,
            ):
                raise SymlinkMaterializationError(
                    "wrong_target",
                    f"Workspace link {link_path} does not point to "
                    f"{expected_target}",
                )


def _assistant_skill_rollback_plan(
    paths: SystemAssistantPaths,
) -> tuple[list[Path], list[Path]]:
    """Record only absent skill paths/directories this call may create."""
    links = [
        paths.workspace / subdir / slug
        for subdir in (".claude/skills", ".agents/skills")
        for slug in sorted(_ASSISTANT_SKILL_SLUGS)
    ]
    directories = [
        paths.root.parent,
        paths.root,
        paths.workspace,
        paths.workspace / ".claude",
        paths.workspace / ".claude/skills",
        paths.workspace / ".agents",
        paths.workspace / ".agents/skills",
    ]
    return (
        [path for path in links if not os.path.lexists(path)],
        [path for path in directories if not os.path.lexists(path)],
    )


def _rollback_created_assistant_skill_paths(
    links: list[Path], directories: list[Path],
) -> None:
    """Remove only skill links/directories proven absent before this call."""
    failures: list[str] = []
    for link in links:
        if not os.path.lexists(link):
            continue
        if link.is_symlink():
            try:
                link.unlink()
            except OSError as exc:
                failures.append(f"{link}: {exc}")
        else:
            failures.append(f"{link}: created path is not a symlink")
    for directory in sorted(
        directories,
        key=lambda path: len(path.parts),
        reverse=True,
    ):
        if not os.path.lexists(directory):
            continue
        if directory.is_symlink() or not directory.is_dir():
            failures.append(f"{directory}: created path is not a directory")
            continue
        try:
            directory.rmdir()
        except OSError as exc:
            failures.append(f"{directory}: {exc}")
    if failures:
        raise ValueError(
            "assistant skill materialization rollback failed: " + "; ".join(failures)
        )


def bootstrap_assistant_workspace(runtime_root: Path, *, executor: str) -> None:
    selected_executor = _validate_executor(executor)
    paths = system_assistant_paths(runtime_root)
    _reject_symlink(
        paths.root.parent,
        "assistant system directory must not be a symlink",
    )
    _reject_symlink(paths.root, "assistant root must not be a symlink")
    _reject_symlink(paths.workspace, "assistant workspace must not be a symlink")
    _reject_symlink(
        paths.knowledge_dir,
        "assistant knowledge directory must not be a symlink",
    )
    _reject_symlink(
        paths.learnings_dir,
        "assistant learnings directory must not be a symlink",
    )
    _reject_symlink(paths.logs_dir, "assistant logs directory must not be a symlink")
    managed_detail = _managed_dir_existing_invalid_detail(paths)
    if managed_detail is not None:
        raise ValueError(managed_detail)
    _reject_existing_invalid_bootstrap_file(
        paths.workspace / "agent.yaml",
        "agent.yaml",
    )
    _reject_existing_invalid_bootstrap_file(
        paths.workspace / "AGENTS.md",
        "AGENTS.md",
    )
    _reject_existing_invalid_bootstrap_file(
        paths.workspace / "CLAUDE.md",
        "CLAUDE.md",
    )
    learnings_index_invalid_detail = _learnings_index_invalid_detail(
        paths.learnings_dir / "_index.md",
    )
    if learnings_index_invalid_detail is not None:
        raise ValueError(learnings_index_invalid_detail)
    knowledge_index_invalid_detail = _knowledge_index_invalid_detail(
        paths.knowledge_dir / "README.md",
    )
    if (
        knowledge_index_invalid_detail is not None
        and knowledge_index_invalid_detail != "assistant knowledge index is missing"
    ):
        raise ValueError(knowledge_index_invalid_detail)

    from runtime.config import Settings
    from runtime.orchestrator.workspace_adapters import (
        SystemContractMaterializationError,
        materialize_workspace_skills_union,
    )
    from runtime.skills.canonical_store import CanonicalStoreError
    from runtime.skills.symlink_materializer import SymlinkMaterializationError

    settings = Settings()
    try:
        _preflight_assistant_skills(paths.workspace, settings)
    except (
        CanonicalStoreError,
        SymlinkMaterializationError,
        SystemContractMaterializationError,
    ) as exc:
        raise ValueError(f"assistant skill materialization failed: {exc}") from exc

    rollback_links, rollback_directories = _assistant_skill_rollback_plan(paths)
    try:
        materialize_workspace_skills_union(
            paths.workspace,
            settings,
            slug="system-assistant",
            contexts=list(_ASSISTANT_SKILL_CONTEXTS),
            provider=selected_executor,
            agent_name="system_assistant",
            team="",
            # The runtime-global assistant has no managed catalog or org
            # database. Only the canonical system-contract union is eligible.
            skills_root=paths.root / ".no-managed-skills",
        )
    except (
        CanonicalStoreError,
        SymlinkMaterializationError,
        SystemContractMaterializationError,
    ) as exc:
        try:
            _rollback_created_assistant_skill_paths(
                rollback_links, rollback_directories,
            )
        except ValueError as rollback_exc:
            raise ValueError(
                f"assistant skill materialization failed: {exc}; {rollback_exc}"
            ) from exc
        raise ValueError(f"assistant skill materialization failed: {exc}") from exc

    _ensure_managed_dir(
        paths.root.parent,
        "assistant system directory must not be a symlink",
        "assistant system directory is not a directory",
    )
    _ensure_managed_dir(
        paths.root,
        "assistant root must not be a symlink",
        "assistant root is not a directory",
    )
    _ensure_managed_dir(
        paths.workspace,
        "assistant workspace must not be a symlink",
        "assistant workspace is not a directory",
    )
    _write_knowledge_pack(paths)
    _ensure_managed_dir(
        paths.learnings_dir,
        "assistant learnings directory must not be a symlink",
        "assistant learnings directory is not a directory",
    )
    _ensure_managed_dir(
        paths.logs_dir,
        "assistant logs directory must not be a symlink",
        "assistant logs directory is not a directory",
    )
    (paths.workspace / "agent.yaml").write_text(
        yaml.safe_dump(
            {
                "name": "system_assistant",
                "executor": selected_executor,
                "repos": {},
            },
            sort_keys=False,
        )
    )
    if not (paths.learnings_dir / "_index.md").exists():
        (paths.learnings_dir / "_index.md").write_text("# Learnings: system_assistant\n\n")
    prompt = _assistant_prompt()
    _write_assistant_instruction_pair(paths.workspace, prompt)
