"""Agent inspection, init, and learnings callback endpoints."""
from __future__ import annotations

import asyncio
import hashlib
import json as _json
import logging
import os
import re
import shutil
import tempfile
from contextlib import asynccontextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import StrEnum
from pathlib import Path
from typing import Literal

from fastapi import APIRouter, HTTPException, Query, status
from pydantic import BaseModel, field_validator, model_validator
from sse_starlette.sse import EventSourceResponse

from runtime.daemon.agent_config import (
    load_agent_config,
)
from runtime.daemon.auth import require_token
from runtime.daemon.org_state import OrgState
from runtime.daemon.routes._org_dep import OrgDep
from runtime.infrastructure.audit_logger import AuditLogger
from runtime.infrastructure.kb_store import KBStore, InvalidSlug
from runtime.infrastructure.learnings_store import (
    InvalidLearningEntry,
    InvalidLearningId,
    LearningIdExists,
    LearningNotFound,
    LearningSearchHit,
    LearningSlugExists,
    MemoryCompactionPolicy,
    MemoryItem,
    MemoryStore,
    PromotedLocked,
)
from runtime.infrastructure.memory_migration import migrate_workspace
from runtime.models import (
    DreamStatus,
    ScheduleStatus,
    TaskStatus,
    ThreadInvocationStatus,
    WorkHourStatus,
)
from runtime.orchestrator import prompt_loader
from runtime.orchestrator._paths import OrgPaths
from runtime.orchestrator.active_authority_policy import is_eligible_policy_manager
from runtime.orchestrator.org_config import load_org_config
from runtime.orchestrator.agent_def import AgentDef, AgentParseError, Executor
from runtime.orchestrator.authority_policy_store import AuthorityPolicyStore
from runtime.orchestrator.context_builder import ContextBuilder
from runtime.orchestrator.workspace_adapters import (
    InstructionPairConflict,
    _workspace_skills_transaction,
    materialize_workspace_skills,
    validate_workspace_skills_integrity,
)

router = APIRouter(dependencies=[require_token()])


def _executor_switch_materialize(
    workspace: Path,
    org: OrgState,
    agent_name: str,
    provider: str,
) -> list[str]:
    """Materialize the six-context canonical skill union during executor switch.

    Runs under the process-local workspace RLock so a concurrent
    session-time task/thread spawn cannot interleave inside the
    materialization tree. Returns a list of materialization error
    messages (empty on success).

    This function does ONLY the union materialization. Bootstrap files
    (CLAUDE.md/AGENTS.md, .claude/settings.json, memory, task_history)
    are NOT written here — they are handled by the caller AFTER this
    function succeeds and before the new executor frontmatter is
    persisted. This ordering guarantees:

    1. Union failure → no bootstrap files, no config change, no audit.
    2. Union success + bootstrap failure → safe compensation cleans up
       any partial bootstrap files BEFORE any config/audit mutation.
    3. Union success + bootstrap success → config + audit proceed.
    """
    _logger = logging.getLogger(__name__)

    # Resolve agent team for the unified call
    try:
        agent_def = prompt_loader.load_agent(OrgPaths(root=org.root), agent_name)
        agent_team = agent_def.team if agent_def else "engineering"
    except Exception:
        agent_team = "engineering"

    skills_root = org.settings.project_root / "runtime" / "skills"

    with _workspace_skills_transaction(workspace):
        errors: list[str] = []
        try:
            from runtime.orchestrator.workspace_adapters import (
                materialize_workspace_skills_union,
            )
            expected_specs = materialize_workspace_skills_union(
                workspace, org.settings,
                slug=org.slug,
                contexts=["task", "thread", "wake", "dream",
                          "schedule", "bootstrap"],
                provider=provider,
                agent_name=agent_name,
                team=agent_team,
                skills_root=skills_root,
                org_root=org.root,
                db=org.db,
            )
        except Exception as e:
            errors.append(str(e))
            _logger.error(
                "Executor switch: materialization failed for "
                "context-union provider=%s agent=%s: %s",
                provider, agent_name, e,
            )
            return errors

        # ── Pre-switch integrity validation ───────────────────────
        # Validate the resolved union against the canonical store
        # BEFORE executor switch can report success. A mismatch
        # (same-owner mutation detected via hash, broken/malicious
        # link, unexpected entry) emits a durable audit event and
        # rejects the switch with the documented recovery command.
        try:
            validate_workspace_skills_integrity(
                workspace,
                expected_specs,
                settings=org.settings,
                db=org.db,
                agent_name=agent_name,
            )
        except Exception as e:
            errors.append(str(e))
            _logger.error(
                "Executor switch: integrity validation failed for "
                "provider=%s agent=%s: %s",
                provider, agent_name, e,
            )
            return errors

    return errors


def _bootstrap_readiness_marker(
    org: OrgState,
    workspace: Path,
    agent_name: str,
    agent_def: AgentDef | None,
    provider: str,
) -> None:
    """GH-709 Slice C: produce + verify the selected executor profile's marker.

    The bootstrap producers are the workspace adapters (``CLAUDE.md`` /
    ``AGENTS.md``) and the canonical skill materializer (which produces the
    claude profile marker ``.claude/skills/start-task/SKILL.md`` — otherwise
    only materialized at session spawn). Materializing at init time makes the
    regenerated workspace launch-ready immediately; ``context="bootstrap"``
    still materializes the full system-contract union (all ordinary contexts).

    Marker resolution follows the orchestrator's existing contract
    (``Orchestrator._readiness_marker``): ``get_profile(provider).
    readiness_marker_fragment``. An unregistered profile is a blocked agent
    (relocation runbook §7.1 step 1) — the marker cannot be verified, so init
    must not report ``done``.

    Raises an actionable error when the profile is unregistered or the exact
    marker is missing / not a regular file — the route converts it into a
    per-agent ``error`` event (no ``done``, no ``all_done``).
    """
    from runtime.orchestrator.executor_registry import get_registry

    skills_root = org.settings.project_root / "runtime" / "skills"
    materialize_workspace_skills(
        workspace, org.settings,
        slug=org.slug,
        context="bootstrap",
        provider=provider,
        agent_name=agent_name,
        team=agent_def.team if agent_def else "engineering",
        skills_root=skills_root,
        org_root=org.root,
        db=org.db,
    )

    from runtime.orchestrator.workspace_adapters import instruction_pair_refusal

    pair_refusal = instruction_pair_refusal(workspace)
    if pair_refusal is not None:
        raise RuntimeError(
            f"instruction pair for {agent_name!r} is not canonical: "
            f"{pair_refusal}. Run `happyranch init-agent {agent_name}` to "
            "complete it."
        )

    profile = get_registry().get_profile(provider)
    if profile is None:
        raise RuntimeError(
            f"executor profile {provider!r} is not registered on this machine; "
            "register it before initializing (readiness marker cannot be verified)"
        )
    marker = workspace / profile.readiness_marker_fragment
    if not marker.is_file():
        raise RuntimeError(
            f"readiness marker for executor profile {provider!r} is missing or not "
            f"a regular file: {profile.readiness_marker_fragment!r}"
        )


class InitBody(BaseModel):
    agent: str | None = None


class LearningBody(BaseModel):
    session_id: str
    task_id: str
    text: str


_ALLOW_RULES_FORBIDDEN = ("\n", "\r", ";", "|", "&", "`", "$(")


def _validate_allow_rules(values: list[str] | None) -> list[str] | None:
    """Shared validator for ``allow_rules`` arrays.

    Rejects entries containing shell metacharacters that could break the
    Claude/opencode permission matcher. Returns the original list (or None)
    unchanged on success; raises ``ValueError`` on the first bad entry.
    """
    if values is None:
        return values
    for entry in values:
        if not entry or not entry.strip():
            raise ValueError("allow_rules entries must be non-empty")
        if entry != entry.strip():
            raise ValueError("allow_rules entries must not have leading/trailing whitespace")
        for bad in _ALLOW_RULES_FORBIDDEN:
            if bad in entry:
                raise ValueError(f"allow_rules entries must not contain {bad!r}")
    return values


class RepoAction(StrEnum):
    add = "add"
    remove = "remove"
    update = "update"


class ManageRepoBody(BaseModel):
    action: RepoAction
    repo_name: str
    url: str | None = None


class ManageAgentAction(StrEnum):
    enroll = "enroll"
    update = "update"
    terminate = "terminate"


class ManageAgentBody(BaseModel):
    action: ManageAgentAction
    name: str
    task_id: str | None = None
    session_id: str | None = None
    description: str | None = None
    system_prompt: str | None = None
    repos: dict[str, str] | None = None
    executor: str | None = None
    model: str | None = None
    allow_rules: list[str] | None = None
    target_team: str | None = None
    expected_revision: str | None = None

    @field_validator("allow_rules")
    @classmethod
    def _reject_unsafe_allow_rules(cls, v: list[str] | None) -> list[str] | None:
        return _validate_allow_rules(v)

    @model_validator(mode="after")
    def _exactly_one_auth_path(self) -> ManageAgentBody:
        task_path = self.task_id is not None and self.session_id is not None
        partial_task = (self.task_id is not None) != (self.session_id is not None)
        if partial_task:
            raise ValueError("task_id and session_id must be supplied together")
        if not task_path:
            raise ValueError("supply task_id and session_id")
        return self


class FounderCreateAgentBody(BaseModel):
    name: str
    role: Literal["worker", "manager"]
    team: str | None = None
    new_team: str | None = None
    executor: str = "claude"
    model: str | None = None
    description: str
    system_prompt: str
    allow_rules: list[str] | None = None
    repos: dict[str, str] | None = None

    @field_validator("allow_rules")
    @classmethod
    def _reject_unsafe_allow_rules(cls, v: list[str] | None) -> list[str] | None:
        return _validate_allow_rules(v)


_VALID_AGENT_NAME = re.compile(r"^[a-z][a-z0-9_]*$")


_TERMINATED_AGENTS_DIRNAME = "_terminated"
_TERMINATED_WORKSPACES_DIRNAME = "_terminated"


def _terminated_agents_dir(paths: OrgPaths) -> Path:
    return paths.agents_dir / _TERMINATED_AGENTS_DIRNAME


def _terminated_workspaces_dir(paths: OrgPaths) -> Path:
    return paths.workspaces_dir / _TERMINATED_WORKSPACES_DIRNAME


def _move_dir_atomically(src: Path, dst: Path) -> None:
    """Move a directory, preferring an atomic same-filesystem rename.

    ``dst`` must not already exist. Falls back to ``shutil.move`` only when
    the source and destination are on different filesystems.
    """
    if dst.exists():
        raise FileExistsError(f"destination already exists: {dst}")
    try:
        os.rename(src, dst)
    except OSError:
        shutil.move(str(src), str(dst))


def _require_team_manager_auth(body: ManageAgentBody, org: OrgState) -> tuple[str, str]:
    """Validate the caller is a team manager and return (manager_name, manager_team).

    Iterates all team managers, finds the one with a matching active
    (task_id, session_id) session.

    Returns (manager_name, manager_team) so callers can enforce team scoping.
    """
    if org.teams is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="manage-agent requires teams registry (no active runtime)",
        )

    # Find the team manager whose active session matches
    for candidate in org.teams.all_agents():
        if not org.teams.is_team_manager(candidate):
            continue
        active = org.sessions.get_active(body.task_id, candidate)
        if active is not None and active == body.session_id:
            if org.sessions.is_recovery_session(body.task_id, candidate, body.session_id):
                raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail={"code": "recovery_purpose_forbidden"})
            manager_team = org.teams.team_for_manager(candidate)
            assert manager_team is not None
            return candidate, manager_team

    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="manage-agent requires an active team-manager session",
    )


def _collect_quiescence_conflicts(org: OrgState, agent_name: str) -> list[dict]:
    """Return stable IDs/kinds of live work that blocks termination.

    Non-terminal directly assigned tasks (including children assigned to this
    worker), already-started thread invocations, firing schedules, running
    work-hours wakes, running dreams, and pending/running jobs attributable to
    the worker are all conflicts. Each entry is ``{"kind": ..., "id": ...}``.
    """
    conflicts: list[dict] = []
    db = org.db

    # Non-terminal tasks assigned to this agent.
    non_terminal_statuses = {
        TaskStatus.PENDING.value,
        TaskStatus.IN_PROGRESS.value,
        TaskStatus.ESCALATED.value,
    }
    for task in db.list_tasks(assigned_agent=agent_name, limit=10000):
        if task.status.value in non_terminal_statuses:
            conflicts.append({"kind": "task", "id": task.id})

    # Already-started (but not yet consumed/declined) thread invocations.
    for token, _thread_id in db.list_started_invocations_for_agent(agent_name):
        conflicts.append({"kind": "thread_invocation", "id": token})

    # Firing schedules.
    for sched in db.schedules.list(agent=agent_name, status=ScheduleStatus.FIRING, limit=500):
        conflicts.append({"kind": "schedule", "id": sched.id})

    # Running work-hours wakes.
    for wh in db.work_hours.list(agent=agent_name, limit=500):
        if wh.status == WorkHourStatus.RUNNING:
            conflicts.append({"kind": "work_hour", "id": wh.id})

    # Running dreams.
    for dream in db.list_dreams(agent=agent_name, limit=500):
        if dream.status == DreamStatus.RUNNING:
            conflicts.append({"kind": "dream", "id": dream.id})

    # Pending/running jobs attributable to the worker.
    for job in db.list_jobs_db(agent=agent_name, status=["pending", "running"], limit=500):
        conflicts.append({"kind": "job", "id": job.id})

    return conflicts


def _append_to_learnings_file(learnings_path: Path, agent_name: str, text: str) -> None:
    """Append a single learning line to learnings.md, creating the file+header if missing.

    Callers are responsible for serialization (e.g. holding org.db_lock) when
    concurrent writes are possible. The function itself performs no locking.
    """
    if not learnings_path.exists():
        learnings_path.parent.mkdir(parents=True, exist_ok=True)
        learnings_path.write_text(f"# Learnings: {agent_name}\n\n")
    existing = learnings_path.read_text()
    learnings_path.write_text(existing + f"- {text}\n")


def _resolve_agent_model(paths: OrgPaths, agent_name: str) -> str | None:
    """Resolve the per-agent model from org/agents/<name>.md frontmatter.

    THR-095: AgentDef.model is the SINGLE authoritative store.
    The agent.yaml ladder has been REMOVED per founder ruling (option B).
    """
    agent_def = prompt_loader.load_agent(paths, agent_name)
    return agent_def.model if agent_def else None


@router.get("/agents")
def list_agents(slug: str, org: OrgDep) -> dict:
    """Return the active agent roster.

    The canonical active roster is ``prompt_loader.list_agents(paths)`` — the
    set of approved agent markdown files under ``org/agents/``. This excludes
    pending enrollments, terminated archives, and any stray workspace
    directories that do not correspond to an active AgentDef.

    Compatibility note: earlier implementations discovered agents by scanning
    ``workspaces/`` and would surface workspace-only directories. That behavior
    is not a documented requirement; the file-based roster is the supported
    source of truth.
    """
    paths = OrgPaths(root=org.root)
    rows = []
    for listed_agent in prompt_loader.list_agents(paths):
        loaded = prompt_loader.load_agent_with_revision(paths, listed_agent.name)
        if loaded is None:
            continue
        agent_def, revision = loaded
        name = agent_def.name
        # THR-095: repos are read from AgentDef.repos (org/agents/<name>.md).
        # agent.yaml is no longer the source for repos.
        repos = dict(agent_def.repos) if agent_def.repos else {}
        rows.append({
            "name": name,
            "team": agent_def.team,
            "role": agent_def.role,
            "executor": agent_def.executor,
            "model": agent_def.model,
            "description": agent_def.description,
            # Phase 2: additive read-only fields (D6 spec)
            "repos": repos,
            "system_prompt": agent_def.system_prompt,
            "revision": revision,
        })
    return {"agents": rows}


@router.get("/agents/{agent_name}/cleanup-activity")
def get_cleanup_activity(slug: str, agent_name: str, org: OrgDep) -> dict:
    """Read five newest scheduled or exact-marker manual cleanup reports."""
    paths = OrgPaths(root=org.root)
    if prompt_loader.load_agent(paths, agent_name) is None:
        raise HTTPException(status_code=404, detail=f"agent {agent_name!r} not found")
    return {"activities": org.db.list_workspace_cleanup_activity(agent_name)}


@router.post("/agents/init")
async def init_agents(slug: str, body: InitBody, org: OrgDep):
    """Initialize agent workspaces.

    With ``agent`` set, initializes exactly that agent (even a name without
    an AgentDef yet — the workspace bootstrap is provider-derived). With
    ``agent`` unset (bulk), targets are the canonical active AgentDef roster
    only — ``prompt_loader.list_agents(paths)`` — never workspace
    directories, team-registry members without an AgentDef, or
    ``_pending``/``_terminated`` enrollments (GH-709 Slice B).

    GH-709 Slice C: an agent is reported ``done`` only after the selected
    executor profile's **exact readiness marker** exists as a valid regular
    file produced by this bootstrap (workspace adapter + skill
    materialization). An unregistered profile, a missing/wrong-profile
    marker, a non-regular marker, or a bootstrap/materialization failure
    emits a per-agent ``error`` event, never ``done``; the stream stops at
    the first error (no ``all_done``) so the CLI exits nonzero.
    """
    paths = OrgPaths(root=org.root)

    if body.agent is None:
        # Bulk init derives targets from the canonical active AgentDef roster
        # only (org/agents/*.md). Workspace directories, the team registry, and
        # _pending/_terminated enrollments are never targets: bulk init must
        # not bootstrap material into archive/reserved/stray roots (GH-709).
        targets = sorted(a.name for a in prompt_loader.list_agents(paths))
    else:
        targets = [body.agent]

    async def gen():
        ctx = ContextBuilder(org.settings, paths, slug=org.slug)
        for agent_name in targets:
            workspace = paths.workspaces_dir / agent_name
            workspace.mkdir(parents=True, exist_ok=True)
            yield {"data": _json.dumps({"agent": agent_name, "phase": "starting"})}
            try:
                agent_def = prompt_loader.load_agent(paths, agent_name)
                # THR-095: agent.yaml is no longer the source for
                # executor/repos.  Read both from AgentDef (.md frontmatter).
                provider = agent_def.executor if agent_def else "claude"
                repos = dict(agent_def.repos) if agent_def else {}
                for repo_name, url in repos.items():
                    yield {"data": _json.dumps({
                        "agent": agent_name, "phase": "repo_cloning",
                        "repo": repo_name,
                    })}
                    ok = await asyncio.to_thread(
                        ctx.clone_repo, workspace, repo_name, url,
                    )
                    yield {"data": _json.dumps({
                        "agent": agent_name,
                        "phase": "repo_ready" if ok else "repo_failed",
                        "repo": repo_name,
                    })}
                sys_prompt = agent_def.system_prompt if agent_def else ""
                await asyncio.to_thread(
                    ctx.ensure_workspace_ready, workspace, agent_name, sys_prompt,
                    provider=provider,
                )
                await asyncio.to_thread(
                    ctx.create_agent_dirs, workspace, agent_name,
                )
                # GH-709 Slice C: report done only after the selected executor
                # profile's exact readiness marker exists as a valid regular
                # file produced by this bootstrap.
                await asyncio.to_thread(
                    _bootstrap_readiness_marker, org, workspace, agent_name,
                    agent_def, provider,
                )
            except Exception as exc:
                yield {"data": _json.dumps({
                    "agent": agent_name, "phase": "error", "detail": str(exc),
                })}
                return
            yield {"data": _json.dumps({"agent": agent_name, "phase": "done"})}
        yield {"data": _json.dumps({"phase": "all_done"})}

    return EventSourceResponse(gen())


@router.post("/agents/{agent_name}/repos")
async def manage_repo(
    slug: str, agent_name: str, body: ManageRepoBody, org: OrgDep,
) -> dict:
    paths = OrgPaths(root=org.root)
    workspace = paths.workspaces_dir / agent_name
    if not workspace.exists():
        raise HTTPException(status_code=404, detail=f"workspace {agent_name!r} not found")

    if body.action in (RepoAction.add, RepoAction.update) and not body.url:
        raise HTTPException(status_code=422, detail=f"url required for {body.action!r}")

    ctx = ContextBuilder(org.settings, paths, slug=org.slug)
    agent_def = prompt_loader.load_agent(paths, agent_name)
    if agent_def is None:
        raise HTTPException(status_code=404, detail=f"agent {agent_name!r} not found")

    # THR-095: persist repos to org/agents/<name>.md frontmatter ONLY
    # (single source of truth).  agent.yaml is no longer the repo store.
    from runtime.orchestrator.agent_def import render_agent_text
    new_repos = dict(agent_def.repos)

    if body.action == RepoAction.add:
        if body.repo_name in new_repos:
            raise HTTPException(status_code=409, detail=f"repo {body.repo_name!r} already exists")
        new_repos[body.repo_name] = body.url
    elif body.action == RepoAction.remove:
        if body.repo_name not in new_repos:
            raise HTTPException(status_code=404, detail=f"repo {body.repo_name!r} not found")
        del new_repos[body.repo_name]
    elif body.action == RepoAction.update:
        if body.repo_name not in new_repos:
            raise HTTPException(status_code=404, detail=f"repo {body.repo_name!r} not found")
        new_repos[body.repo_name] = body.url

    # Atomic write the updated .md
    updated = AgentDef(
        name=agent_def.name,
        team=agent_def.team,
        role=agent_def.role,
        executor=agent_def.executor,
        allow_rules=agent_def.allow_rules,
        repos=new_repos,
        enrolled_by=agent_def.enrolled_by,
        enrolled_at_task=agent_def.enrolled_at_task,
        enrolled_at=agent_def.enrolled_at,
        system_prompt=agent_def.system_prompt,
        description=agent_def.description,
        model=agent_def.model,
    )
    async with _consumer_writer_interval(
        org, publisher="manage_repo", consumer=agent_name, executor=updated.executor,
    ) as authority_change:
        with authority_change.canonical_change():
            active_path = paths.agents_dir / f"{agent_name}.md"
            fd, tmp = tempfile.mkstemp(
                prefix=f".{agent_name}.", suffix=".md", dir=str(paths.agents_dir),
            )
            try:
                with os.fdopen(fd, "w") as fh:
                    fh.write(render_agent_text(updated))
                os.replace(tmp, active_path)
            except Exception:
                try:
                    os.unlink(tmp)
                except FileNotFoundError:
                    pass
                raise

    # Clone/remove repo dir as before
    if body.action == RepoAction.add:
        await asyncio.to_thread(ctx.clone_repo, workspace, body.repo_name, body.url)
    elif body.action == RepoAction.remove:
        repo_dir = workspace / "repos" / body.repo_name
        if repo_dir.exists():
            shutil.rmtree(repo_dir)
    elif body.action == RepoAction.update:
        repo_dir = workspace / "repos" / body.repo_name
        if repo_dir.exists():
            shutil.rmtree(repo_dir)
        await asyncio.to_thread(ctx.clone_repo, workspace, body.repo_name, body.url)

    # clone_repo can yield to the event loop.  Bootstrap from a fresh
    # canonical snapshot afterwards so an accepted whole-definition update
    # is not overwritten in workspace inputs (and a removed agent is not
    # resurrected).  This capture does not serialize workspace generation
    # against arbitrary later writes or external same-UID/multiprocess edits.
    fresh = prompt_loader.load_agent(paths, agent_name)
    if fresh is None:
        raise HTTPException(status_code=404, detail=f"agent {agent_name!r} not found")
    await asyncio.to_thread(
        ctx.ensure_workspace_ready, workspace, agent_name, fresh.system_prompt,
        provider=fresh.executor,
    )
    return {"ok": True}


@router.post("/agents/manage")
async def manage_agent(slug: str, body: ManageAgentBody, org: OrgDep) -> dict:
    paths = OrgPaths(root=org.root)

    # Any team manager may manage agents within their team.
    manager_name, manager_team = _require_team_manager_auth(body, org)

    scope_id = body.task_id
    assert scope_id is not None  # guaranteed by ManageAgentBody validation
    source = "task"
    audit = AuditLogger(org.db)

    if not _VALID_AGENT_NAME.match(body.name):
        raise HTTPException(status_code=422, detail=f"invalid agent name: {body.name!r}")

    if body.action == ManageAgentAction.enroll:
        if not body.description or not body.system_prompt:
            raise HTTPException(status_code=422, detail="description and system_prompt required for enroll")
        _validate_executor(body.executor or "claude")
        async with (
            org.workflow_authority.async_writer_interval(
                publisher="manage_agent_enroll",
            ) as authority_change,
            org.teams_lock,
        ):
            # Never reuse a name that has ever been enrolled (active, pending,
            # or terminated), to keep historical identity unambiguous. This must
            # share the lock with the synchronous pending write: the helper
            # atomically replaces an existing pending file.
            if prompt_loader.is_name_unavailable(paths, body.name):
                detail = {"code": "agent_name_unavailable", "name": body.name}
                if prompt_loader.is_terminated(paths, body.name):
                    detail["reason"] = "a terminated agent with this name exists"
                raise HTTPException(status_code=409, detail=detail)
            # Validate target_team BEFORE inserting — avoid zombie enrollment files.
            target_team = body.target_team or manager_team
            if target_team != manager_team:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail={
                        "code": "cross_team_forbidden",
                        "caller_team": manager_team,
                        "requested_team": target_team,
                    },
                )
            agent = AgentDef(
                name=body.name,
                team=target_team,
                role="worker",
                executor=body.executor or "claude",
                allow_rules=tuple(body.allow_rules or []),
                repos=body.repos or {},
                enrolled_by=manager_name,
                enrolled_at_task=body.task_id,
                enrolled_at=datetime.now(timezone.utc),
                system_prompt=body.system_prompt,
                description=body.description,
                model=body.model if body.model else None,
            )
            with authority_change.canonical_change():
                prompt_loader.write_pending_agent(paths, agent)
                org.teams.add_worker(manager_team, body.name)
        audit.log_agent_managed(
            scope_id=scope_id,
            action="enroll",
            name=body.name,
            source=source,
            actor=manager_name,
        )
        return {"ok": True, "status": "pending"}

    elif body.action == ManageAgentAction.update:
        if body.expected_revision is None or not re.fullmatch(r"[0-9a-f]{64}", body.expected_revision):
            raise HTTPException(status_code=422, detail={"code": "expected_revision_required", "message": "update requires a 64-character expected_revision"})
        async with _consumer_writer_interval(
            org, publisher="manage_agent_update", consumer=body.name,
            executor=body.executor, preserve=body.executor is None,
        ) as authority_change:
            async with org.teams_lock:
                loaded = prompt_loader.load_agent_snapshot(paths, body.name)
                if loaded is None:
                    raise HTTPException(status_code=404, detail=f"agent {body.name!r} not found")
                existing, current_revision, original_bytes = loaded
                agent_team = org.teams.team_for_agent(body.name) if org.teams is not None else None
                if agent_team != manager_team:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail={
                            "code": "cross_team_forbidden",
                            "caller_team": manager_team,
                            "agent_team": agent_team,
                        },
                    )
                if current_revision != body.expected_revision:
                    raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail={"code": "stale_agent_revision", "current_revision": current_revision})
                if body.executor is not None:
                    _validate_executor(body.executor)
                # Build the updated AgentDef, preserving fields not being updated.
                # model: use Pydantic field-set detection to distinguish omitted
                # (preserve existing) vs explicit null (clear).
                model_is_set = "model" in body.model_fields_set
                executor_changed = (
                    body.executor is not None and body.executor != existing.executor
                )
                if model_is_set:
                    resolved_model = body.model if body.model else None
                elif executor_changed:
                    # A model override is executor-specific. Never carry an omitted
                    # value from the old executor into a newly selected executor.
                    resolved_model = None
                else:
                    resolved_model = existing.model
                updated = AgentDef(
                    name=existing.name,
                    team=existing.team,
                    role=existing.role,
                    executor=body.executor or existing.executor,
                    allow_rules=tuple(body.allow_rules) if body.allow_rules is not None else existing.allow_rules,
                    repos=body.repos if body.repos is not None else existing.repos,
                    enrolled_by=existing.enrolled_by,
                    enrolled_at_task=existing.enrolled_at_task,
                    enrolled_at=existing.enrolled_at,
                    system_prompt=body.system_prompt if body.system_prompt is not None else existing.system_prompt,
                    description=body.description if body.description is not None else existing.description,
                    model=resolved_model,
                )
                with authority_change.canonical_change():
                    active_path = paths.agents_dir / f"{body.name}.md"
                    from runtime.orchestrator.agent_def import render_agent_text
                    fd, tmp = tempfile.mkstemp(prefix=f".{body.name}.", suffix=".md", dir=str(paths.agents_dir))
                    try:
                        updated_bytes = render_agent_text(updated).encode("utf-8")
                        with os.fdopen(fd, "wb") as fh:
                            fh.write(updated_bytes)
                        os.replace(tmp, active_path)
                    except Exception:
                        try:
                            os.unlink(tmp)
                        except FileNotFoundError:
                            pass
                        raise
            workspace = paths.workspaces_dir / body.name
            if workspace.exists() and (body.system_prompt or body.executor is not None):
                # Reconcile the workspace bootstrap for the (possibly new) executor
                # profile. Use the preserved or updated system prompt so the
                # bootstrap files reflect the current agent definition — not only
                # the caller-supplied body.system_prompt.
                ctx = ContextBuilder(org.settings, paths, slug=org.slug)
                await asyncio.to_thread(
                    ctx.ensure_workspace_ready,
                    workspace,
                    body.name,
                    updated.system_prompt,
                    provider=updated.executor,
                )
            # THR-200: a SUCCESSFUL executor switch invalidates every thread
            # participant session row for this agent — a later switch back to a
            # resume-capable executor must start from a fresh full-prompt launch,
            # never reuse a provider session minted under a different executor.
            # The reset and its invalidation audit commit in ONE database-owned
            # transaction: if either fails, rollback restores prior frontmatter
            # and re-reconciles the workspace only while this operation still owns
            # the canonical revision; a newer or missing definition is preserved.
            if executor_changed:
                try:
                    org.db.reset_thread_sessions_for_agent(
                        body.name,
                        audit_scope_id=scope_id,
                        audit_agent=manager_name,
                        audit_reason="executor_switch",
                    )
                except Exception:
                    _logger = logging.getLogger(__name__)
                    _logger.exception(
                        "executor-switch session invalidation failed for %s; "
                        "rolling back the switch", body.name,
                    )
                    # Restore only the exact canonical bytes this operation owns.
                    # The original read/commit happened under teams_lock; after
                    # workspace bootstrap yielded, another accepted route update
                    # may have won.  Do not overwrite that newer definition.
                    restored = False
                    try:
                        async with org.teams_lock:
                            current = prompt_loader.load_agent_with_revision(paths, body.name)
                            written_revision = hashlib.sha256(updated_bytes).hexdigest()
                            if current is not None and current[1] == written_revision:
                                with authority_change.canonical_change():
                                    fd, tmp = tempfile.mkstemp(
                                        prefix=f".{body.name}.", suffix=".md",
                                        dir=str(paths.agents_dir),
                                    )
                                    try:
                                        with os.fdopen(fd, "wb") as fh:
                                            fh.write(original_bytes)
                                        os.replace(tmp, active_path)
                                        restored = True
                                    except Exception:
                                        try:
                                            os.unlink(tmp)
                                        except FileNotFoundError:
                                            pass
                                        raise
                            else:
                                _logger.warning(
                                    "executor-switch rollback conflict for %s; "
                                    "canonical definition changed or disappeared",
                                    body.name,
                                )
                    except Exception:
                        _logger.exception(
                            "failed to restore agent file for %s", body.name,
                        )
                    if restored:
                        try:
                            if workspace.exists():
                                ctx = ContextBuilder(org.settings, paths, slug=org.slug)
                                await asyncio.to_thread(
                                    ctx.ensure_workspace_ready,
                                    workspace, body.name,
                                    existing.system_prompt,
                                    provider=existing.executor,
                                )
                        except Exception:
                            _logger.exception(
                                "failed to re-reconcile workspace for %s", body.name,
                            )
                    raise
        # THR-095: agent.yaml executor/model sync REMOVED.
        # The .md frontmatter is the single source of truth.
        audit.log_agent_managed(
            scope_id=scope_id,
            action="update",
            name=body.name,
            source=source,
            actor=manager_name,
        )
        return {"ok": True}

    elif body.action == ManageAgentAction.terminate:
        existing = prompt_loader.load_agent(paths, body.name)
        if existing is None:
            raise HTTPException(status_code=404, detail=f"agent {body.name!r} not found")

        # Only non-manager workers may be terminated. Removing a manager would
        # corrupt the team hierarchy.
        if existing.role == "manager":
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail={
                    "code": "manager_terminate_forbidden",
                    "name": body.name,
                    "reason": "terminating a team manager is not allowed",
                },
            )

        # Enforce quiescence before any destructive archive step. Active work
        # is never killed, cancelled, reassigned, or silently mutated.
        conflicts = _collect_quiescence_conflicts(org, body.name)
        if conflicts:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail={
                    "code": "agent_not_quiescent",
                    "name": body.name,
                    "conflicts": conflicts,
                },
            )

        # Preflight archive collision and move feasibility BEFORE any state
        # mutation. If the active AgentDef or workspace cannot be archived, we
        # must return 409/500 with the agent still fully active: team
        # membership, armed schedules, pending wakes/dreams, and unstarted
        # invocations untouched.
        active_path = paths.agents_dir / f"{body.name}.md"
        terminated_agents_dir = _terminated_agents_dir(paths)
        terminated_agents_dir.mkdir(parents=True, exist_ok=True)
        terminated_agent_path = terminated_agents_dir / f"{body.name}.md"
        if terminated_agent_path.exists():
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail={
                    "code": "archive_collision",
                    "name": body.name,
                    "reason": "a terminated agent file already exists",
                },
            )

        workspace = paths.workspaces_dir / body.name
        terminated_workspace_dir = _terminated_workspaces_dir(paths)
        terminated_workspace_dir.mkdir(parents=True, exist_ok=True)
        terminated_workspace = terminated_workspace_dir / body.name
        workspace_exists = workspace.exists()
        if workspace_exists and terminated_workspace.exists():
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail={
                    "code": "archive_collision",
                    "name": body.name,
                    "reason": "a terminated workspace already exists",
                },
            )
        if workspace_exists and not workspace.is_dir():
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail={
                    "code": "workspace_archive_failed",
                    "name": body.name,
                    "reason": "workspace path is not a directory",
                },
            )
        if workspace_exists and not os.access(terminated_workspace_dir, os.W_OK):
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail={
                    "code": "workspace_archive_failed",
                    "name": body.name,
                    "reason": "terminated workspace directory is not writable",
                },
            )

        async with (
            _consumer_writer_interval(
                org, publisher="manage_agent_terminate", consumer=body.name,
            ) as authority_change,
            org.teams_lock,
        ):
            # The outer checks make ordinary refusals cheap, but this await
            # permits another accepted writer to change the canonical file,
            # its role, or archive/workspace occupancy.  Refresh precisely
            # those facts before this synchronous archive/cleanup segment.
            loaded = prompt_loader.load_agent_snapshot(paths, body.name)
            if loaded is None:
                raise HTTPException(status_code=404, detail=f"agent {body.name!r} not found")
            existing, _current_revision, archived_agent_bytes = loaded
            if existing.role == "manager":
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail={
                        "code": "manager_terminate_forbidden",
                        "name": body.name,
                        "reason": "terminating a team manager is not allowed",
                    },
                )
            agent_team = org.teams.team_for_agent(body.name) if org.teams is not None else None
            if agent_team != manager_team:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail={
                        "code": "cross_team_forbidden",
                        "caller_team": manager_team,
                        "agent_team": agent_team,
                    },
                )

            # Re-check quiescence under the lock: new live work may have been
            # assigned between the outer check and lock acquisition.
            conflicts = _collect_quiescence_conflicts(org, body.name)
            if conflicts:
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail={
                        "code": "agent_not_quiescent",
                        "name": body.name,
                        "conflicts": conflicts,
                    },
                )

            if terminated_agent_path.exists():
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail={
                        "code": "archive_collision",
                        "name": body.name,
                        "reason": "a terminated agent file already exists",
                    },
                )
            workspace_exists = workspace.exists()
            if workspace_exists and terminated_workspace.exists():
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail={
                        "code": "archive_collision",
                        "name": body.name,
                        "reason": "a terminated workspace already exists",
                    },
                )
            if workspace_exists and not workspace.is_dir():
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail={
                        "code": "workspace_archive_failed",
                        "name": body.name,
                        "reason": "workspace path is not a directory",
                    },
                )
            if workspace_exists and not os.access(terminated_workspace_dir, os.W_OK):
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail={
                        "code": "workspace_archive_failed",
                        "name": body.name,
                        "reason": "terminated workspace directory is not writable",
                    },
                )

            # Archive the filesystem identity FIRST. If this fails, no DB or
            # team mutation has occurred yet, so the agent remains fully active.
            # POSIX rename overwrites an existing destination.  The preceding
            # final preflight is the supported daemon guarantee here: writers
            # that await use teams_lock, while synchronous no-await event-loop
            # writers cannot interleave this archive/cleanup segment. It does
            # not make a claim about external same-UID or multiprocess writers.
            with authority_change.canonical_change():
                os.rename(active_path, terminated_agent_path)
                if workspace_exists:
                    try:
                        _move_dir_atomically(workspace, terminated_workspace)
                    except Exception:
                        try:
                            if (
                                not active_path.exists()
                                and terminated_agent_path.exists()
                                and terminated_agent_path.read_bytes()
                                == archived_agent_bytes
                            ):
                                os.rename(terminated_agent_path, active_path)
                            else:
                                logging.getLogger(__name__).warning(
                                    "terminate workspace rollback conflict for %s; "
                                    "canonical definition changed or disappeared",
                                    body.name,
                                )
                        except OSError:
                            logging.getLogger(__name__).exception(
                                "failed to roll back agent file archive for %s", body.name,
                            )
                        raise HTTPException(
                            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail={
                                "code": "workspace_archive_failed",
                                "name": body.name,
                            },
                        )

                # Remove team membership while still holding the lock. If the
                # subsequent DB cleanup fails, we roll this back together with the
                # filesystem archive.
                org.teams.remove_worker(manager_team, body.name)

                # Atomically cancel armed schedules, skip pending wakes/dreams, and
                # decline unstarted invocations. A failure here rolls back the team
                # and filesystem archive so the agent stays active and consistent.
                try:
                    org.db.terminate_agent_cleanups(
                        body.name,
                        audit_scope_id=scope_id,
                        audit_agent=manager_name,
                    )
                except Exception:
                    _logger = logging.getLogger(__name__)
                    _logger.exception(
                        "terminate cleanup failed for %s; rolling back archive",
                        body.name,
                    )
                    # Roll back team membership first.
                    try:
                        org.teams.add_worker(manager_team, body.name)
                    except Exception:
                        _logger.exception(
                            "failed to roll back team membership for %s",
                            body.name,
                        )
                    # Roll back the filesystem archive.
                    try:
                        if workspace_exists and terminated_workspace.exists():
                            _move_dir_atomically(terminated_workspace, workspace)
                    except Exception:
                        _logger.exception(
                            "failed to roll back workspace archive for %s",
                            body.name,
                        )
                    try:
                        if (
                            not active_path.exists()
                            and terminated_agent_path.exists()
                            and terminated_agent_path.read_bytes()
                            == archived_agent_bytes
                        ):
                            os.rename(terminated_agent_path, active_path)
                        else:
                            _logger.warning(
                                "terminate cleanup rollback conflict for %s; "
                                "canonical definition changed or disappeared",
                                body.name,
                            )
                    except OSError:
                        _logger.exception(
                            "failed to roll back agent file archive for %s",
                            body.name,
                        )
                    raise HTTPException(
                        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                        detail={
                            "code": "terminate_cleanup_failed",
                            "name": body.name,
                        },
                    )

        audit.log_agent_managed(
            scope_id=scope_id,
            action="terminate",
            name=body.name,
            source=source,
            actor=manager_name,
        )
        return {"ok": True, "status": "terminated"}

    raise HTTPException(status_code=422, detail=f"unknown action: {body.action}")


@router.post("/agents")
async def founder_create_agent(
    slug: str, body: FounderCreateAgentBody, org: OrgDep,
) -> dict:
    """Founder-driven enroll. Lands the agent ACTIVE immediately (no
    pending hop). Worker: assigned to an existing team. Manager: creates
    a new team in teams.yaml as part of the same call.

    If workspace bootstrap (clone_repo / ensure_workspace_ready /
    create_agent_dirs) fails mid-flight, the agent file and teams.yaml
    entry are RETAINED — matches ``approve_agent``'s semantics. Use
    ``manage-agent terminate`` to clean up before retrying.
    """
    paths = OrgPaths(root=org.root)

    # ---- validation ----
    if not _VALID_AGENT_NAME.match(body.name):
        raise HTTPException(
            status_code=422,
            detail={"code": "invalid_agent_name", "name": body.name},
        )
    if not body.description.strip() or not body.system_prompt.strip():
        raise HTTPException(
            status_code=422,
            detail={"code": "missing_required_field"},
        )
    _validate_executor(body.executor)
    if body.role == "worker":
        if not body.team or body.new_team:
            raise HTTPException(
                status_code=422,
                detail={"code": "role_team_mismatch"},
            )
    else:  # manager
        if not body.new_team or body.team:
            raise HTTPException(
                status_code=422,
                detail={"code": "role_team_mismatch"},
            )

    # ---- team mutation + agent file write, under the same locks ----
    async with (
        _consumer_writer_interval(
            org, publisher="founder_create_agent", consumer=body.name, executor=body.executor,
        ) as authority_change,
        org.teams_lock,
    ):
        # Duplicate check inside the lock to close TOCTOU between check + write.
        # Terminated names are also unavailable to preserve historical identity.
        if prompt_loader.is_name_unavailable(paths, body.name):
            detail = {"code": "agent_exists", "name": body.name}
            if prompt_loader.is_terminated(paths, body.name):
                detail["reason"] = "a terminated agent with this name exists"
            raise HTTPException(status_code=409, detail=detail)

        if body.role == "worker":
            assert body.team is not None
            if body.team not in org.teams.teams():
                raise HTTPException(
                    status_code=404,
                    detail={"code": "unknown_team", "team": body.team},
                )
            team_name = body.team
        else:
            assert body.new_team is not None
            if body.new_team in org.teams.teams():
                raise HTTPException(
                    status_code=409,
                    detail={"code": "team_exists", "team": body.new_team},
                )
            team_name = body.new_team

        with authority_change.canonical_change():
            if body.role == "worker":
                org.teams.add_worker(team_name, body.name)
            else:
                try:
                    org.teams.add_team(team_name, manager=body.name)
                except ValueError:
                    # Defense in depth — the in-lock check above should make this
                    # unreachable, but if a future refactor drifts, surface as 409
                    # rather than a bare 500.
                    raise HTTPException(
                        status_code=409,
                        detail={"code": "team_exists", "team": body.new_team},
                    )

            agent_def = AgentDef(
                name=body.name,
                team=team_name,
                role=body.role,
                executor=body.executor,
                allow_rules=tuple(body.allow_rules or []),
                repos=body.repos or {},
                enrolled_by="founder",
                enrolled_at_task=None,
                enrolled_at=datetime.now(timezone.utc),
                system_prompt=body.system_prompt,
                description=body.description,
                model=body.model if body.model else None,
            )

            # Atomic write directly into active agents/ (skip _pending/).
            from runtime.orchestrator.agent_def import render_agent_text
            paths.agents_dir.mkdir(parents=True, exist_ok=True)
            active_path = paths.agents_dir / f"{body.name}.md"
            fd, tmp = tempfile.mkstemp(
                prefix=f".{body.name}.", suffix=".md",
                dir=str(paths.agents_dir),
            )
            active_landed = False
            try:
                with os.fdopen(fd, "w") as fh:
                    fh.write(render_agent_text(agent_def))
                os.replace(tmp, active_path)
                active_landed = True
                if body.role == "manager":
                    # The new team and its now-live eligible manager become
                    # launchable in this SAME coordinator-owned canonical
                    # mutation. Publication therefore observes the initialized
                    # selector and advances exactly one authority generation.
                    AuthorityPolicyStore(org.db).ensure_authority_selector(
                        team_name,
                    )
            except Exception:
                try:
                    os.unlink(tmp)
                except FileNotFoundError:
                    pass
                if active_landed:
                    try:
                        active_path.unlink()
                    except FileNotFoundError:
                        pass
                # Roll back the registry mutation (add_worker or add_team)
                # so we don't leave a phantom team-membership entry without
                # the corresponding agent file. Without this rollback the
                # manager-branch case is unrecoverable on retry (returns
                # 409 team_exists even though no manager file ever landed).
                if body.role == "worker":
                    org.teams.remove_worker(team_name, body.name)
                else:
                    org.teams.remove_team(team_name)
                raise
    # ---- workspace bootstrap (THR-095: no agent.yaml writes) ----
    workspace = paths.workspaces_dir / body.name
    workspace.mkdir(parents=True, exist_ok=True)

    # THR-095: agent.yaml is no longer the source for executor/repos.
    # The .md frontmatter (AgentDef) is the single source of truth.
    repos = agent_def.repos or {}
    ctx = ContextBuilder(org.settings, paths, slug=org.slug)
    for repo_name, url in repos.items():
        await asyncio.to_thread(ctx.clone_repo, workspace, repo_name, url)

    # Cloning yields to the event loop.  Bootstrap from the current active
    # definition so an accepted update is not fed stale prompt/provider
    # inputs, and never recreate a definition removed while cloning.  This
    # fresh capture does not serialize workspace generation against arbitrary
    # later writes.
    fresh = prompt_loader.load_agent(paths, body.name)
    if fresh is None:
        raise HTTPException(status_code=404, detail=f"agent {body.name!r} not found")
    await asyncio.to_thread(
        ctx.ensure_workspace_ready,
        workspace,
        body.name,
        fresh.system_prompt,
        provider=fresh.executor,
    )
    await asyncio.to_thread(ctx.create_agent_dirs, workspace, body.name)

    AuditLogger(org.db).log_agent_managed(
        scope_id="founder",
        action="enroll",
        name=body.name,
        source="founder",
        actor="founder",
    )
    return {"name": body.name, "team": team_name, "role": body.role}


# ---------------------------------------------------------------------------
# Founder surface: switch an existing agent's executor end-to-end.
# ---------------------------------------------------------------------------

# Executor validation is now registry-driven (THR-052). The registry
# singleton is the single source of truth for which executors are valid.
# We derive _VALID_EXECUTORS lazily to avoid a module-level import cycle.
def _get_valid_executors() -> tuple[str, ...]:
    from runtime.orchestrator.executor_registry import get_registry as _gr
    return tuple(_gr().list_profile_names())

_VALID_EXECUTORS: tuple[str, ...] = ()  # populated lazily

# Claude-only workspace files that go stale when an agent switches AWAY from
# the Claude executor. The shared canonical instruction pair
# (``AGENTS.md`` + raw relative ``CLAUDE.md`` link) and ``.claude/skills`` are
# PRESERVED; only the Claude-only ``.claude/settings.json`` is stale.
_CLAUDE_ONLY_WORKSPACE_FILES: tuple[str, ...] = (".claude/settings.json",)


# ---------------------------------------------------------------------------
# THR-190: bounded declared-write rollback journal for executor switch.
# ---------------------------------------------------------------------------
# The executor-switch bootstrap writer chain is
# ``set_agent_executor -> ContextBuilder.ensure_workspace_ready -> provider
# adapter -> PersistentWorkspaceSetup.ensure + provider writers``. Its whole
# write surface is a small, explicit set of bootstrap-owned paths (listed
# below). ``_BootstrapRollbackJournal`` captures/restores exactly that set
# (absence/presence/type/content) and NEVER traverses the workspace,
# ``repos/``, or the canonical skill links materialized by the union.
#
# Four Step-0 checks make lossless compensation possible (all run before
# ``_executor_switch_materialize`` — the first mutation):
#  * ``_bootstrap_legacy_migration_unsupported`` — a structured legacy
#    ``learnings/`` (with ``memory/`` absent) would trigger the unbounded
#    ``learnings/ -> memory/`` migration during bootstrap, which a bounded
#    journal cannot reverse; the switch fails closed BEFORE materialization.
#  * ``_bootstrap_unsupported_owned_paths`` — a symlink or non-regular entry
#    at an owned path cannot be restored exactly after a write-through or
#    replace; the switch fails closed BEFORE materialization so the union
#    reconciler can never follow a symlinked owned directory either.
#  * ``_bootstrap_uncapturable_owned_files`` — a present regular owned file
#    whose ``read_bytes()`` raises ``OSError`` is materially distinct from an
#    absent file (rollback must never delete a file it could not capture);
#    the switch fails closed BEFORE materialization and never represents
#    the file as absent.
#  * ``_BootstrapRollbackJournal.capture`` — the AUTHORITATIVE rollback
#    capture runs in Step 0, before the first mutation, and the route fails
#    closed (400 ``executor_bootstrap_failed``) if the capture observes ANY
#    uncapturable declared file. This closes the second-read window where a
#    preflight read succeeds but a later capture read fails after
#    materialization has already mutated: materialization/bootstrap/
#    frontmatter/audit can never run unless every pre-existing
#    declared-write target has already been captured as rollback
#    bytes/state.
#
# The drift-tripwire test (tests/daemon/test_routes_agents.py) instruments
# the real adapter bootstrap call against these constants so future adapter
# evolution cannot silently outrun the journal.

# Bootstrap-owned regular-file paths (relative to the workspace root).
_BOOTSTRAP_OWNED_FILES: tuple[str, ...] = (
    "CLAUDE.md",             # claude provider writer
    "AGENTS.md",             # codex/opencode/pi provider writer
    ".claude/settings.json",  # claude provider writer
    "opencode.json",         # opencode provider writer
    "task_history.md",       # PersistentWorkspaceSetup.ensure
    "recent_tasks.md",       # legacy rename source (recent_tasks.md -> task_history.md)
    "memory/_index.md",      # MemoryStore index (create/regenerate)
)

# Directories bootstrap may create (removed only if empty and newly created).
_BOOTSTRAP_OWNED_DIRS: tuple[str, ...] = (".claude", "memory")


def _bootstrap_legacy_migration_unsupported(workspace: Path) -> bool:
    """True when bootstrap would run the legacy ``learnings/ -> memory/`` migration.

    ``migrate_workspace`` performs its (unbounded) structural move only when
    ``memory/`` is absent AND ``learnings/`` is present; in every other case
    it is a no-op. A bounded declared-write journal cannot reverse that move
    losslessly, so the executor switch fails closed BEFORE any materialization
    or bootstrap mutation when this gate fires.
    """
    return (workspace / "learnings").exists() and not (workspace / "memory").exists()


def _is_canonical_claude_instruction_link(workspace: Path) -> bool:
    """True when ``CLAUDE.md`` is the accepted raw relative ``AGENTS.md`` link.

    THR-262 Slice B: the canonical instruction pair admits exactly one symlink
    at an owned path — a same-directory relative ``CLAUDE.md -> AGENTS.md``
    whose target is a regular file. Every other symlink remains unsupported.
    """
    import stat as _stat

    link = workspace / "CLAUDE.md"
    target = workspace / "AGENTS.md"
    try:
        if os.readlink(link) != "AGENTS.md":
            return False
        if not _stat.S_ISREG(os.lstat(target).st_mode):
            return False
        return os.path.realpath(link) == os.path.realpath(target)
    except OSError:
        return False


def _bootstrap_unsupported_owned_paths(workspace: Path) -> list[str]:
    """Return owned paths bootstrap cannot safely mutate (symlink / non-regular).

    Bootstrap may write through an owned path (following a symlink) or
    atomically replace it. A pre-existing symlink (e.g. a symlinked
    ``AGENTS.md``) or a non-regular entry (directory, FIFO, socket, device)
    at an owned path cannot be losslessly compensated: writing through a
    symlink mutates its (arbitrary, possibly external) target, and replacing
    it discards the link. The caller must therefore reject the switch BEFORE
    any mutation — including union materialization, which reconciles the
    bootstrap-owned ``.claude`` directory.

    THR-262 Slice B admission: the single canonical instruction link
    ``CLAUDE.md -> AGENTS.md`` (regular same-directory target) is accepted;
    the journal now captures/restores its exact raw link text, so it is
    losslessly compensable. Every other symlink/non-regular entry is still
    rejected.

    Detection uses ``is_symlink`` first (an ``lstat`` that never follows the
    link), so a symlink is classified without reading or touching its
    target. ``exists``/``is_file``/``is_dir`` are only consulted after the
    path is known not to be a symlink.
    """
    unsupported: list[str] = []
    for rel in _BOOTSTRAP_OWNED_FILES:
        fp = workspace / rel
        if fp.is_symlink():
            if rel == "CLAUDE.md" and _is_canonical_claude_instruction_link(workspace):
                continue
            unsupported.append(rel)
        elif fp.exists() and not fp.is_file():
            unsupported.append(rel)
    for dirname in _BOOTSTRAP_OWNED_DIRS:
        d = workspace / dirname
        if d.is_symlink():
            unsupported.append(dirname)
        elif d.exists() and not d.is_dir():
            unsupported.append(dirname)
    return unsupported


def _bootstrap_uncapturable_owned_files(workspace: Path) -> list[str]:
    """Return owned regular files whose bytes cannot be captured.

    A present regular file whose ``read_bytes()`` raises ``OSError`` is
    materially distinct from an absent file: bootstrap may overwrite it (or
    fail after partial writes) and the journal cannot restore content it
    never read. ``_bootstrap_unsupported_owned_paths`` already rejects
    symlinks and non-regular types; this gate catches regular files that are
    present but unreadable so the switch fails closed BEFORE any mutation
    (including union materialization), never representing the file as absent.
    """
    uncapturable: list[str] = []
    for rel in _BOOTSTRAP_OWNED_FILES:
        fp = workspace / rel
        if fp.is_symlink():
            # THR-262 Slice B: the admitted canonical instruction link must
            # have readable raw link text, or capture cannot restore it.
            try:
                os.readlink(fp)
            except OSError:
                uncapturable.append(rel)
        elif fp.is_file():
            try:
                fp.read_bytes()
            except OSError:
                uncapturable.append(rel)
    return uncapturable


class _BootstrapCompensationOperation(StrEnum):
    """Closed caller-visible classifications for rollback operations."""

    UNCAPTURABLE_FILE = "Uncapturable owned file cannot be compensated"
    RESTORE_LINK = "Failed to restore link"
    REMOVE_NEW_FILE = "Failed to remove new file"
    RESTORE_FILE = "Failed to restore file"
    REMOVE_NEW_DIRECTORY = "Failed to remove new directory"


@dataclass(frozen=True)
class _BootstrapCompensationFailure:
    """Structured rollback failure with raw detail reserved for daemon logs."""

    operation: _BootstrapCompensationOperation
    owned_relative_path: str
    cause: OSError | None = None

    def caller_diagnostic(self) -> str:
        """Return only stable classification and declared relative name."""
        return f"{self.operation.value} {self.owned_relative_path}"

    def raw_diagnostic(self) -> str:
        """Return full operator detail, including the original exception."""
        diagnostic = self.caller_diagnostic()
        if self.cause is not None:
            diagnostic = f"{diagnostic}: {self.cause}"
        return diagnostic


class _BootstrapRollbackJournal:
    """Bounded record of bootstrap-owned filesystem state, captured pre-bootstrap.

    Records only ``_BOOTSTRAP_OWNED_FILES``/``_BOOTSTRAP_OWNED_DIRS``
    (absence/presence/type/content). ``restore`` returns a list of
    structured compensation failures (empty when clean). Files that did not
    exist before bootstrap are removed; files that existed are restored to
    their original type, bytes, mode, and UID; newly-created owned directories
    are removed when empty.
    Canonical skill links and all other workspace content are never touched.
    No broad workspace/repos traversal occurs on either the capture or the
    restore path.

    Capture is the AUTHORITATIVE rollback read and runs in Step-0 preflight,
    BEFORE ``_executor_switch_materialize`` (the first mutation) and before
    any adapter writer, frontmatter, or audit write — so
    materialization/bootstrap/frontmatter/audit can never mutate unless every
    pre-existing declared-write target that may need restoration has already
    been captured as rollback bytes/state. The route fails closed (400
    ``executor_bootstrap_failed``) if ``capture`` observes ANY uncapturable
    declared file.

    A present regular file whose bytes cannot be read is a THIRD state,
    distinct from both absence and captured content. It is recorded in
    ``_uncapturable`` — NEVER as ``None``/absent, because ``restore``
    interprets ``None`` as "absent before bootstrap" and would delete the
    file. ``_bootstrap_uncapturable_owned_files`` rejects this state during
    Step-0 preflight (before any mutation), so capture normally does not
    encounter it; the distinct state remains the fail-closed backstop: any
    restore around an uncapturable file reports an error instead of deleting
    it, and ``uncapturable()`` lets the route abort before the first
    mutation should capture ever observe one.
    """

    @dataclass(frozen=True)
    class _RegularFileState:
        data: bytes
        mode: int
        uid: int

    __slots__ = ("_files", "_uncapturable", "_dirs", "_links")

    def __init__(self) -> None:
        self._files: dict[
            str, _BootstrapRollbackJournal._RegularFileState | None
        ] = {}
        self._uncapturable: set[str] = set()
        self._dirs: set[str] = set()
        # THR-262 Slice B: exact raw link text for admitted symlink owned
        # paths (the canonical CLAUDE.md -> AGENTS.md link), so restore can
        # recreate the link rather than collapsing it to absent.
        self._links: dict[str, str] = {}

    def uncapturable(self) -> list[str]:
        """Sorted declared files observed present-but-unreadable at capture.

        The route fails closed on this set during Step-0 preflight, before
        the first mutation — closing the second-read window where a preflight
        read succeeds but the authoritative capture read fails after
        materialization has already mutated.
        """
        return sorted(self._uncapturable)

    @classmethod
    def _capture_regular_file(cls, fp: Path) -> _RegularFileState:
        """Capture one regular file from a no-follow descriptor."""
        import stat as _stat

        flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
        fd = os.open(fp, flags)
        try:
            st = os.fstat(fd)
            if not _stat.S_ISREG(st.st_mode):
                raise OSError("declared file changed type during capture")
            with os.fdopen(fd, "rb") as fh:
                fd = -1
                data = fh.read()
            return cls._RegularFileState(
                data=data,
                mode=st.st_mode & 0o7777,
                uid=st.st_uid,
            )
        finally:
            if fd >= 0:
                os.close(fd)

    @classmethod
    def _restore_regular_file(
        cls, fp: Path, original: _RegularFileState,
    ) -> None:
        """Atomically restore one regular file without opening the live path."""
        fd, staged_raw = tempfile.mkstemp(
            prefix=f".{fp.name}.happyranch-restore-",
            dir=fp.parent,
        )
        staged = Path(staged_raw)
        try:
            with os.fdopen(fd, "wb") as fh:
                fd = -1
                fh.write(original.data)
                fh.flush()
                if original.uid != os.geteuid():
                    os.fchown(fh.fileno(), original.uid, -1)
                # Apply mode after ownership: chown may clear set-id bits.
                os.fchmod(fh.fileno(), original.mode)
            os.replace(staged, fp)
            restored = cls._capture_regular_file(fp)
            if restored != original:
                raise OSError(
                    "regular-file metadata/content verification failed: "
                    f"expected {original!r}, got {restored!r}"
                )
        finally:
            if fd >= 0:
                os.close(fd)
            try:
                staged.unlink()
            except FileNotFoundError:
                pass

    @staticmethod
    def _restore_link(fp: Path, raw_link: str) -> None:
        """Atomically restore exact raw link text via a collision-safe sibling."""
        import stat as _stat

        staged: Path | None = None
        for counter in range(64):
            candidate = fp.parent / (
                f".{fp.name}.happyranch-restore-{os.getpid()}-{counter}.lnk"
            )
            try:
                os.symlink(raw_link, candidate)
            except FileExistsError:
                continue
            staged = candidate
            break
        if staged is None:
            raise OSError("could not reserve an owned link-restore name")
        try:
            os.replace(staged, fp)
            st = os.lstat(fp)
            if not _stat.S_ISLNK(st.st_mode) or os.readlink(fp) != raw_link:
                raise OSError("link restore verification failed")
        finally:
            try:
                staged.unlink()
            except FileNotFoundError:
                pass

    @classmethod
    def capture(cls, workspace: Path) -> "_BootstrapRollbackJournal":
        import stat as _stat

        journal = cls()
        for rel in _BOOTSTRAP_OWNED_FILES:
            fp = workspace / rel
            try:
                st = os.lstat(fp)
            except FileNotFoundError:
                journal._files[rel] = None
                continue
            except OSError:
                journal._uncapturable.add(rel)
                continue
            if _stat.S_ISLNK(st.st_mode):
                # Admitted canonical instruction link: record exact raw text.
                try:
                    journal._links[rel] = os.readlink(fp)
                except OSError:
                    journal._uncapturable.add(rel)
                continue
            if _stat.S_ISREG(st.st_mode):
                try:
                    journal._files[rel] = cls._capture_regular_file(fp)
                except OSError:
                    # Present regular file whose bytes cannot be captured.
                    # Never collapse this into the absent (None) state —
                    # restore() would delete a file it could not read.
                    journal._uncapturable.add(rel)
                continue
            # Step-0 preflight rejects a non-regular declared file before
            # capture. Preserve the same fail-closed distinction here in
            # case the path changes type between those two checks.
            journal._uncapturable.add(rel)
        for dirname in _BOOTSTRAP_OWNED_DIRS:
            d = workspace / dirname
            if d.is_dir() and not d.is_symlink():
                journal._dirs.add(dirname)
        return journal

    def restore(self, workspace: Path) -> list[_BootstrapCompensationFailure]:
        errors: list[_BootstrapCompensationFailure] = []
        for rel in sorted(self._uncapturable):
            # Never delete or overwrite a file whose original bytes were
            # never captured; compensation cannot be lossless, so surface
            # the failure instead of guessing.
            errors.append(
                _BootstrapCompensationFailure(
                    _BootstrapCompensationOperation.UNCAPTURABLE_FILE,
                    rel,
                )
            )
        for rel, raw_link in sorted(self._links.items()):
            # THR-262 Slice B: recreate the exact captured raw relative link
            # (never collapse an admitted canonical link to absent).
            fp = workspace / rel
            try:
                self._restore_link(fp, raw_link)
            except OSError as exc:
                errors.append(
                    _BootstrapCompensationFailure(
                        _BootstrapCompensationOperation.RESTORE_LINK,
                        rel,
                        exc,
                    )
                )
        for rel, original in self._files.items():
            fp = workspace / rel
            if original is None:
                # Absent before bootstrap — remove anything bootstrap created.
                try:
                    import stat as _stat
                    st = os.lstat(fp)
                    if _stat.S_ISLNK(st.st_mode) or _stat.S_ISREG(st.st_mode):
                        fp.unlink()
                    else:
                        raise OSError(
                            "refusing to remove unexpected non-regular path"
                        )
                except FileNotFoundError:
                    pass
                except OSError as exc:
                    errors.append(
                        _BootstrapCompensationFailure(
                            _BootstrapCompensationOperation.REMOVE_NEW_FILE,
                            rel,
                            exc,
                        )
                    )
            else:
                try:
                    try:
                        current = self._capture_regular_file(fp)
                    except OSError:
                        current = None
                    if current != original:
                        self._restore_regular_file(fp, original)
                except OSError as exc:
                    errors.append(
                        _BootstrapCompensationFailure(
                            _BootstrapCompensationOperation.RESTORE_FILE,
                            rel,
                            exc,
                        )
                    )
        # Remove newly-created owned directories (only when empty).
        for dirname in _BOOTSTRAP_OWNED_DIRS:
            d = workspace / dirname
            if dirname not in self._dirs and d.is_dir() and not d.is_symlink():
                try:
                    if not any(d.iterdir()):
                        d.rmdir()
                except OSError as exc:
                    errors.append(
                        _BootstrapCompensationFailure(
                            _BootstrapCompensationOperation.REMOVE_NEW_DIRECTORY,
                            dirname,
                            exc,
                        )
                    )
        return errors


class SetExecutorBody(BaseModel):
    executor: str
    clean: bool = False


_BOOTSTRAP_COMPENSATION_MAX_ERRORS = 4


def _bounded_bootstrap_compensation_diagnostics(
    errors: list[_BootstrapCompensationFailure],
) -> str:
    """Return caller-safe bounded prose for rollback compensation failures.

    Raw exceptions remain available to daemon logging only.  The HTTP surface
    is derived structurally from a closed operation classification and a
    declared bootstrap-owned relative path, never from exception text.
    """
    visible = errors[:_BOOTSTRAP_COMPENSATION_MAX_ERRORS]
    if len(errors) > _BOOTSTRAP_COMPENSATION_MAX_ERRORS:
        visible = errors[:_BOOTSTRAP_COMPENSATION_MAX_ERRORS - 1]
    diagnostics = [failure.caller_diagnostic() for failure in visible]
    omitted = len(errors) - len(visible)
    if omitted > 0:
        diagnostics.append(f"... and {omitted} more compensation failure(s)")
    return "; ".join(diagnostics)


def _validate_executor(executor: str) -> None:
    """Reject an unregistered executor with an actionable error.

    Raises HTTPException(422) listing the registered values. Kept as a standalone
    helper so the validation is unit-testable without an HTTP round trip.
    """
    from runtime.orchestrator.executor_registry import get_registry as _gr
    registry = _gr()
    if not registry.is_registered(executor):
        raise HTTPException(
            status_code=422,
            detail={
                "code": "invalid_executor",
                "got": executor,
                "valid": registry.list_profile_names(),
            },
        )


@asynccontextmanager
async def _consumer_writer_interval(org, *, publisher, consumer, executor=None, preserve=False):
    coordinator = getattr(org, "_profile_coordinator", None)
    if coordinator is None:
        async with org.workflow_authority.async_writer_interval(publisher=publisher) as interval:
            yield interval
        return
    try:
        async with coordinator.consumer_writer(
            org=org, publisher=publisher, consumer=consumer,
            executor=executor, preserve=preserve,
        ) as interval:
            yield interval
    except Exception as exc:
        from runtime.workflows.profile_coordinator import ProfileCoordinatorError
        if isinstance(exc, ProfileCoordinatorError):
            raise HTTPException(status_code=409, detail={"code": exc.code}) from None
        raise


@router.put("/agents/{agent_name}/executor")
async def set_agent_executor(
    slug: str, agent_name: str, body: SetExecutorBody, org: OrgDep,
) -> dict:
    """Founder action: switch an existing agent's executor end-to-end.

    **Atomicity contract:** The six-context canonical union materialization
    MUST complete successfully BEFORE any new executor frontmatter is
    persisted and BEFORE audit logging. On union/materialization failure,
    this route returns a named HTTP error, preserves the previous executor
    configuration and audit state, and prohibits subsequent launch.

    **Authority:** org/agents/<name>.md AgentDef frontmatter is
    authoritative for executor/repository declarations (THR-095).
    Dispatch resolves ``AgentDef.executor`` via
    ``orchestrator._resolve_executor_name`` — workspace agent.yaml is
    neither reconciled by this route nor read at dispatch. Workspace
    setup on this path is bootstrap/provisioning only, and session
    repository refresh is fail-open and existing-clone-only.

    Surfaces this route touches:
      1. org agent .md frontmatter (``executor:``) — atomic rebuild via
         render_agent_text + tempfile + os.replace (same pattern as the
         manage-agent update path). This is the single authoritative store.
      2. executor bootstrap — via ContextBuilder.ensure_workspace_ready with
         ``provider=<NEW executor>`` so every built-in adapter regenerates the
         common canonical ``AGENTS.md`` plus ``CLAUDE.md -> AGENTS.md`` pair,
         while provider-specific settings and skill-root handling remain
         adapter-owned.

    Stale-file handling (away-from-Claude only): the canonical regular
    ``AGENTS.md`` plus raw ``CLAUDE.md -> AGENTS.md`` pair and the managed
    ``.claude/skills`` union are preserved for cross-provider discovery.
    By default stale executor settings are warned about; ``clean=True``
    removes only the accepted stale executor settings. Never auto-deletes
    the canonical instruction pair or either managed skills root.
    """
    paths = OrgPaths(root=org.root)

    _validate_executor(body.executor)

    existing = prompt_loader.load_agent(paths, agent_name)
    if existing is None:
        raise HTTPException(
            status_code=404,
            detail={"code": "agent_not_found", "agent": agent_name},
        )

    workspace = paths.workspaces_dir / agent_name
    has_workspace = workspace.exists()

    before_org = existing.executor
    before_ws = load_agent_config(workspace).get("executor") if has_workspace else None

    # ── Step 0: Preflight — reject the switch before ANY mutation when the
    # bounded declared-write journal cannot compensate losslessly ──
    # 1. Structured legacy learnings/ state would trigger the unbounded
    #    learnings/ -> memory/ migration during bootstrap; fail closed.
    # 2. Symlinked / non-regular owned paths cannot be restored exactly;
    #    fail closed BEFORE materialization so the union reconciler can
    #    never follow a symlinked owned directory (e.g. workspace/.claude)
    #    into an arbitrary external target.
    # 3. A present regular owned file whose read_bytes() raises OSError is
    #    materially distinct from an absent file — the journal must never
    #    represent it as absent (rollback would delete it); fail closed
    #    BEFORE materialization and every mutation.
    # 4. AUTHORITATIVE rollback capture: every pre-existing declared-write
    #    target must be captured as rollback bytes/state HERE, before the
    #    first mutation, so materialization/bootstrap/frontmatter/audit can
    #    never mutate unless capture was lossless. If the capture read fails
    #    for any declared file (a second-read window after gate 3's read
    #    succeeded), the switch fails closed before the first mutation.
    # All gates and the capture run before _executor_switch_materialize and
    # before any adapter writer — no materialize/bootstrap/frontmatter/audit
    # mutation.
    if has_workspace:
        if _bootstrap_legacy_migration_unsupported(workspace):
            raise HTTPException(
                status_code=400,
                detail={
                    "code": "executor_bootstrap_failed",
                    "error": (
                        "unsupported structured legacy learnings state: "
                        "workspace holds learnings/ without memory/, which "
                        "would require a learnings/ -> memory/ migration "
                        "during bootstrap"
                    ),
                    "message": (
                        "Executor workspace bootstrap was rejected before "
                        "any mutation because the workspace holds a "
                        "structured legacy learnings/ directory that would "
                        "require a learnings/ -> memory/ migration during "
                        "the switch. Executor switching does not perform "
                        "that migration; the previous executor has been "
                        "preserved. Migrate the workspace via the normal "
                        "init/session path before retrying."
                    ),
                },
            )
        unsupported = _bootstrap_unsupported_owned_paths(workspace)
        if unsupported:
            raise HTTPException(
                status_code=400,
                detail={
                    "code": "executor_bootstrap_failed",
                    "error": (
                        "Bootstrap-owned path is a symlink or unsupported "
                        "non-regular type: " + ", ".join(sorted(unsupported))
                    ),
                    "message": (
                        "Executor workspace bootstrap was rejected before "
                        "any mutation because an owned path is a symlink or "
                        "unsupported non-regular type. The previous executor "
                        "has been preserved. Resolve the path conflict before "
                        "retrying."
                    ),
                },
            )
        uncapturable = _bootstrap_uncapturable_owned_files(workspace)
        if uncapturable:
            raise HTTPException(
                status_code=400,
                detail={
                    "code": "executor_bootstrap_failed",
                    "error": (
                        "Bootstrap-owned file is present but cannot be "
                        "captured (read_bytes failed): "
                        + ", ".join(sorted(uncapturable))
                    ),
                    "message": (
                        "Executor workspace bootstrap was rejected before "
                        "any mutation because a bootstrap-owned file is "
                        "present but its contents could not be read, so the "
                        "switch cannot be compensated losslessly. The "
                        "previous executor has been preserved. Resolve the "
                        "file readability issue before retrying."
                    ),
                },
            )

        # ── Authoritative rollback capture (before the first mutation) ──
        # capture() is the single authoritative read of the declared write
        # surface. It runs BEFORE _executor_switch_materialize so the switch
        # can never mutate unless every pre-existing declared-write target
        # has already been captured as rollback type/content/metadata. A
        # declared file that gate 3 could read but capture cannot (TOCTOU)
        # fails closed here, before any materialize/bootstrap/frontmatter/
        # audit mutation.
        rollback_journal = _BootstrapRollbackJournal.capture(workspace)
        uncaptured = rollback_journal.uncapturable()
        if uncaptured:
            raise HTTPException(
                status_code=400,
                detail={
                    "code": "executor_bootstrap_failed",
                    "error": (
                        "Bootstrap-owned file is present but cannot be "
                        "captured (no-follow content/metadata capture failed): "
                        + ", ".join(uncaptured)
                    ),
                    "message": (
                        "Executor workspace bootstrap was rejected before "
                        "any mutation because a bootstrap-owned file is "
                        "present but its contents could not be read, so the "
                        "switch cannot be compensated losslessly. The "
                        "previous executor has been preserved. Resolve the "
                        "file readability issue before retrying."
                    ),
                },
            )

    # ── Step 1: Materialize the six-context canonical union FIRST ──
    # This MUST complete successfully before any frontmatter is persisted.
    # On failure, the previous executor is preserved and a named HTTP
    # error is returned — no partial state mutation.
    materialization_errors: list[str] = []
    if has_workspace:
        materialization_errors = await asyncio.to_thread(
            _executor_switch_materialize,
            workspace, org, agent_name, body.executor,
        )
        if materialization_errors:
            raise HTTPException(
                status_code=400,
                detail={
                    "code": "executor_materialization_failed",
                    "errors": materialization_errors,
                    "message": (
                        "Canonical skill materialization for the new executor "
                        "failed. The previous executor has been preserved. "
                        "Resolve the materialization errors before retrying."
                    ),
                },
            )

    # The materialization await above permits another accepted route writer.
    # Refresh before bootstrap so it receives the latest prompt, and reject a
    # competing executor/model change instead of silently clobbering it.
    fresh = prompt_loader.load_agent(paths, agent_name)
    if fresh is None:
        raise HTTPException(status_code=404, detail={"code": "agent_not_found", "agent": agent_name})
    if fresh.executor != existing.executor or fresh.model != existing.model:
        raise HTTPException(status_code=409, detail={"code": "executor_switch_conflict", "agent": agent_name})
    existing = fresh

    # ── Step 2: Bootstrap persistent workspace files ──
    # Run AFTER successful union but BEFORE frontmatter/audit persistence.
    # A bootstrap failure must clean up any partial files and refuse the
    # switch — no config change, no audit row. Only if this succeeds does
    # the switch become durable.
    if has_workspace:
        # ── Bounded declared-write rollback journal (THR-190) ──
        # The journal was captured losslessly in Step 0 (before the first
        # mutation). restore() compensates exactly the declared
        # bootstrap-owned write surface; never traverse or read repos/ or
        # other broad workspace content. The legacy learnings/ -> memory/
        # migration is rejected up front (Step 0), so no full-workspace
        # snapshot is ever taken on this path.
        ctx = ContextBuilder(org.settings, paths, slug=org.slug)
        try:
            ctx.ensure_workspace_ready(
                workspace,
                agent_name,
                existing.system_prompt,
                provider=body.executor,
            )
        except Exception as e:
            _logger = logging.getLogger(__name__)
            logged_error = (
                e.raw_diagnostic()
                if isinstance(e, InstructionPairConflict)
                else str(e)
            )
            _logger.error(
                "Executor switch: bootstrap failed after successful "
                "union for provider=%s agent=%s: %s",
                body.executor, agent_name, logged_error,
            )
            # ── Bounded rollback compensation ──
            # 1. Remove ONLY declared bootstrap-owned artifacts newly created
            #    by this bootstrap attempt.
            # 2. Restore any pre-existing declared bootstrap-owned files
            #    whose contents (or absence/presence/type) changed.
            # Canonical skill links and all non-owned workspace content are
            # preserved exactly. Errors during cleanup are surfaced, not
            # suppressed.
            errors = rollback_journal.restore(workspace)
            if errors:
                _logger.error(
                    "Executor switch bootstrap cleanup errors: %s",
                    "; ".join(error.raw_diagnostic() for error in errors),
                )
            response_error = (
                e.caller_diagnostic(
                    max_compensation_failures=_BOOTSTRAP_COMPENSATION_MAX_ERRORS,
                )
                if isinstance(e, InstructionPairConflict)
                else str(e)
            )
            message = (
                "Executor workspace bootstrap failed after successful skill "
                "materialization. The previous executor has been preserved. "
                "Any partial bootstrap files have been cleaned up. Resolve "
                "the bootstrap error before retrying."
            )
            if errors:
                diagnostics = _bounded_bootstrap_compensation_diagnostics(errors)
                response_error = (
                    f"{response_error}; rollback compensation incomplete: "
                    f"{diagnostics}"
                )
                message = (
                    "Executor workspace bootstrap failed after successful skill "
                    "materialization. The previous executor has been preserved. "
                    "Cleanup/restore was incomplete: "
                    f"{diagnostics}. Resolve the bootstrap error before retrying."
                )
            raise HTTPException(
                status_code=400,
                detail={
                    "code": "executor_bootstrap_failed",
                    "error": response_error,
                    "message": message,
                },
            )

    # ── Step 3: Persist the new executor frontmatter ──
    # Only reached if union materialization AND bootstrap both succeeded
    # (or no workspace exists).
    # Final supported-route compare/mutate boundary: no await occurs while
    # teams_lock is held. Atomic replace provides durable bytes, while this
    # fresh read prevents a stale whole-definition write among ASGI writers.
    async with (
        _consumer_writer_interval(
            org, publisher="set_agent_executor", consumer=agent_name,
            executor=body.executor,
        ) as authority_change,
        org.teams_lock,
    ):
        latest = prompt_loader.load_agent(paths, agent_name)
        if latest is None:
            raise HTTPException(status_code=404, detail={"code": "agent_not_found", "agent": agent_name})
        if latest.executor != existing.executor or latest.model != existing.model:
            raise HTTPException(status_code=409, detail={"code": "executor_switch_conflict", "agent": agent_name})
        updated = AgentDef(
            name=latest.name, team=latest.team, role=latest.role,
            executor=body.executor, allow_rules=latest.allow_rules,
            repos=latest.repos, enrolled_by=latest.enrolled_by,
            enrolled_at_task=latest.enrolled_at_task, enrolled_at=latest.enrolled_at,
            system_prompt=latest.system_prompt, description=latest.description,
            model=None if body.executor != latest.executor else latest.model,
        )
        from runtime.orchestrator.agent_def import render_agent_text
        active_path = paths.agents_dir / f"{agent_name}.md"
        original_bytes = active_path.read_bytes()
        fd, tmp = tempfile.mkstemp(prefix=f".{agent_name}.", suffix=".md", dir=str(paths.agents_dir))
        try:
            with authority_change.canonical_change():
                with os.fdopen(fd, "w") as fh:
                    fh.write(render_agent_text(updated))
                os.replace(tmp, active_path)
        except Exception:
            try:
                os.unlink(tmp)
            except FileNotFoundError:
                pass
            raise

    after_ws = before_ws
    stale_files: list[str] = []
    removed: list[str] = []
    cleaned = False

    if has_workspace:
        # THR-095: agent.yaml is no longer the source — skip the
        # agent.yaml reconcile.  The .md frontmatter is the single
        # source of truth.
        after_ws = before_ws

        # 4. stale Claude-only files when switching AWAY from a Claude
        #    adapter. Check the profile's canonical workspace_adapter_id (D6),
        #    not the name — a custom profile might use the pi adapter but not
        #    be named "pi".
        from runtime.orchestrator.executor_registry import get_registry as _gr
        profile = _gr().get_profile(body.executor)
        if profile is not None and profile.workspace_adapter_id != "claude":
            stale_files = [
                name for name in _CLAUDE_ONLY_WORKSPACE_FILES
                if (workspace / name).exists()
            ]
            if stale_files and body.clean:
                for name in stale_files:
                    target = workspace / name
                    if target.is_dir():
                        shutil.rmtree(target)
                    else:
                        target.unlink()
                    removed.append(name)
                cleaned = True
                # THR-262 Slice B: the shared canonical instruction pair and
                # ``.claude/skills`` are preserved. Remove ``.claude`` only
                # when cleaning genuinely emptied it.
                claude_dir = workspace / ".claude"
                if claude_dir.is_dir() and not claude_dir.is_symlink():
                    try:
                        if not any(claude_dir.iterdir()):
                            claude_dir.rmdir()
                    except OSError:
                        pass

    AuditLogger(org.db).log_agent_managed(
        scope_id="founder",
        action="update",
        name=agent_name,
        source="founder",
        actor="founder",
    )

    return {
        "agent": agent_name,
        "before": {"org_executor": before_org, "workspace_executor": before_ws},
        "after": {"org_executor": body.executor, "workspace_executor": after_ws},
        "stale_files": stale_files,
        "cleaned": cleaned,
        "removed": removed,
    }


# ---------------------------------------------------------------------------
# Founder surface: set an existing agent's model end-to-end.
# ---------------------------------------------------------------------------


class SetModelBody(BaseModel):
    model: str | None = None


@router.put("/agents/{agent_name}/model")
async def set_agent_model(
    slug: str, agent_name: str, body: SetModelBody, org: OrgDep,
) -> dict:
    """Founder action: set or clear an existing agent's model.

    THR-095: writes to org/agents/<name>.md frontmatter ONLY.
    agent.yaml is no longer the source — the .md is the single
    source of truth.
    """
    paths = OrgPaths(root=org.root)

    existing = prompt_loader.load_agent(paths, agent_name)
    if existing is None:
        raise HTTPException(
            status_code=404,
            detail={"code": "agent_not_found", "agent": agent_name},
        )

    workspace = paths.workspaces_dir / agent_name
    has_workspace = workspace.exists()

    before_model = _resolve_agent_model(paths, agent_name)

    # 1. org .md frontmatter — atomic overwrite via tempfile + os.replace.
    updated = AgentDef(
        name=existing.name,
        team=existing.team,
        role=existing.role,
        executor=existing.executor,  # type: ignore[arg-type]
        allow_rules=existing.allow_rules,
        repos=existing.repos,
        enrolled_by=existing.enrolled_by,
        enrolled_at_task=existing.enrolled_at_task,
        enrolled_at=existing.enrolled_at,
        system_prompt=existing.system_prompt,
        description=existing.description,
        model=body.model if body.model else None,
    )
    async with _consumer_writer_interval(
        org, publisher="set_agent_model", consumer=agent_name, executor=updated.executor,
    ) as authority_change:
        with authority_change.canonical_change():
            from runtime.orchestrator.agent_def import render_agent_text
            active_path = paths.agents_dir / f"{agent_name}.md"
            fd, tmp = tempfile.mkstemp(
                prefix=f".{agent_name}.", suffix=".md", dir=str(paths.agents_dir),
            )
            try:
                with os.fdopen(fd, "w") as fh:
                    fh.write(render_agent_text(updated))
                os.replace(tmp, active_path)
            except Exception:
                try:
                    os.unlink(tmp)
                except FileNotFoundError:
                    pass
                raise

    after_model = _resolve_agent_model(paths, agent_name)

    AuditLogger(org.db).log_agent_managed(
        scope_id="founder",
        action="update",
        name=agent_name,
        source="founder",
        actor="founder",
    )

    return {
        "agent": agent_name,
        "before": before_model,
        "after": after_model,
    }


@router.get("/agents/enrollments")
def list_enrollments(
    slug: str,
    org: OrgDep,
    enrollment_status: str | None = Query(default=None, alias="status"),
    team: str | None = Query(default=None),
) -> dict:
    """List enrollments with optional ?status= and/or ?team= filters.

    File-based: pending agents live in _pending/, active in agents_dir/,
    and terminated/archived agents live in agents_dir/_terminated/.
    The ?team= filter is voluntary scoping — it does not authenticate the
    caller as a member of that team. Founders always get an unfiltered view
    when neither parameter is supplied. Terminated agents are surfaced only
    when ?status=terminated is explicitly requested.
    """
    paths = OrgPaths(root=org.root)

    # Collect all enrollments from files. `team` and `role` come from the
    # parsed AgentDef so the founder UI can render the same shape as the
    # active-agents table without a second roundtrip.
    all_enrollments: list[dict] = []

    if enrollment_status == "terminated":
        for agent in prompt_loader.list_terminated(paths):
            all_enrollments.append({
                "name": agent.name,
                "team": agent.team,
                "role": agent.role,
                "executor": agent.executor,
                "description": agent.description or "",
                "status": "terminated",
                "enrolled_by": agent.enrolled_by,
                "created_at": agent.enrolled_at.isoformat() if agent.enrolled_at else None,
            })
        return {"enrollments": all_enrollments}

    for agent in prompt_loader.list_pending(paths):
        all_enrollments.append({
            "name": agent.name,
            "team": agent.team,
            "role": agent.role,
            "executor": agent.executor,
            "description": agent.description or "",
            "status": "pending",
            "enrolled_by": agent.enrolled_by,
            "created_at": agent.enrolled_at.isoformat() if agent.enrolled_at else None,
        })
    for agent in prompt_loader.list_agents(paths):
        all_enrollments.append({
            "name": agent.name,
            "team": agent.team,
            "role": agent.role,
            "executor": agent.executor,
            "description": agent.description or "",
            "status": "approved",
            "enrolled_by": agent.enrolled_by,
            "created_at": agent.enrolled_at.isoformat() if agent.enrolled_at else None,
        })

    # Apply status filter.
    if enrollment_status is not None:
        all_enrollments = [e for e in all_enrollments if e["status"] == enrollment_status]

    # Apply team filter.
    if team is not None and org.teams is not None:
        team_agents = {
            agent
            for agent in org.teams.all_agents()
            if org.teams.team_for_agent(agent) == team
        }
        all_enrollments = [e for e in all_enrollments if e["name"] in team_agents]

    return {"enrollments": all_enrollments}


@router.post("/agents/{agent_name}/approve")
async def approve_agent(slug: str, agent_name: str, org: OrgDep) -> dict:
    paths = OrgPaths(root=org.root)

    pending = prompt_loader.load_pending_agent(paths, agent_name)
    if pending is None:
        # Check if already approved (active).
        existing = prompt_loader.load_agent(paths, agent_name)
        if existing is not None:
            raise HTTPException(status_code=409, detail=f"agent is approved, not pending")
        if prompt_loader.is_terminated(paths, agent_name):
            raise HTTPException(
                status_code=409,
                detail={
                    "code": "agent_name_unavailable",
                    "name": agent_name,
                    "reason": "a terminated agent with this name exists",
                },
            )
        raise HTTPException(status_code=404, detail=f"agent {agent_name!r} not found")

    # Refuse to promote an agent whose declared team isn't registered.
    # For workers, manage-agent enroll already added the team — this is
    # defense in depth against hand-edited pending files. For managers,
    # this is the primary guard: bootstrap managers must have their team
    # wired in teams.yaml first, never the other way around.
    if org.teams is None or pending.team not in org.teams.teams():
        raise HTTPException(
            status_code=409,
            detail={
                "code": "team_not_registered",
                "agent": agent_name,
                "team": pending.team,
                "fix": "add the team to teams.yaml first, then approve",
            },
        )

    async with _consumer_writer_interval(
        org, publisher="approve_agent", consumer=agent_name, preserve=True,
    ) as authority_change:
        with authority_change.canonical_change():
            promoted = False
            try:
                agent_def = prompt_loader.approve_agent(paths, agent_name)
                promoted = True
                if (
                    agent_def.role == "manager"
                    and is_eligible_policy_manager(
                        root=org.root,
                        agent_name=agent_name,
                        team=agent_def.team,
                        teams=org.teams,
                    )
                ):
                    # Bootstrap-manager approval is the supported lifecycle that
                    # can make an already-registered team's manager eligible.
                    # Initialize inside this same supported canonical change so
                    # the published snapshot and launch resolver cannot diverge.
                    AuthorityPolicyStore(org.db).ensure_authority_selector(
                        agent_def.team,
                    )
            except FileExistsError:
                raise HTTPException(status_code=409, detail=f"agent is approved, not pending")
            except Exception:
                if promoted:
                    active_path = paths.agents_dir / f"{agent_name}.md"
                    pending_path = paths.pending_agents_dir / f"{agent_name}.md"
                    if active_path.exists() and not pending_path.exists():
                        os.replace(active_path, pending_path)
                raise

    workspace = paths.workspaces_dir / agent_name
    workspace.mkdir(parents=True, exist_ok=True)

    # THR-095: agent.yaml is no longer the source for executor/repos.
    # The .md frontmatter (AgentDef) is the single source of truth.
    # Repos from AgentDef.repos; executor from AgentDef.executor.
    repos = agent_def.repos or {}

    ctx = ContextBuilder(org.settings, paths, slug=org.slug)
    for repo_name, url in repos.items():
        await asyncio.to_thread(ctx.clone_repo, workspace, repo_name, url)

    # Promotion is synchronous before the first await, but cloning is not.
    # Use a fresh active snapshot for bootstrap; it does not serialize later
    # workspace generation against arbitrary canonical writers.
    fresh = prompt_loader.load_agent(paths, agent_name)
    if fresh is None:
        raise HTTPException(status_code=404, detail=f"agent {agent_name!r} not found")

    await asyncio.to_thread(
        ctx.ensure_workspace_ready,
        workspace,
        agent_name,
        fresh.system_prompt,
        provider=fresh.executor,
    )
    await asyncio.to_thread(ctx.create_agent_dirs, workspace, agent_name)

    return {"ok": True}


@router.post("/agents/{agent_name}/reject")
async def reject_agent(slug: str, agent_name: str, org: OrgDep) -> dict:
    paths = OrgPaths(root=org.root)

    # Fresh-read after acquiring the locks so a promotion or replacement that
    # wins while this request waits cannot be unlinked or removed by stale team.
    async with (
        org.workflow_authority.async_writer_interval(
            publisher="reject_agent",
        ) as authority_change,
        org.teams_lock,
    ):
        with authority_change.canonical_change():
            pending = prompt_loader.load_pending_agent(paths, agent_name)
            if pending is None:
                existing = prompt_loader.load_agent(paths, agent_name)
                if existing is not None:
                    raise HTTPException(status_code=409, detail=f"agent is approved, not pending")
                raise HTTPException(status_code=404, detail=f"agent {agent_name!r} not found")
            # Drop the file first; holding teams_lock keeps the synchronous unlink
            # and teams-yaml mutation paired with the freshly read pending state.
            try:
                prompt_loader.reject_agent(paths, agent_name)
            except FileNotFoundError:
                raise HTTPException(status_code=404, detail=f"agent {agent_name!r} not found")
            # manage_agent.enroll added this worker to teams.yaml when it wrote the
            # pending file. Reject must undo both — otherwise the agent stays in
            # team membership forever and re-enrollment hits "duplicate" on the
            # team-side too. remove_worker is a no-op if the agent isn't a worker
            # under pending.team, so this is safe even if teams drifted.
            if org.teams is not None and pending.team in org.teams.teams():
                org.teams.remove_worker(pending.team, agent_name)

    return {"ok": True}


# THR-032 Phase R: canonical path is /memory; /learnings is kept as a hidden
# forwarder for one rollout cycle so in-flight callers don't break.
@router.post("/agents/{agent_name}/memory")
@router.post("/agents/{agent_name}/learnings", include_in_schema=False)
async def append_learning(
    slug: str, agent_name: str, body: LearningBody, org: OrgDep,
) -> dict:
    workspace = org.root / "workspaces" / agent_name
    if (workspace / "memory").exists() or (workspace / "learnings").exists():
        raise HTTPException(
            status_code=410,
            detail={
                "error": "endpoint_deprecated_for_migrated_workspace",
                "migrate_to": f"POST /api/v1/orgs/{slug}/agents/{agent_name}/memory/entries",
            },
        )
    expected = org.sessions.get_active(body.task_id, agent_name)
    if expected is None:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={"code": "unknown_session", "task_id": body.task_id, "agent": agent_name},
        )
    if expected != body.session_id:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={"code": "session_mismatch", "active": expected, "got": body.session_id},
        )
    if org.sessions.is_recovery_session(body.task_id, agent_name, body.session_id):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"code": "recovery_purpose_forbidden"},
        )

    learnings_path = workspace / "learnings.md"

    # Hold the lock across exists/init/append so two concurrent posts can't both
    # see the file as missing and race the header write.
    async with org.db_lock:
        _append_to_learnings_file(learnings_path, agent_name, body.text)
    return {"ok": True}


# ---------------------------------------------------------------------------
# Memory read routes + 412 pre-migration guard
# ---------------------------------------------------------------------------


def _workspace_memory_store(org: OrgState, agent_name: str) -> MemoryStore:
    """Return the per-agent MemoryStore.

    Raises 404 if the agent workspace doesn't exist, 412 if it exists but
    hasn't been migrated to the structured per-entry layout. A legacy
    ``learnings/`` workspace is moved forward to ``memory/`` lazily here
    (idempotent + lossless, THR-032 Phase R) so first memory access migrates it.
    """
    workspace = org.root / "workspaces" / agent_name
    if not workspace.exists():
        raise HTTPException(
            status_code=404,
            detail={"error": "agent_not_found", "agent": agent_name},
        )
    migrate_workspace(workspace)
    memory_dir = workspace / "memory"
    if not memory_dir.exists():
        raise HTTPException(
            status_code=412,
            detail={"error": "workspace_not_migrated", "migrate_first": True},
        )
    org_cfg = load_org_config(OrgPaths(root=org.root))
    return MemoryStore(memory_dir, compaction_config=org_cfg.memory_compaction)


def _entry_to_dict(entry: MemoryItem) -> dict:
    result = {
        "id": entry.id,
        "slug": entry.slug,
        "title": entry.title,
        "topic": entry.topic,
        "tags": entry.tags,
        "body": entry.body,
        "source_task": entry.source_task,
        "related_to": entry.related_to,
        "supersedes": entry.supersedes,
        "promoted_to": entry.promoted_to,
        "authored_by": entry.authored_by,
        "authored_at": entry.authored_at,
        "updated_by": entry.updated_by,
        "updated_at": entry.updated_at,
        "lifecycle": entry.lifecycle,
        "provenance": entry.provenance,
        "salience": entry.salience,
        "last_verified": entry.last_verified,
    }
    # THR-091: surface entry age at recall
    result.update(entry.age_summary())
    return result


@router.get("/agents/{agent_name}/memory/entries/")


@router.get("/agents/{agent_name}/learnings/entries/", include_in_schema=False)
async def list_learnings(
    slug: str,
    agent_name: str,
    org: OrgDep,
    topic: str | None = None,
    tag: str | None = None,
    promoted: bool | None = None,
) -> dict:
    store = _workspace_memory_store(org, agent_name)
    summaries = store.list_entries(topic=topic, tag=tag, promoted=promoted)
    return {
        "entries": [
            {
                "id": s.id,
                "slug": s.slug,
                "title": s.title,
                "topic": s.topic,
                "tags": s.tags,
                "promoted_to": s.promoted_to,
                "updated_at": s.updated_at,
            }
            for s in summaries
        ],
    }


@router.get("/agents/{agent_name}/memory/entries/{id_or_slug}")


@router.get("/agents/{agent_name}/learnings/entries/{id_or_slug}", include_in_schema=False)
async def get_learning(
    slug: str,
    agent_name: str,
    id_or_slug: str,
    org: OrgDep,
    session_id: str | None = Query(None),
) -> dict:
    store = _workspace_memory_store(org, agent_name)
    try:
        entry = store.read_entry(id_or_slug)
    except LearningNotFound:
        raise HTTPException(
            status_code=404,
            detail={"error": "id_not_found", "id_or_slug": id_or_slug},
        )
    # THR-091 Slice 2: validate session_id via SessionTracker before
    # using it for correlation.  Only a server-side-verified
    # (org_slug, task_id, agent_name) tuple qualifies for same-session
    # attribution.  No validated context → source=explicit_or_other.
    validated_task_id: str | None = None
    validated_session_id: str | None = None
    if session_id is not None:
        ctx = org.sessions.get_context_by_session(session_id)
        if ctx is not None:
            ctx_org, task_id, ctx_agent = ctx
            if ctx_org == slug and ctx_agent == agent_name:
                validated_task_id = task_id
                validated_session_id = session_id
    AuditLogger(org.db).log_memory_read(
        agent=agent_name,
        id=entry.id,
        slug=entry.slug,
        session_id=validated_session_id,
        task_id=validated_task_id,
    )
    return _entry_to_dict(entry)


class LearningSearchBody(BaseModel):
    query: str
    limit: int | None = None
    include_promoted: bool | None = None
    include_evicted: bool | None = None
    include_superseded: bool | None = None
    include_kb: bool | None = None


@router.post("/agents/{agent_name}/memory/entries/search")


@router.post("/agents/{agent_name}/learnings/entries/search", include_in_schema=False)
async def search_learnings(
    slug: str,
    agent_name: str,
    body: LearningSearchBody,
    org: OrgDep,
    session_id: str | None = Query(None),
) -> dict:
    org_cfg = load_org_config(OrgPaths(root=org.root))
    sc = org_cfg.memory_search
    store = _workspace_memory_store(org, agent_name)
    # Merge: explicit request fields override org config defaults
    limit = body.limit if body.limit is not None else sc.default_limit
    include_promoted = body.include_promoted if body.include_promoted is not None else False
    include_evicted = body.include_evicted if body.include_evicted is not None else sc.include_evicted_by_default
    include_superseded = body.include_superseded if body.include_superseded is not None else sc.include_superseded_by_default
    include_kb = body.include_kb if body.include_kb is not None else sc.include_kb_by_default
    hits = store.search(
        body.query,
        limit=limit,
        include_promoted=include_promoted,
        include_evicted=include_evicted,
        include_superseded=include_superseded,
    )
    warnings: list[str] = []
    # THR-032 P4b: opt-in read-only KB federation
    if include_kb:
        kb_store = KBStore(org.root / "kb")
        try:
            kb_hits = kb_store.search(body.query, limit=limit)
            for kh in kb_hits:
                hits.append(LearningSearchHit(
                    id=kh.slug, slug=kh.slug, title=kh.title,
                    snippet=kh.snippet, score=kh.score,
                    source="kb",
                    lifecycle="valid", provenance="experiential",
                    salience=50, updated_at=None,
                ))
        except Exception as exc:
            warnings.append(f"KB search failed: {exc}")
    # THR-032 P4b: merge + sort combined memory+KB hits, then truncate
    hits.sort(key=lambda h: (-h.score, h.updated_at or "", h.title, h.id))
    hits = hits[:limit]
    # THR-091 Slice 2: log privacy-preserving search telemetry.
    # Store only memory IDs (exclude KB hits), plus counts/correlation.
    # NEVER persist raw query text, snippets, titles, or bodies.
    # Validate session_id via SessionTracker before using it for
    # correlation — only a server-side-verified context qualifies.
    memory_hit_ids = [h.id for h in hits if h.source != "kb"]
    kb_hit_count = sum(1 for h in hits if h.source == "kb")
    validated_task_id: str | None = None
    validated_session_id: str | None = None
    if session_id is not None:
        ctx = org.sessions.get_context_by_session(session_id)
        if ctx is not None:
            ctx_org, task_id, ctx_agent = ctx
            if ctx_org == slug and ctx_agent == agent_name:
                validated_task_id = task_id
                validated_session_id = session_id
    AuditLogger(org.db).log_memory_search(
        agent=agent_name,
        session_id=validated_session_id,
        memory_ids=memory_hit_ids,
        hit_count=len(memory_hit_ids),
        kb_hit_count=kb_hit_count,
        task_id=validated_task_id,
    )
    result: dict = {
        "hits": [
            {
                "id": h.id,
                "slug": h.slug,
                "title": h.title,
                "snippet": h.snippet,
                "score": h.score,
                "source": h.source,
                "lifecycle": h.lifecycle,
                "provenance": h.provenance,
                "salience": h.salience,
                "updated_at": h.updated_at,
            }
            for h in hits
        ],
    }
    if warnings:
        result["warnings"] = warnings
    return result


# ---------------------------------------------------------------------------
# Learnings write routes — POST add + PUT update
# ---------------------------------------------------------------------------


class LearningAddBody(BaseModel):
    slug: str
    title: str
    topic: str
    body: str
    tags: list[str] = []
    source_task: str | None = None
    related_to: list[str] = []
    supersedes: str | None = None


class LearningUpdateBody(BaseModel):
    slug: str
    title: str
    topic: str
    body: str
    tags: list[str] = []
    source_task: str | None = None
    related_to: list[str] = []
    supersedes: str | None = None


def _invalid_entry_to_http(err: InvalidLearningEntry) -> HTTPException:
    return HTTPException(status_code=400, detail={"error": err.code, "message": str(err)})


@router.post("/agents/{agent_name}/memory/entries/", status_code=201)


@router.post("/agents/{agent_name}/learnings/entries/", status_code=201, include_in_schema=False)
async def add_learning(
    slug: str, agent_name: str, body: LearningAddBody, org: OrgDep,
) -> dict:
    store = _workspace_memory_store(org, agent_name)
    async with org.db_lock:
        new_id = store.next_id()
        entry = MemoryItem(
            id=new_id,
            slug=body.slug,
            title=body.title,
            topic=body.topic,
            body=body.body,
            tags=list(body.tags),
            source_task=body.source_task,
            related_to=list(body.related_to),
            supersedes=body.supersedes,
        )
        try:
            written = store.write_entry(entry, agent=agent_name)
        except InvalidLearningEntry as e:
            raise _invalid_entry_to_http(e)
        except LearningIdExists as e:
            raise HTTPException(status_code=409, detail={"error": "id_exists", "id": e.id})
        except LearningSlugExists as e:
            raise HTTPException(status_code=409, detail={"error": "slug_exists", "slug": e.slug})
        # THR-032 P3b: audit supersede lifecycle transition if it occurred
        sup_target = getattr(written, '_superseded_target_id', None)
        store.regenerate_index()
        if sup_target is not None:
            AuditLogger(org.db).log_memory_lifecycle_changed(
                agent=agent_name,
                id=sup_target,
                from_lifecycle="valid",
                to_lifecycle="superseded",
                reason=f"superseded by {written.id}",
                source="supersedes",
            )
        AuditLogger(org.db).log_memory_added(
            agent=agent_name,
            id=written.id,
            slug=written.slug,
            topic=written.topic,
            tags=written.tags,
            source_task=written.source_task,
        )
    rel_path = f"memory/{written.id}-{written.slug}.md"
    return {"id": written.id, "path": rel_path, "authored_at": written.authored_at}


@router.put("/agents/{agent_name}/memory/entries/{id}")


@router.put("/agents/{agent_name}/learnings/entries/{id}", include_in_schema=False)
async def update_learning(
    slug: str, agent_name: str, id: str, body: LearningUpdateBody, org: OrgDep,
) -> dict:
    store = _workspace_memory_store(org, agent_name)
    # THR-091 WS-A: preserve last_verified on normal update (read-modify-write).
    # The PUT body deliberately does NOT carry last_verified — we carry forward
    # the existing value so a content update never silently clears verification state.
    try:
        prior_last_verified = store.read_entry(id).last_verified
    except LearningNotFound:
        prior_last_verified = None
    entry = MemoryItem(
        id=id,
        slug=body.slug,
        title=body.title,
        topic=body.topic,
        body=body.body,
        tags=list(body.tags),
        source_task=body.source_task,
        related_to=list(body.related_to),
        supersedes=body.supersedes,
        last_verified=prior_last_verified,
    )
    async with org.db_lock:
        try:
            prior_slug = store.read_entry(id).slug
        except LearningNotFound:
            prior_slug = None  # store.update_entry will raise its own LearningNotFound
        try:
            written = store.update_entry(id, entry, agent=agent_name)
        except LearningNotFound:
            raise HTTPException(status_code=404, detail={"error": "id_not_found", "id": id})
        except PromotedLocked as e:
            raise HTTPException(status_code=409, detail={"error": "promoted_locked", "id": e.id, "kb_slug": e.kb_slug})
        except InvalidLearningId:
            raise HTTPException(status_code=400, detail={"error": "invalid_id", "id": id})
        except InvalidLearningEntry as e:
            raise _invalid_entry_to_http(e)
        except LearningSlugExists as e:
            raise HTTPException(status_code=409, detail={"error": "slug_exists", "slug": e.slug})
        # THR-032 P3b: audit supersede lifecycle transition if it occurred
        sup_target = getattr(written, '_superseded_target_id', None)
        store.regenerate_index()
        if sup_target is not None:
            AuditLogger(org.db).log_memory_lifecycle_changed(
                agent=agent_name,
                id=sup_target,
                from_lifecycle="valid",
                to_lifecycle="superseded",
                reason=f"superseded by {written.id}",
                source="supersedes",
            )
        AuditLogger(org.db).log_memory_updated(
            agent=agent_name,
            id=written.id,
            slug_changed=prior_slug is not None and prior_slug != written.slug,
        )
    return _entry_to_dict(written)


class LearningPromoteBody(BaseModel):
    kb_slug: str


@router.post("/agents/{agent_name}/memory/entries/reindex")


@router.post("/agents/{agent_name}/learnings/entries/reindex", include_in_schema=False)
async def reindex_learnings(slug: str, agent_name: str, org: OrgDep) -> dict:
    store = _workspace_memory_store(org, agent_name)
    async with org.db_lock:
        store.regenerate_index()
    return {"ok": True}


@router.post("/agents/{agent_name}/memory/entries/{id}/promote")


@router.post("/agents/{agent_name}/learnings/entries/{id}/promote", include_in_schema=False)
async def promote_learning(
    slug: str, agent_name: str, id: str, body: LearningPromoteBody, org: OrgDep,
) -> dict:
    if not body.kb_slug:
        raise HTTPException(status_code=400, detail={"error": "kb_slug_missing"})
    kb_store = KBStore(org.root / "kb")
    try:
        kb_store.validate_slug(body.kb_slug)
    except InvalidSlug:
        raise HTTPException(
            status_code=400, detail={"error": "invalid_kb_slug", "kb_slug": body.kb_slug},
        )
    if not kb_store.path_for(body.kb_slug).exists():
        raise HTTPException(
            status_code=404,
            detail={"error": "kb_slug_not_found", "kb_slug": body.kb_slug},
        )
    store = _workspace_memory_store(org, agent_name)
    async with org.db_lock:
        try:
            written = store.promote(id, kb_slug=body.kb_slug, agent=agent_name)
        except InvalidLearningId:
            raise HTTPException(status_code=400, detail={"error": "invalid_id", "id": id})
        except LearningNotFound:
            raise HTTPException(status_code=404, detail={"error": "id_not_found", "id": id})
        except PromotedLocked as e:
            raise HTTPException(status_code=409, detail={"error": "promoted_locked", "id": e.id, "kb_slug": e.kb_slug})
        except InvalidLearningEntry as e:
            raise _invalid_entry_to_http(e)
        store.regenerate_index()
        AuditLogger(org.db).log_memory_promoted(
            agent=agent_name,
            id=written.id,
            kb_slug=body.kb_slug,
        )
    return _entry_to_dict(written)


class LifecyclePatchBody(BaseModel):
    lifecycle: str
    reason: str | None = None


@router.patch("/agents/{agent_name}/memory/entries/{id}/lifecycle")
@router.patch(
    "/agents/{agent_name}/learnings/entries/{id}/lifecycle",
    include_in_schema=False,
)
async def patch_lifecycle(
    slug: str, agent_name: str, id: str, body: LifecyclePatchBody, org: OrgDep,
) -> dict:
    if not body.reason or not body.reason.strip():
        raise HTTPException(
            status_code=400,
            detail={"error": "reason_required", "message": "reason must be non-empty"},
        )
    store = _workspace_memory_store(org, agent_name)
    async with org.db_lock:
        try:
            updated, prior = store.set_lifecycle(
                id, body.lifecycle, agent=agent_name, reason=body.reason.strip(),
            )
        except InvalidLearningId:
            raise HTTPException(status_code=400, detail={"error": "invalid_id", "id": id})
        except LearningNotFound:
            raise HTTPException(status_code=404, detail={"error": "id_not_found", "id": id})
        except PromotedLocked as e:
            raise HTTPException(
                status_code=409,
                detail={"error": "promoted_locked", "id": e.id, "kb_slug": e.kb_slug},
            )
        except InvalidLearningEntry as e:
            raise _invalid_entry_to_http(e)
        store.regenerate_index()
        AuditLogger(org.db).log_memory_lifecycle_changed(
            agent=agent_name,
            id=updated.id,
            from_lifecycle=prior,
            to_lifecycle=updated.lifecycle,
            reason=body.reason.strip(),
            source="manual",
        )
    result = _entry_to_dict(updated)
    result["previous_lifecycle"] = prior
    return result


class CompactBody(BaseModel):
    dry_run: bool = True
    # Optional per-request overrides for compaction policy knobs.
    # When absent, org config defaults apply.
    salience_floor: int | None = None
    stale_days: int | None = None
    superseded_grace_days: int | None = None
    max_evictions_per_run: int | None = None


@router.post("/agents/{agent_name}/memory/entries/compact")
async def compact_memory(
    slug: str, agent_name: str, body: CompactBody, org: OrgDep,
) -> dict:
    org_cfg = load_org_config(OrgPaths(root=org.root))
    cc = org_cfg.memory_compaction
    # Dry-runs are always allowed (read-only). Apply requires config enablement.
    if not body.dry_run and not cc.enabled:
        raise HTTPException(
            status_code=403,
            detail={"error": "compaction_disabled",
                    "message": "memory compaction apply is disabled in org config"},
        )
    # Build policy: org config defaults, with explicit request-field overrides
    policy = MemoryCompactionPolicy(
        salience_floor=body.salience_floor if body.salience_floor is not None else cc.salience_floor,
        stale_days=body.stale_days if body.stale_days is not None else cc.stale_days,
        superseded_grace_days=body.superseded_grace_days if body.superseded_grace_days is not None else cc.superseded_grace_days,
        max_evictions_per_run=body.max_evictions_per_run if body.max_evictions_per_run is not None else cc.max_evictions_per_run,
    )
    store = _workspace_memory_store(org, agent_name)
    async with org.db_lock:
        result = store.compact(dry_run=body.dry_run, policy=policy)
        # Audit each eviction
        if not body.dry_run:
            for evicted_id in result.evicted:
                AuditLogger(org.db).log_memory_lifecycle_changed(
                    agent=agent_name,
                    id=evicted_id,
                    from_lifecycle="valid" if evicted_id not in {
                        c.id for c in result.candidates if c.current_lifecycle == "superseded"
                    } else "superseded",
                    to_lifecycle="evicted",
                    reason=f"compaction (dry_run={body.dry_run})",
                    source="compaction",
                )
        return {
            "dry_run": result.dry_run,
            "candidates": [
                {"id": c.id, "title": c.title, "reason": c.reason, "current_lifecycle": c.current_lifecycle}
                for c in result.candidates
            ],
            "evicted": result.evicted,
            "skipped": result.skipped,
            "errors": result.errors,
        }
