from __future__ import annotations

from runtime.infrastructure.database import Database
from runtime.models import CompletionReport, TokenUsage


class AuditLogger:
    def __init__(self, db: Database) -> None:
        self._db = db

    def log_session_start(
        self,
        task_id: str,
        agent: str,
        workspace: str,
        *,
        session_id: str | None = None,
        invocation_purpose: str = "unattributed",
        executor: str | None = None,
        model: str | None = None,
    ) -> None:
        self._db.insert_audit_log(
            task_id=task_id,
            agent=agent,
            action="session_start",
            payload={
                "workspace": workspace,
                "session_id": session_id,
                "invocation_purpose": invocation_purpose,
                "executor": executor,
                "model": model,
            },
        )

    def log_session_end(
        self,
        task_id: str,
        agent: str,
        duration_seconds: int,
        token_usage: TokenUsage | None = None,
    ) -> None:
        payload: dict = {"duration_seconds": duration_seconds}
        if token_usage is not None:
            payload["token_usage"] = token_usage.model_dump()
            payload["token_count"] = token_usage.total
        else:
            payload["token_count"] = None
        self._db.insert_audit_log(
            task_id=task_id,
            agent=agent,
            action="session_end",
            payload=payload,
        )

    def log_completion_report(self, report: CompletionReport) -> None:
        # The task_results row is written by the agent callback at
        # POST /tasks/{task_id}/completion (routes/tasks.py); audit logger only
        # records the semantic event. Writing both produced duplicate rows
        # (one per task_result, ~20s apart) — see TASK-137 post-mortem.
        self._db.insert_audit_log(
            task_id=report.task_id,
            agent=report.agent,
            action="completion_report",
            payload=report.model_dump(),
        )

    def log_review_verdict(
        self,
        task_id: str,
        reviewer: str,
        verdict: str,
        feedback: str | None,
        reviewed_agent: str | None = None,
    ) -> None:
        self._db.insert_audit_log(
            task_id=task_id,
            agent=reviewer,
            action="review_verdict",
            payload={
                "verdict": verdict,
                "feedback": feedback,
                "reviewed_agent": reviewed_agent,
            },
        )

    def log_escalation(self, task_id: str, agent: str, reason: str) -> None:
        self._db.insert_audit_log(
            task_id=task_id,
            agent=agent,
            action="escalation",
            payload={"reason": reason},
        )

    def log_daemon_restart_failure(
        self, task_id: str, agent: str,
    ) -> None:
        """Recorded by _sweep_on_startup when an IN_PROGRESS task is FAILED
        due to a daemon restart. Distinct from log_escalation (which signals
        a manager-initiated escalate decision)."""
        self._db.insert_audit_log(
            task_id=task_id, agent=agent,
            action="daemon_restart_failure",
            payload={"reason": "daemon restarted mid-task"},
        )

    def log_escalation_resolved(
        self,
        task_id: str,
        decision: str,
        rationale: str,
        *,
        actor: str = "founder",
        thread_id: str | None = None,
        resolution_path: str = "manual_break_glass",
    ) -> None:
        """Record that an escalated task was resolved.

        THR-080: `actor` records the real agent who resolved (manager/thread-
        originated continue, or founder). `thread_id` cites the dispatching
        thread when the resolution came from the thread surface. Back-compat:
        both params are keyword-only with founder/None defaults.
        """
        payload: dict = {
            "decision": decision,
            "rationale": rationale,
            "resolution_path": resolution_path,
        }
        if thread_id is not None:
            payload["thread_id"] = thread_id
        self._db.insert_audit_log(
            task_id=task_id,
            agent=actor,
            action="escalation_resolved",
            payload=payload,
        )

    def log_zombie_flagged(self, task_id: str, agent: str) -> None:
        """Recorded by the ongoing zombie reaper when a zombie task is first
        flagged (THR-090 Track B)."""
        self._db.insert_audit_log(
            task_id=task_id, agent=agent,
            action="zombie_flagged",
            payload={"reason": "zombie detected — dead pid + stale heartbeat"},
        )

    def log_zombie_cancelled(self, task_id: str, agent: str) -> None:
        """Recorded by the ongoing zombie reaper when a flagged zombie is
        cancelled after TTL expiry (THR-090 Track B)."""
        self._db.insert_audit_log(
            task_id=task_id, agent=agent,
            action="zombie_cancelled",
            payload={"reason": "zombie cancelled after TTL expiry"},
        )

    def log_zombie_cleared(self, task_id: str, agent: str) -> None:
        """Recorded by the ongoing zombie reaper when a flagged zombie recovers
        before TTL expiry (THR-090 Track B)."""
        self._db.insert_audit_log(
            task_id=task_id, agent=agent,
            action="zombie_cleared",
            payload={"reason": "zombie recovered — flag cleared"},
        )

    def log_portability_reconciled(
        self,
        *,
        task_id: str,
        actor: str,
        request_hash: str,
        evidence: dict,
        disposition: str,
        before: dict,
        after: dict,
    ) -> None:
        """Record a founder-authorized portability zombie reconciliation.

        Uses the ordinary ``task_id`` scope (the reconciled task), not a new
        scope prefix. Payload carries the SHA-256 request hash, founder evidence,
        disposition, and before/after state so the human decision is auditable.
        """
        self._db.insert_audit_log(
            task_id=task_id,
            agent=actor,
            action="portability_reconciled",
            payload={
                "request_hash": request_hash,
                "evidence": evidence,
                "disposition": disposition,
                "before": before,
                "after": after,
            },
        )

    def log_task_cancelled(
        self, task_id: str, rationale: str, cascade: bool, actor: str = "founder",
    ) -> None:
        self._db.insert_audit_log(
            task_id=task_id,
            agent=actor,
            action="task_cancelled",
            payload={"rationale": rationale, "cascade": cascade},
        )

    def log_progress(self, task_id: str, agent: str, message: str) -> None:
        """Record an agent-controlled mid-task progress note.

        Distinct from completion_report: this is a semantic checkpoint the
        agent emits while still working. Used by `happyranch tail` and `happyranch details`
        to give the founder visibility into long-running tasks without
        waiting for the final completion callback.
        """
        self._db.insert_audit_log(
            task_id=task_id,
            agent=agent,
            action="progress",
            payload={"message": message},
        )

    def log_auto_revisit_of(
        self,
        task_id: str,
        predecessor_root: str,
        failed_task: str,
        failed_agent: str,
        cascade: list[str],
        failure_kind: str,
        error_context: dict,
        attempt: int,
    ) -> None:
        """Record on the NEW root that it is an orchestrator-triggered revisit.

        Parallel to ``log_revisit_of`` (founder-triggered) but distinguished
        by action name so the prompt-injection step can render a different
        first-step header — and so we can count auto-revisits in the chain
        without conflating them with founder revisits when enforcing the
        per-chain cap.

        ``failure_kind`` is the classified granular failure mode
        (session_timeout / no_callback / rate_limit / executor_error /
        agent_exception / session_failed); hoisted to top-level of the
        payload so per-kind cap counting can read it with a single dict
        lookup without parsing ``error_context``. See
        ``docs/superpowers/specs/2026-05-25-session-timeout-auto-route-design.md``.

        ``error_context`` is the structured failure payload produced by
        ``_executor_failure_context``: mode, rc, stderr/stdout tail, etc.
        ``attempt`` is the 1-indexed auto-revisit number in this chain.
        """
        self._db.insert_audit_log(
            task_id=task_id,
            agent="orchestrator",
            action="auto_revisit_of",
            payload={
                "predecessor_root": predecessor_root,
                "failed_task": failed_task,
                "failed_agent": failed_agent,
                "cascade": cascade,
                "failure_kind": failure_kind,
                "error_context": error_context,
                "attempt": attempt,
            },
        )

    def log_orchestration_step(
        self, task_id: str, step_number: int, decision: dict
    ) -> int:
        return self._db.insert_audit_log(
            task_id=task_id,
            agent="orchestrator",
            action="orchestration_step",
            payload={"step_number": step_number, "decision": decision},
        )

    def log_chain_auto_advance(
        self,
        parent_task_id: str,
        *,
        leg_index: int,
        spawned_child_id: str,
        triggering_child_id: str,
        triggering_verdict: str | None,
        chain_origin_step_audit_id: int,
    ) -> None:
        """Audit row for an orchestrator-driven chain advance. Distinct from
        `orchestration_step` (which is manager-authored). Does NOT correspond to
        a tasks.orchestration_step_count bump — chains are one decision, multiple
        auto-advances.
        """
        self._db.insert_audit_log(
            task_id=parent_task_id,
            agent="orchestrator",
            action="chain_auto_advance",
            payload={
                "leg_index": leg_index,
                "spawned_child_id": spawned_child_id,
                "triggering_child_id": triggering_child_id,
                "triggering_verdict": triggering_verdict,
                "chain_origin_step_audit_id": chain_origin_step_audit_id,
            },
        )

    def log_task_blocked_on_jobs(
        self,
        task_id: str,
        agent: str,
        blocking_job_ids: list[str],
        output_summary_excerpt: str,
    ) -> None:
        """Written when run_step_impl transitions a task to in_progress+blocked_on_job
        in response to report.status=blocked + report.waiting_on_job_ids non-empty.
        Spec §7.
        """
        self._db.insert_audit_log(
            task_id=task_id,
            agent=agent,
            action="task_blocked_on_jobs",
            payload={
                "agent": agent,
                "blocking_job_ids": blocking_job_ids,
                "output_summary_excerpt": output_summary_excerpt,
            },
        )

    def log_fanout_spawned(
        self,
        task_id: str,
        agent: str,
        width: int,
        children_ids: list[str],
    ) -> None:
        """Written when run_step_impl atomically spawns all fan-out children."""
        self._db.insert_audit_log(
            task_id=task_id,
            agent=agent,
            action="fanout_spawned",
            payload={
                "agent": agent,
                "width": width,
                "children_ids": children_ids,
            },
        )

    def log_fanout_review_not_approved(
        self,
        task_id: str,
        *,
        reason: str,
    ) -> None:
        """Written when a pending-review fan-out re-enters and the review
        job was rejected or failed — children will NOT be spawned.

        Uses its own action so it does not suppress BLOCKED-JOBS-RESULTS
        (unlike ``log_orchestration_step``, which always writes
        ``action="orchestration_step"`` and would hide the job-outcome
        header from the manager prompt).
        """
        self._db.insert_audit_log(
            task_id=task_id,
            agent="orchestrator",
            action="fanout_review_not_approved",
            payload={"reason": reason},
        )

    def log_fanout_join(
        self,
        task_id: str,
        width: int,
        children_ids: list[str],
        context_markdown: str,
    ) -> None:
        """Written after try_claim_for_step wins on a fan-out parent and join
        context is built. Read by the fan-out join header injector."""
        self._db.insert_audit_log(
            task_id=task_id,
            agent="orchestrator",
            action="fanout_join",
            payload={
                "width": width,
                "children_ids": children_ids,
                "context_markdown": context_markdown,
            },
        )

    def log_task_resumed_from_jobs(
        self,
        task_id: str,
        blocking_job_ids: list[str],
        trigger: str,
        triggering_job_id: str | None,
        job_outcomes: dict[str, str],
    ) -> None:
        """Written immediately after try_claim_for_step wins on an in_progress+blocked_on_job
        row. Read by the resume header injector. Spec §5.2, §7.
        """
        self._db.insert_audit_log(
            task_id=task_id,
            agent="orchestrator",
            action="task_resumed_from_jobs",
            payload={
                "blocking_job_ids": blocking_job_ids,
                "trigger": trigger,
                "triggering_job_id": triggering_job_id,
                "job_outcomes": job_outcomes,
            },
        )

    def log_task_resume_skipped(
        self,
        task_id: str,
        reason: str,
        blocked_on_job_ids_raw: str | None = None,
    ) -> None:
        """Diagnostic-only: written when the resume helper returns False with
        reason=empty_job_list (the only audited skip reason). Spec §7.
        """
        payload: dict[str, object] = {"reason": reason}
        if blocked_on_job_ids_raw is not None:
            payload["blocked_on_job_ids_raw"] = blocked_on_job_ids_raw
        self._db.insert_audit_log(
            task_id=task_id,
            agent="orchestrator",
            action="task_resume_skipped",
            payload=payload,
        )

    def log_revisit_of(
        self,
        task_id: str,
        predecessor_root: str,
        flagged: str,
        cascade: list[str],
        prior_status: str,
        founder_note: str | None,
        actor: str = "cli",
    ) -> None:
        """Record on the NEW root that it is a revisit of `predecessor_root`.

        `cascade` is [predecessor_root, ..., flagged] -- the chain the founder
        walked from the flagged task back up to the predecessor root. The
        prompt-injection step in run_step reads this entry to build the
        first-step context header.

        `actor` identifies the surface that triggered the revisit: "cli"
        (HTTP route / happyranch revisit command) or "feishu-reply" (Feishu listener).
        Defaults to "cli" for backward compatibility with existing callers.
        """
        self._db.insert_audit_log(
            task_id=task_id,
            agent="founder",
            action="revisit_of",
            payload={
                "predecessor_root": predecessor_root,
                "flagged": flagged,
                "cascade": cascade,
                "prior_status": prior_status,
                "founder_note": founder_note,
                "actor": actor,
            },
        )

    def log_revisit_spawned(
        self, predecessor_task_id: str, new_root: str,
    ) -> None:
        """Record on the predecessor that it spawned a revisit (observational)."""
        self._db.insert_audit_log(
            task_id=predecessor_task_id,
            agent="founder",
            action="revisit_spawned",
            payload={"new_root": new_root},
        )

    def log_escalation_superseded(
        self,
        predecessor_task_id: str,
        *,
        successor_root: str,
        prior_block_kind: str,
        actor: str,
        founder_note: str | None = None,
        thread_id: str | None = None,
    ) -> None:
        """Record that an escalated or in_progress(delegated) task was auto-resolved to
        SUPERSEDED because a human-authorized continuation
        (`successor_root`) superseded it.

        The `successor_root` citation IS the maker-checker evidence: this
        transition NEVER fires without a concrete successor task_id, which only
        exists because a human (founder `revisit` / founder-or-manager
        thread-dispatch) authorized the continuation. `actor` records which
        surface triggered it; `thread_id` (set on the thread-dispatch path)
        cites the dispatching thread ruling. THR-018 tier #3, §3a.
        """
        self._db.insert_audit_log(
            task_id=predecessor_task_id,
            agent="founder",
            action="escalation_superseded",
            payload={
                "successor_root": successor_root,
                "prior_block_kind": prior_block_kind,
                "actor": actor,
                "founder_note": founder_note,
                "thread_id": thread_id,
            },
        )

    def log_artifact_put(self, name: str, size_bytes: int, agent: str) -> None:
        self._db.insert_audit_log(
            task_id=f"artifact:{name}",  # namespaced to avoid collision with TASK-/JOB- ids in get_audit_logs(task_id)
            agent=agent,
            action="artifact_put",
            payload={"name": name, "size_bytes": size_bytes},
        )

    def log_artifact_delete(self, name: str, agent: str) -> None:
        # Mirrors log_artifact_put's row shape: same artifact:<name> namespacing
        # so deletes never collide with TASK-/JOB- ids in get_audit_logs(task_id).
        self._db.insert_audit_log(
            task_id=f"artifact:{name}",
            agent=agent,
            action="artifact_delete",
            payload={"name": name},
        )

    # ── Task attachment audit actions (THR-109) ──────────────────────────────

    def log_task_attachment_uploaded(
        self, storage_key: str, display_name: str,
        size_bytes: int, content_type: str | None, agent: str,
    ) -> None:
        """Record a private-store upload (pre-task-creation).

        Uses a namespaced task_id so rows don't collide with TASK-/JOB- ids
        in get_audit_logs(task_id). Payload carries only metadata — never
        attachment bytes or local file paths.
        """
        self._db.insert_audit_log(
            task_id=f"task-attachment:{storage_key}",
            agent=agent,
            action="task_attachment_uploaded",
            payload={
                "storage_key": storage_key,
                "display_name": display_name,
                "size_bytes": size_bytes,
                "content_type": content_type,
            },
        )

    def log_task_attachment_added(
        self, task_id: str, storage_key: str, display_name: str,
        content_type: str | None, uploaded_by: str,
    ) -> None:
        """Record that an attachment was linked to a task on creation.

        Uses the concrete task_id — the ordinary primary use of the column.
        Payload carries metadata only; never bytes or local paths.
        """
        self._db.insert_audit_log(
            task_id=task_id,
            agent=uploaded_by,
            action="task_attachment_added",
            payload={
                "storage_key": storage_key,
                "display_name": display_name,
                "content_type": content_type,
            },
        )

    def log_task_attachment_materialized(
        self, task_id: str, session_id: str,
        count: int, materialized_keys: list[str],
    ) -> None:
        """Record that attachments were materialized for a session spawn.

        Uses the spawning task's id. Payload carries the session id and
        storage_key list — never bytes or local file paths.
        """
        self._db.insert_audit_log(
            task_id=task_id,
            agent="orchestrator",
            action="task_attachment_materialized",
            payload={
                "session_id": session_id,
                "count": count,
                "storage_keys": materialized_keys,
            },
        )

    def log_agent_managed(
        self,
        *,
        scope_id: str,
        action: str,
        name: str,
        source: str,
        actor: str,
    ) -> None:
        """Record a successful manage-agent call.

        `scope_id` populates `audit_log.task_id` (the generic scope column
        described at line 173): TASK-xxx for task-path calls.
        `source` is 'task' for quick filtering.
        `actor` is the manager_name resolved by the team-manager auth helper.
        """
        self._db.insert_audit_log(
            task_id=scope_id,
            agent=actor,
            action="agent_managed",
            payload={
                "action": action,
                "name": name,
                "source": source,
            },
        )

    def log_executor_removed(
        self,
        *,
        profile_name: str,
        command_adapter_id: str,
        actor: str = "founder",
    ) -> None:
        """Record a successful runtime-level executor profile removal.

        The payload captures only the retired profile's registered custom
        adapter identity; legacy command and argv fields are not supported.

        Row shape:
          task_id = "executor:<profile_name>"
          action  = "executor_removed"
          payload = {command_adapter_id}
        """
        self._db.insert_audit_log(
            task_id=f"executor:{profile_name}",
            agent=actor,
            action="executor_removed",
            payload={"command_adapter_id": command_adapter_id},
        )

    def log_learning_added(
        self,
        *,
        agent: str,
        id: str,
        slug: str,
        topic: str,
        tags: list[str],
        source_task: str | None,
    ) -> None:
        self._db.insert_audit_log(
            task_id=source_task if source_task is not None else f"AGENT-{agent}",
            agent=agent,
            action="learning_added",
            payload={"id": id, "slug": slug, "topic": topic, "tags": tags, "source_task": source_task},
        )

    def log_learning_updated(
        self,
        *,
        agent: str,
        id: str,
        slug_changed: bool,
    ) -> None:
        self._db.insert_audit_log(
            task_id=f"AGENT-{agent}",
            agent=agent,
            action="learning_updated",
            payload={"id": id, "slug_changed": slug_changed},
        )

    def log_learning_promoted(
        self,
        *,
        agent: str,
        id: str,
        kb_slug: str,
    ) -> None:
        self._db.insert_audit_log(
            task_id=f"AGENT-{agent}",
            agent=agent,
            action="learning_promoted",
            payload={"id": id, "kb_slug": kb_slug},
        )

    # THR-032 Phase R — memory event names, emitted FORWARD ONLY. New writes use
    # these; the log_learning_* methods above remain so historical rows stay
    # truthful and any reader can still parse them (§7.2(a) audit immutability).
    # Additive event-name variants only — no column added/altered/dropped, and
    # audit_log.task_id scope-prefix overloading is untouched.
    def log_memory_added(
        self,
        *,
        agent: str,
        id: str,
        slug: str,
        topic: str,
        tags: list[str],
        source_task: str | None,
    ) -> None:
        self._db.insert_audit_log(
            task_id=source_task if source_task is not None else f"AGENT-{agent}",
            agent=agent,
            action="memory_added",
            payload={"id": id, "slug": slug, "topic": topic, "tags": tags, "source_task": source_task},
        )

    def log_memory_updated(
        self,
        *,
        agent: str,
        id: str,
        slug_changed: bool,
    ) -> None:
        self._db.insert_audit_log(
            task_id=f"AGENT-{agent}",
            agent=agent,
            action="memory_updated",
            payload={"id": id, "slug_changed": slug_changed},
        )

    def log_memory_promoted(
        self,
        *,
        agent: str,
        id: str,
        kb_slug: str,
    ) -> None:
        self._db.insert_audit_log(
            task_id=f"AGENT-{agent}",
            agent=agent,
            action="memory_promoted",
            payload={"id": id, "kb_slug": kb_slug},
        )

    def log_memory_digest_impression(
        self,
        *,
        agent: str,
        task_id: str,
        session_id: str,
        digest_ids: list[str],
        budget: int,
        memory_telemetry_version: int | None = None,
        pointer_ids: list[str] | None = None,
        full_body_ids: list[str] | None = None,
    ) -> None:
        """THR-091 Slice 2: log a digest impression at agent spawn.

        Emitted exactly once per non-empty digest injected into an agent
        prompt.  Carries the shown digest's memory IDs plus agent, current
        task ID, and generated session ID.  No digest text, titles,
        directive/full bodies, prompts, or briefs are stored.

        Row shape: ``task_id=<task_id>``, ``action="memory_digest_impression"``,
        ``payload`` includes ``agent``, ``session_id``, ``digest_ids``,
        ``digest_count``, ``budget``. New observed renders additionally carry
        exactly ``memory_telemetry_version=1``, ``pointer_ids``, ``full_body_ids``.
        Modes are disjoint/unique and their union equals digest IDs/count.
        Calls without metadata retain the exact legacy unversioned payload.
        Version records exposure only, never task eligibility or epoch authority.
        """
        payload = {
            "agent": agent,
            "session_id": session_id,
            "digest_ids": digest_ids,
            "digest_count": len(digest_ids),
            "budget": budget,
        }
        if any(value is not None for value in (
            memory_telemetry_version, pointer_ids, full_body_ids,
        )):
            from runtime.infrastructure.learnings_store import ID_RE

            # All-or-nothing metadata. Validate before the existing insert so
            # programmer errors cannot leave partial or upgraded legacy rows.
            if type(memory_telemetry_version) is not int or memory_telemetry_version != 1:
                raise ValueError("invalid memory exposure version")
            for ids in (digest_ids, pointer_ids, full_body_ids):
                if not isinstance(ids, list) or any(
                    not isinstance(mid, str) or ID_RE.fullmatch(mid) is None for mid in ids
                ):
                    raise ValueError("memory exposure IDs must be lists of memory identifiers")
                if len(ids) != len(set(ids)):
                    raise ValueError("duplicate memory exposure IDs")
            if set(pointer_ids) & set(full_body_ids):
                raise ValueError("overlapping memory exposure modes")
            if set(pointer_ids) | set(full_body_ids) != set(digest_ids):
                raise ValueError("memory exposure does not match digest IDs/count")
            payload.update(
                memory_telemetry_version=memory_telemetry_version,
                pointer_ids=pointer_ids,
                full_body_ids=full_body_ids,
            )
        self._db.insert_audit_log(
            task_id=task_id,
            agent=agent,
            action="memory_digest_impression",
            payload=payload,
        )

    def log_memory_search(
        self,
        *,
        agent: str,
        session_id: str | None,
        memory_ids: list[str],
        hit_count: int,
        kb_hit_count: int,
        task_id: str | None = None,
    ) -> None:
        """THR-091 Slice 2: log a privacy-preserving search result telemetry event.

        Stores only returned memory IDs (and minimal counts/correlation/source
        metadata).  NEVER persists raw query text, query tokens/hashes, snippets,
        titles, bodies, KB body content, or prompt text.  KB hits are excluded
        from ``memory_ids``; their count is recorded as ``kb_hit_count``.

        When ``task_id`` is provided (validated server-side via SessionTracker),
        the row's ``task_id`` column is the actual task ID for trusted
        correlation.  Otherwise ``task_id="AGENT-{agent}"`` (legacy).

        Row shape: ``task_id=<task_id or AGENT-{agent}>``, ``action="memory_search"``,
        ``payload`` includes ``agent``, ``session_id`` (when available),
        ``memory_ids``, ``hit_count``, ``kb_hit_count``, and ``task_id``
        (when available).
        """
        payload: dict = {
            "agent": agent,
            "memory_ids": memory_ids,
            "hit_count": hit_count,
            "kb_hit_count": kb_hit_count,
        }
        if session_id is not None:
            payload["session_id"] = session_id
        if task_id is not None:
            payload["task_id"] = task_id
        row_task_id = task_id if task_id is not None else f"AGENT-{agent}"
        self._db.insert_audit_log(
            task_id=row_task_id,
            agent=agent,
            action="memory_search",
            payload=payload,
        )

    def log_memory_read(
        self,
        *,
        agent: str,
        id: str,
        slug: str,
        session_id: str | None = None,
        source: str | None = None,
        task_id: str | None = None,
    ) -> None:
        """Log a memory read with optional same-session attribution.

        THR-091 Slice 2: adds optional ``session_id``, ``source``, and
        ``task_id`` metadata.  ``source`` is one of ``digest``, ``search``,
        or ``explicit_or_other``.  When ``source`` is None and ``session_id``
        is provided, auto-resolve attribution via
        ``_resolve_read_source`` which now also validates ``task_id`` when
        known (server-side SessionTracker-confirmed).

        Legacy rows without these fields remain compatible.
        task_id column stays ``AGENT-{agent}`` (legacy scope convention).
        When a validated ``task_id`` is supplied it is stored in payload.

        Row shape: ``task_id="AGENT-{agent}"``, ``action="memory_read"``,
        ``payload`` includes ``id``, ``slug``, and (when available)
        ``source``, ``session_id``, ``task_id``.
        """
        resolved_source = source
        if resolved_source is None and session_id is not None:
            resolved_source = self._resolve_read_source(
                agent=agent, id=id, session_id=session_id, task_id=task_id,
            )
        payload: dict = {"id": id, "slug": slug}
        if resolved_source is not None:
            payload["source"] = resolved_source
        if session_id is not None:
            payload["session_id"] = session_id
        if task_id is not None:
            payload["task_id"] = task_id
        self._db.insert_audit_log(
            task_id=f"AGENT-{agent}",
            agent=agent,
            action="memory_read",
            payload=payload,
        )

    def _resolve_read_source(
        self,
        *,
        agent: str,
        id: str,
        session_id: str,
        task_id: str | None = None,
    ) -> str:
        """Resolve the source of a memory read for same-session attribution.

        When ``task_id`` is provided (server-side SessionTracker-validated),
        only matches events that share the same task_id — never cross-credits
        a different task's digest or search, even for the same agent+session.

        Returns ``digest`` when the id is in the session+task's digest impression;
        ``search`` when in the session+task's search result ids; otherwise
        ``explicit_or_other``.
        """
        import json
        # Check digest impression for this session (and task when known).
        # Digest impressions already store the actual task_id in the task_id
        # column, so we filter by it directly in SQL.
        if task_id is not None:
            rows = self._db.fetch_all_readonly(
                "SELECT payload FROM audit_log"
                " WHERE agent = ? AND action = 'memory_digest_impression'"
                " AND task_id = ?",
                (agent, task_id),
            )
        else:
            rows = self._db.fetch_all_readonly(
                "SELECT payload FROM audit_log"
                " WHERE agent = ? AND action = 'memory_digest_impression'",
                (agent,),
            )
        for row in rows:
            try:
                payload = json.loads(row["payload"])
            except (json.JSONDecodeError, TypeError):
                continue
            if payload.get("session_id") == session_id:
                digest_ids = payload.get("digest_ids", [])
                if id in digest_ids:
                    return "digest"
        # Check search events for this session (and task when known).
        # Search events with validated task_id store it in the task_id column;
        # unvalidated ones use "AGENT-{agent}".  Filter by task_id when known.
        if task_id is not None:
            rows = self._db.fetch_all_readonly(
                "SELECT payload FROM audit_log"
                " WHERE agent = ? AND action = 'memory_search'"
                " AND task_id = ?",
                (agent, task_id),
            )
        else:
            rows = self._db.fetch_all_readonly(
                "SELECT payload FROM audit_log"
                " WHERE agent = ? AND action = 'memory_search'",
                (agent,),
            )
        for row in rows:
            try:
                payload = json.loads(row["payload"])
            except (json.JSONDecodeError, TypeError):
                continue
            if payload.get("session_id") == session_id:
                memory_ids = payload.get("memory_ids", [])
                if id in memory_ids:
                    return "search"
        return "explicit_or_other"

    def log_memory_lifecycle_changed(
        self,
        *,
        agent: str,
        id: str,
        from_lifecycle: str,
        to_lifecycle: str,
        reason: str,
        source: str = "manual",
    ) -> None:
        """THR-032 P3a: audit a lifecycle transition.

        Row shape: ``task_id="AGENT-{agent}"``, ``action="memory_lifecycle_changed"``,
        ``payload`` includes id, from_lifecycle, to_lifecycle, reason, source.
        No column added; no historical row rewritten.
        """
        self._db.insert_audit_log(
            task_id=f"AGENT-{agent}",
            agent=agent,
            action="memory_lifecycle_changed",
            payload={
                "id": id,
                "from_lifecycle": from_lifecycle,
                "to_lifecycle": to_lifecycle,
                "reason": reason,
                "source": source,
            },
        )

    # THR-091 Slice 2: telemetry primitives — digest impression, memory_read
    # attribution, search telemetry, and the operator-facing telemetry report
    # (replacing the earlier WS-C pull-through stub).

    @staticmethod
    def _extract_digest_ids(digest_text: str) -> list[str]:
        """Extract MEM-NNN ids from a digest string.

        Matches markers like ``- `MEM-139` — ...`` or ``**Directive:** ``MEM-001`` ...``
        """
        import re
        ids = re.findall(r'MEM-\d{3,}', digest_text)
        # Preserve order, deduplicate
        seen: set[str] = set()
        result: list[str] = []
        for mid in ids:
            if mid not in seen:
                seen.add(mid)
                result.append(mid)
        return result

    def compute_memory_pull_through(
        self,
        *,
        agent: str,
        digest_ids: set[str],
    ) -> dict:
        """Compute pull-through: of digest pointers, how many were read.

        Returns a dict with:
        - digest_count: total pointers in the digest
        - read_count: how many were read at least once
        - pull_through: fraction read (0.0–1.0)
        - read_ids: sorted list of ids that were read
        - unread_ids: sorted list of ids in digest but never read

        THR-091 WS-C: retained for backward-compatible per-agent analysis.
        """
        if not digest_ids:
            return {
                "digest_count": 0,
                "read_count": 0,
                "pull_through": 0.0,
                "read_ids": [],
                "unread_ids": [],
            }
        # Query memory_read events for this agent and extract payload.id
        rows = self._db.fetch_all_readonly(
            "SELECT payload FROM audit_log WHERE agent = ? AND action = 'memory_read'",
            (agent,),
        )
        import json
        read_set: set[str] = set()
        for row in rows:
            try:
                payload = json.loads(row["payload"])
            except (json.JSONDecodeError, TypeError):
                continue
            mid = payload.get("id")
            if mid and mid in digest_ids:
                read_set.add(mid)
        digest_count = len(digest_ids)
        read_count = len(read_set)
        pull_through = read_count / digest_count if digest_count > 0 else 0.0
        return {
            "digest_count": digest_count,
            "read_count": read_count,
            "pull_through": pull_through,
            "read_ids": sorted(read_set),
            "unread_ids": sorted(digest_ids - read_set),
        }

    def compute_memory_telemetry_report(
        self, *, agent_role_map: dict[str, str] | None = None,
        current_time: "datetime | None" = None,
    ) -> dict:
        """Acquire four streams in one synchronized SELECT, then reduce purely.

        Roles are descriptive. No report input can supply G1/G3 authority.
        A failed SELECT is an unavailable acquisition, never partial metrics.
        """
        from datetime import datetime, timezone
        from runtime.infrastructure.memory_telemetry_report import (
            ACTIONS, ReportAcquisitionUnavailable, reduce_report,
        )
        cutoff = current_time if current_time is not None else datetime.now(timezone.utc)
        try:
            rows = [dict(row) for row in self._db.fetch_all_readonly(
                "SELECT id, timestamp, agent, task_id, action, payload FROM audit_log"
                " WHERE action IN (?, ?, ?, ?) ORDER BY id", ACTIONS,
            )]
        except Exception as exc:
            raise ReportAcquisitionUnavailable() from exc
        streams = {action: [row for row in rows if row["action"] == action] for action in ACTIONS}
        return reduce_report(
            streams["memory_digest_impression"], streams["memory_read"], streams["memory_search"],
            agent_role_map, cutoff, session_start_rows=streams["session_start"],
        )

    def log_thread_started(
        self,
        thread_id: str,
        *,
        subject: str,
        initial_recipients: list[str],
        forwarded_from_id: str | None,
        composed_by: str = "founder",
        composed_from_task_id: str | None = None,
        composed_from_dream_id: str | None = None,
    ) -> None:
        payload: dict[str, object] = {
            "subject": subject,
            "initial_recipients": initial_recipients,
            "forwarded_from_id": forwarded_from_id,
            "composed_by": composed_by,
            "composed_from_task_id": composed_from_task_id,
            "composed_from_dream_id": composed_from_dream_id,
        }
        self._db.insert_audit_log(
            task_id=thread_id,
            agent=composed_by,
            action="thread_started",
            payload=payload,
        )

    def log_thread_message_sent(
        self,
        thread_id: str,
        *,
        seq: int,
        speaker: str,
        kind: str,
        attachment_names: list[str] | None = None,
    ) -> None:
        payload: dict[str, object] = {"seq": seq, "kind": kind}
        if attachment_names:
            payload["attachment_count"] = len(attachment_names)
            payload["attachment_names"] = attachment_names
        self._db.insert_audit_log(
            task_id=thread_id,
            agent=speaker,
            action="thread_message_sent",
            payload=payload,
        )

    def log_thread_decline_consumed(
        self,
        thread_id: str,
        *,
        agent_name: str,
        reason: str | None = None,
    ) -> None:
        payload: dict[str, object] = {"agent_name": agent_name}
        if reason:
            payload["reason"] = reason
        self._db.insert_audit_log(
            task_id=thread_id,
            agent=agent_name,
            action="thread_decline_consumed",
            payload=payload,
        )

    def log_thread_participant_added(
        self,
        thread_id: str,
        *,
        agent_name: str,
        added_by: str,
    ) -> None:
        self._db.insert_audit_log(
            task_id=thread_id,
            agent=added_by,
            action="thread_participant_added",
            payload={"agent_name": agent_name, "added_by": added_by},
        )

    def log_thread_participant_removed(
        self,
        thread_id: str,
        *,
        agent_name: str,
        removed_by: str,
    ) -> None:
        self._db.insert_audit_log(
            task_id=thread_id,
            agent=removed_by,
            action="thread_participant_removed",
            payload={"agent_name": agent_name, "removed_by": removed_by},
        )

    def log_thread_dispatch(
        self,
        thread_id: str,
        *,
        task_id: str,
        dispatcher: str,
        target_agent: str,
        team: str,
    ) -> None:
        self._db.insert_audit_log(
            task_id=thread_id,
            agent=dispatcher,
            action="thread_dispatch",
            payload={
                "task_id": task_id,
                "dispatcher": dispatcher,
                "target_agent": target_agent,
                "team": team,
            },
        )

    def log_agent_session_reused(
        self,
        thread_id: str,
        *,
        agent_name: str,
        executor: str,
        agent_session_id: str,
        triggering_seq: int,
    ) -> None:
        """Informational: a thread turn successfully resumed an agent session."""
        self._db.insert_audit_log(
            task_id=thread_id,
            agent=agent_name,
            action="agent_session_reused",
            payload={
                "executor": executor,
                "agent_session_id": agent_session_id,
                "triggering_seq": triggering_seq,
            },
        )

    def log_agent_session_evicted_fallback(
        self,
        thread_id: str,
        *,
        agent_name: str,
        executor: str,
        stale_session_id: str,
        error: str,
    ) -> None:
        """Fires when a resume reported session-not-found and we rebuilt a fresh
        full-context session. Watch frequency: high rates mean the agent CLI's
        local session TTL is shorter than our typical inter-turn gap.

        THR-200: this is now the single transactional seam — the audit row and
        the durable ``agent_session_id = NULL`` invalidation commit together
        BEFORE the fallback launch, so a failed fallback can never leave the
        stale provider session id in place for the next wake.
        """
        self._db.invalidate_thread_session_evicted(
            thread_id,
            agent_name,
            stale_session_id=stale_session_id,
            error=error,
            executor=executor,
        )

    def log_thread_task_followup_enqueued(
        self,
        thread_id: str,
        *,
        original_task_id: str,
        terminal_task_id: str,
        dispatcher: str,
        invocation_token: str,
    ) -> None:
        self._db.insert_audit_log(
            task_id=terminal_task_id,
            agent=dispatcher,
            action="thread_task_followup_enqueued",
            payload={
                "thread_id": thread_id,
                "original_task_id": original_task_id,
                "dispatcher": dispatcher,
                "invocation_token_prefix": invocation_token[:8],
            },
        )

    def log_thread_followup_skipped(
        self,
        thread_id: str,
        *,
        original_task_id: str,
        terminal_task_id: str,
        reason: str,
        **extra,
    ) -> None:
        self._db.insert_audit_log(
            task_id=terminal_task_id,
            agent="orchestrator",
            action="thread_followup_skipped",
            payload={
                "thread_id": thread_id,
                "original_task_id": original_task_id,
                "reason": reason,
                **extra,
            },
        )

    def log_thread_turn_cap_auto_extended(
        self,
        thread_id: str,
        *,
        original_task_id: str,
        reason: str,
        new_cap: int,
    ) -> None:
        self._db.insert_audit_log(
            task_id=original_task_id,
            agent="orchestrator",
            action="thread_turn_cap_auto_extended",
            payload={
                "thread_id": thread_id,
                "reason": reason,
                "new_cap": new_cap,
            },
        )

    def log_thread_archived(
        self,
        thread_id: str,
        *,
        turns_used: int,
    ) -> None:
        self._db.insert_audit_log(
            task_id=thread_id,
            agent="founder",
            action="thread_archived",
            payload={"turns_used": turns_used},
        )

    def log_thread_resumed(
        self, thread_id: str, *, prior_archived_at: str | None,
    ) -> None:
        self._db.insert_audit_log(
            task_id=thread_id,
            agent="founder",
            action="thread_resumed",
            payload={"prior_archived_at": prior_archived_at},
        )

    def log_thread_invocation_failed(
        self,
        thread_id: str,
        *,
        agent: str,
        token: str,
        purpose: str,
        reason: str,
        kind: str = "thread_invocation_failed",
        stdout_tail: str = "",
        stderr_tail: str = "",
    ) -> None:
        tail_cap = 2000
        self._db.insert_audit_log(
            task_id=thread_id,
            agent=agent,
            action=kind,
            payload={
                "invocation_token": token[:8] + "…",
                "purpose": purpose,
                "reason": reason,
                "stdout_tail": str(stdout_tail or "")[-tail_cap:],
                "stderr_tail": str(stderr_tail or "")[-tail_cap:],
            },
        )

    def log_agent_backfilled(
        self,
        *,
        name: str,
        repos_count: int,
        executor: str,
    ) -> None:
        """Record a founder-initiated enrollment backfill.

        Unlike `log_agent_managed`, the actor is 'founder' — this is a one-off
        recovery op for agents bootstrapped outside the enroll→approve flow.
        Scope is the agent name itself (no task context).
        """
        self._db.insert_audit_log(
            task_id=f"AGENT-{name}",
            agent="founder",
            action="agent_backfilled",
            payload={
                "name": name,
                "repos_count": repos_count,
                "executor": executor,
            },
        )

    def log_job_submitted(
        self,
        *,
        task_id: str,
        job_id: str,
        agent: str,
        title: str,
        interpreter: str,
        cwd_hint: str | None,
        byte_size: int,
        line_count: int,
    ) -> None:
        self._db.insert_audit_log(
            task_id=task_id,
            agent=agent,
            action="job_submitted",
            payload={
                "script_request_id": job_id,
                "title": title,
                "interpreter": interpreter,
                "cwd_hint": cwd_hint,
                "byte_size": byte_size,
                "line_count": line_count,
            },
        )

    def log_job_rejected(
        self, *, task_id: str, job_id: str, reviewer: str, reason: str
    ) -> None:
        self._db.insert_audit_log(
            task_id=task_id,
            agent=reviewer,
            action="job_rejected",
            payload={
                "script_request_id": job_id,
                "reviewer": reviewer,
                "reason": reason,
            },
        )

    def log_job_run_started(
        self,
        *,
        task_id: str,
        job_id: str,
        reviewer: str,
        cwd_resolved: str,
        timeout_seconds: int,
        interpreter: str,
    ) -> None:
        self._db.insert_audit_log(
            task_id=task_id,
            agent=reviewer,
            action="job_run_started",
            payload={
                "script_request_id": job_id,
                "reviewer": reviewer,
                "cwd_resolved": cwd_resolved,
                "timeout_seconds": timeout_seconds,
                "interpreter": interpreter,
            },
        )

    def log_job_auto_started(
        self,
        *,
        task_id: str,
        job_id: str,
        agent: str,
        cwd_resolved: str,
        timeout_seconds: int | None,
        interpreter: str,
        persistent: bool,
    ) -> None:
        """Agent-triggered auto-run path (review_required=False).

        Distinct action kind from ``job_run_started`` (founder-triggered) so
        audit log readers can tell apart the two run-initiation paths. The
        ``agent`` here is the requesting worker, not a founder reviewer.
        """
        self._db.insert_audit_log(
            task_id=task_id,
            agent=agent,
            action="job_auto_started",
            payload={
                "script_request_id": job_id,
                "agent": agent,
                "cwd_resolved": cwd_resolved,
                "timeout_seconds": timeout_seconds,
                "interpreter": interpreter,
                "persistent": persistent,
            },
        )

    def log_job_run_completed(
        self,
        *,
        task_id: str,
        job_id: str,
        actor: str,
        exit_code: int,
        duration_ms: int,
        stdout_bytes: int,
        stderr_bytes: int,
        truncated_stdout: bool,
        truncated_stderr: bool,
    ) -> None:
        self._db.insert_audit_log(
            task_id=task_id,
            agent=actor,
            action="job_run_completed",
            payload={
                "script_request_id": job_id,
                "exit_code": exit_code,
                "duration_ms": duration_ms,
                "stdout_bytes": stdout_bytes,
                "stderr_bytes": stderr_bytes,
                "truncated_stdout": truncated_stdout,
                "truncated_stderr": truncated_stderr,
            },
        )

    def log_job_run_failed(
        self,
        *,
        task_id: str,
        job_id: str,
        actor: str,
        reason: str,
        exit_code: int | None = None,
        duration_ms: int | None = None,
    ) -> None:
        self._db.insert_audit_log(
            task_id=task_id,
            agent=actor,
            action="job_run_failed",
            payload={
                "script_request_id": job_id,
                "exit_code": exit_code,
                "duration_ms": duration_ms,
                "reason": reason,
            },
        )

    def log_job_stopped(
        self, *, job_id: str, task_id: str, stopped_by: str,
    ) -> None:
        """Caller-triggered stop of a running job.

        ``stopped_by`` is ``"founder"`` (bearer-auth /stop) or ``"agent"``
        (session-bound /stop). The actual terminal transition still flows
        through the runner's normal exit path (``job_run_failed`` with
        ``reason="founder_stop"`` / ``"agent_stop"`` via
        ``_KILL_REASON_OVERRIDE``); this audit row records who pressed the
        button, separately from the runner's own bookkeeping.
        """
        self._db.insert_audit_log(
            task_id=task_id,
            agent=stopped_by,
            action="job_stopped",
            payload={
                "script_request_id": job_id,
                "stopped_by": stopped_by,
            },
        )

    # --- Dream audit events ---

    def log_dream_scheduled(self, dream_id: str, agent: str, *, local_date: str) -> None:
        self._db.insert_audit_log(
            task_id=dream_id, agent=agent,
            action="dream_scheduled",
            payload={"local_date": local_date},
        )

    def log_dream_started(
        self,
        dream_id: str,
        agent: str,
        *,
        executor: str | None = None,
        model: str | None = None,
    ) -> None:
        self._db.insert_audit_log(
            task_id=dream_id, agent=agent,
            action="dream_started",
            payload={"executor": executor, "model": model},
        )

    def log_dream_completed(
        self,
        dream_id: str,
        agent: str,
        *,
        new_learnings_count: int,
        kb_candidate_count: int,
        founder_thread_id: str | None,
    ) -> None:
        self._db.insert_audit_log(
            task_id=dream_id, agent=agent,
            action="dream_completed",
            payload={
                "new_learnings_count": new_learnings_count,
                "kb_candidate_count": kb_candidate_count,
                "founder_thread_id": founder_thread_id,
            },
        )

    def log_dream_failed(self, dream_id: str, agent: str, *, reason: str) -> None:
        self._db.insert_audit_log(
            task_id=dream_id, agent=agent,
            action="dream_failed",
            payload={"reason": reason},
        )

    def log_dream_timeout(self, dream_id: str, agent: str, *, reason: str) -> None:
        """Executor timeout for a dream. Distinct from log_dream_failed so the
        timeout failure mode is queryable separately (spec "Audit And Token
        Usage": dream_timeout). Does not advance the successful-dream window."""
        self._db.insert_audit_log(
            task_id=dream_id, agent=agent,
            action="dream_timeout",
            payload={"reason": reason},
        )

    def log_dream_founder_thread_created(
        self, dream_id: str, agent: str, *, founder_thread_id: str,
    ) -> None:
        """A dream completion created a founder-only thread (spec "Audit And
        Token Usage": dream_founder_thread_created). Scoped to the dream id;
        the thread itself separately emits thread_started/thread_message_sent."""
        self._db.insert_audit_log(
            task_id=dream_id, agent=agent,
            action="dream_founder_thread_created",
            payload={"founder_thread_id": founder_thread_id},
        )

    # --- Working Hours ---
    #
    # As with dreams, ``audit_log.task_id`` stores ``WORKHOUR-NNN`` for these
    # rows — the established generic-scope-id overload, NOT a new overload. The
    # spawned root tasks emit their own ordinary ``task_*`` rows; the two
    # streams correlate via the id list on ``work_hour_spawned``.

    def log_work_hour_scheduled(
        self, work_hour_id: str, agent: str, *, local_date: str, slot: str, mode: str,
        dropped: int = 0,
    ) -> None:
        # ``dropped`` records routines discarded past MAX_ROUTINES_PER_WAKE so
        # the cap leaves an audit trail (no silent truncation).
        self._db.insert_audit_log(
            task_id=work_hour_id, agent=agent,
            action="work_hour_scheduled",
            payload={"local_date": local_date, "slot": slot, "mode": mode, "dropped": dropped},
        )

    def log_work_hour_started(self, work_hour_id: str, agent: str) -> None:
        self._db.insert_audit_log(
            task_id=work_hour_id, agent=agent,
            action="work_hour_started",
            payload={},
        )

    def log_work_hour_spawned(
        self, work_hour_id: str, agent: str, *, task_ids: list[str],
    ) -> None:
        """A wake self-dispatched its routine root tasks. Payload carries the
        spawned root task_id list (the forward correlation to the task surface;
        the reverse linkage is ``work_hours.spawned_task_ids``)."""
        self._db.insert_audit_log(
            task_id=work_hour_id, agent=agent,
            action="work_hour_spawned",
            payload={"task_ids": list(task_ids), "spawned_task_count": len(task_ids)},
        )

    def log_work_hour_completed(
        self, work_hour_id: str, agent: str, *, spawned_task_count: int, routine_count: int,
    ) -> None:
        self._db.insert_audit_log(
            task_id=work_hour_id, agent=agent,
            action="work_hour_completed",
            payload={
                "spawned_task_count": spawned_task_count,
                "routine_count": routine_count,
            },
        )

    def log_work_hour_failed(self, work_hour_id: str, agent: str, *, reason: str) -> None:
        self._db.insert_audit_log(
            task_id=work_hour_id, agent=agent,
            action="work_hour_failed",
            payload={"reason": reason},
        )

    def log_work_hour_timeout(self, work_hour_id: str, agent: str, *, reason: str) -> None:
        """Executor timeout for a wake. Distinct from work_hour_failed so the
        timeout failure mode is queryable separately (spec "Audit And Token
        Usage": work_hour_timeout). No tasks are spawned on timeout."""
        self._db.insert_audit_log(
            task_id=work_hour_id, agent=agent,
            action="work_hour_timeout",
            payload={"reason": reason},
        )

    # --- Org config writes (Settings GUI) ---
    #
    # THR-035 / TASK-967. Like artifacts/threads/dreams, ``audit_log.task_id``
    # carries a generic *scope id* here — the namespaced ``config:<section>``
    # value (e.g. ``config:working_hours``). This reuses the established
    # generic-scope-id convention; it does NOT co-opt a real TASK-/JOB- id and
    # adds no column. The before→after snapshot + touched tiers make a
    # config-write fully reconstructable from the audit trail. The scope-prefix
    # convention is a load-bearing invariant — do NOT reinterpret (see the same
    # note over ``_THREAD_SCOPE_PREFIX`` in runtime/daemon/routes/audit.py).

    def log_org_config_write(
        self,
        *,
        section: str,
        tiers: list[str],
        before: dict,
        after: dict,
        actor: str = "founder",
    ) -> None:
        self._db.insert_audit_log(
            task_id=f"config:{section}",  # namespaced to avoid collision with TASK-/TALK-/SR-/JOB- ids in get_audit_logs(task_id)
            agent=actor,
            action="org_config_write",
            payload={
                "section": section,
                "tiers": tiers,
                "before": before,
                "after": after,
            },
        )

    # --- Skills config writes (THR-055) ---
    #
    # Follows the same config:<section> scope-prefix convention as
    # log_org_config_write (THR-035 / TASK-967). Uses ``config:skills``
    # as the namespaced task_id for registry and eligibility policy
    # mutation audit rows — no schema change, no task_id overload.

    def log_skills_config_write(
        self,
        *,
        subsection: str | None = None,
        tiers: list[str],
        before: dict,
        after: dict,
        actor: str = "founder",
    ) -> None:
        scope_id = "config:skills"
        if subsection:
            scope_id = f"config:skills:{subsection}"
        self._db.insert_audit_log(
            task_id=scope_id,
            agent=actor,
            action="skills_config_write",
            payload={
                "subsection": subsection,
                "tiers": tiers,
                "before": before,
                "after": after,
            },
        )
