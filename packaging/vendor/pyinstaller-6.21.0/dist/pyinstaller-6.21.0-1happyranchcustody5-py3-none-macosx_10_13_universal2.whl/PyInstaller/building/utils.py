#-----------------------------------------------------------------------------
# Copyright (c) 2005-2023, PyInstaller Development Team.
#
# Distributed under the terms of the GNU General Public License (version 2
# or later) with exception for distributing the bootloader.
#
# The full license is in the file COPYING.txt, distributed with this software.
#
# SPDX-License-Identifier: (GPL-2.0-or-later WITH Bootloader-exception)
#-----------------------------------------------------------------------------

import fnmatch
import glob
import hashlib
import io
import marshal
import os
import pathlib
import platform
import shutil
import struct
import subprocess
import sys
import types
import zipfile

from PyInstaller import compat
from PyInstaller import log as logging
from PyInstaller.compat import is_aix, is_darwin, is_win, is_linux, is_termux
from PyInstaller.exceptions import InvalidSrcDestTupleError
from PyInstaller.utils import misc

if is_win:
    from PyInstaller.utils.win32 import versioninfo

if is_darwin:
    import PyInstaller.utils.osx as osxutils

logger = logging.getLogger(__name__)

# -- Helpers for checking guts.
#
# NOTE: by _GUTS it is meant intermediate files and data structures that PyInstaller creates for bundling files and
# creating final executable.


def _check_guts_eq(attr_name, old_value, new_value, last_build):
    """
    Rebuild is required if values differ.
    """
    if old_value != new_value:
        logger.info("Building because %s changed", attr_name)
        return True
    return False


def _check_guts_toc_mtime(attr_name, old_toc, new_toc, last_build):
    """
    Rebuild is required if mtimes of files listed in old TOC are newer than last_build.

    Use this for calculated/analysed values read from cache.
    """
    for dest_name, src_name, typecode in old_toc:
        if misc.mtime(src_name) > last_build:
            logger.info("Building because %s changed", src_name)
            return True
    return False


def _check_guts_toc(attr_name, old_toc, new_toc, last_build):
    """
    Rebuild is required if either TOC content changed or mtimes of files listed in old TOC are newer than last_build.

    Use this for input parameters.
    """
    return _check_guts_eq(attr_name, old_toc, new_toc, last_build) or \
        _check_guts_toc_mtime(attr_name, old_toc, new_toc, last_build)


def destination_name_for_extension(module_name, src_name, typecode):
    """
    Take a TOC entry (dest_name, src_name, typecode) and determine the full destination name for the extension.
    """

    assert typecode == 'EXTENSION'

    # The `module_name` should be the extension's importable module name, such as `psutil._psutil_linux` or
    # `numpy._core._multiarray_umath`. Reconstruct the directory structure from parent package name(s), if any.
    dest_elements = module_name.split('.')

    # We have the base name of the extension file (the last element in the module name), but we do not know the
    # full extension suffix. We can take that from source name; for simplicity, replace the whole base name part.
    src_path = pathlib.Path(src_name)
    dest_elements[-1] = src_path.name

    # Extensions that originate from python's python3.x/lib-dynload directory should be diverted into
    # python3.x/lib-dynload destination directory instead of being collected into top-level application directory.
    # See #5604 for original motivation (using just lib-dynload), and #9204 for extension (using python3.x/lib-dynload).
    if src_path.parent.name == 'lib-dynload':
        python_dir = f'python{sys.version_info.major}.{sys.version_info.minor}'
        if src_path.parent.parent.name == python_dir:
            dest_elements = [python_dir, 'lib-dynload', *dest_elements]

    return os.path.join(*dest_elements)


# HappyRanch custody revision 2, changed 2026-10-16.
# Opt-in observations of existing operations; original notices remain above.
import contextlib as _hr_contextlib
import json as _hr_json
import stat as _hr_stat
import unicodedata as _hr_unicode

_HR_RUNS = {}
_HR_KEYS = {'run_id', 'stage_dir', 'source_roots', 'lane', 'target', 'ordinal', 'ledger_ref'}


def _hr_need(ok, code):
    if not ok:
        raise ValueError('FREEZER_' + code)


def _hr_identity(s):
    return [s.st_dev, s.st_ino, s.st_mode, s.st_uid, s.st_nlink, s.st_size, s.st_mtime_ns, s.st_ctime_ns]


def _hr_encode(value):
    return (_hr_json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False) + '\n').encode()



def _hr_parse(raw, *, _collect_ledger=False):
    cap = (32 if _collect_ledger else 8) * 1024**2
    _hr_need(len(raw) <= cap, 'JSON_CAP')
    depth, quoted, escape, scalar, lexical = 0, False, False, False, 0
    for char in raw.decode('utf-8', 'strict'):
        if quoted:
            if escape:
                escape = False
            elif char == chr(92):
                escape = True
            elif char == '"':
                quoted = False
        elif char == '"':
            quoted = True
            scalar = False
            lexical += 1
        elif char in '[{':
            scalar = False
            lexical += 1
            depth += 1
            _hr_need(depth <= 16, 'JSON_DEPTH')
        elif char in ']}':
            scalar = False
            depth -= 1
        elif char in ' \t\r\n,:':
            scalar = False
        elif not scalar:
            scalar = True
            lexical += 1
        if _collect_ledger:
            _hr_need(lexical <= 1000000, 'JSON_LEXICAL_NODE_CAP')
    def pairs(items):
        value = {}
        for key, child in items:
            _hr_need(key not in value, 'JSON_DUPLICATE_KEY')
            value[key] = child
        return value
    value = _hr_json.loads(raw, object_pairs_hook=pairs)
    nodes = 0
    def check(item):
        nonlocal nodes
        nodes += 1
        _hr_need(nodes <= 1000000, 'JSON_NODE_CAP')
        if isinstance(item, dict):
            for key, child in item.items():
                check(key)
                check(child)
        elif isinstance(item, list):
            for child in item:
                check(child)
        elif isinstance(item, str):
            _hr_need(len(item.encode()) <= 4096, 'JSON_STRING_CAP')
        else:
            _hr_need(item is None or type(item) in (bool, int), 'JSON_SCALAR')
    check(value)
    return value



def _hr_option_identity(option):
    result = dict(option)
    entitlement = result.get('entitlements')
    if entitlement is not None:
        result['entitlements'] = {k: v for k, v in entitlement.items() if k != 'snapshot'}
    return result


def _hr_name(name):
    _hr_need(isinstance(name, str) and name and len(name.encode()) <= 1024 and '\\' not in name
             and not any(ord(c) < 32 or ord(c) == 127 for c in name), 'NAME_INVALID')
    parts = name.split('/')
    _hr_need(len(parts) <= 24 and all(p not in ('', '.', '..') and len(p.encode()) <= 255 for p in parts), 'NAME_INVALID')
    return name


@_hr_contextlib.contextmanager
def _hr_fd(path, directory=False):
    """Pin every absolute ancestor; never follow an unrecorded link."""
    path = pathlib.Path(path)
    _hr_need(path.is_absolute() and '..' not in path.parts, 'ABSOLUTE_PATH_REQUIRED')
    fds = []
    chain = []
    try:
        fd = os.open('/', os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
        fds.append(fd)
        for index, part in enumerate(path.parts[1:]):
            last = index == len(path.parts) - 2
            flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC
            if not last or directory:
                flags |= os.O_DIRECTORY
            child = os.open(part, flags, dir_fd=fd)
            fds.append(child)
            info = os.fstat(child)
            _hr_need(info.st_uid in (0, os.getuid()) and not info.st_mode & 0o022, 'SUBJECT_OWNER_MODE')
            if not last or directory:
                _hr_need(_hr_stat.S_ISDIR(info.st_mode), 'DIRECTORY_REQUIRED')
                identity = [info.st_dev, info.st_ino, info.st_mode, info.st_uid]
            else:
                _hr_need(_hr_stat.S_ISREG(info.st_mode) and info.st_nlink == 1, 'REGULAR_SINGLE_LINK_REQUIRED')
                identity = _hr_identity(info)
            chain.append((fd, part, child, identity, not last or directory))
            fd = child
        yield fd
        for parent, part, child, old, isdir in chain:
            for now in (os.fstat(child), os.stat(part, dir_fd=parent, follow_symlinks=False)):
                actual = [now.st_dev, now.st_ino, now.st_mode, now.st_uid] if isdir else _hr_identity(now)
                _hr_need(old == actual, 'SUBJECT_UNSTABLE')
    finally:
        for fd in reversed(fds):
            os.close(fd)


class _HRCustody:
    """Closed data interface. No executable callbacks or inferred cache paths."""
    def __init__(self, value):
        _hr_need(type(value) is dict and set(value) == _HR_KEYS, 'CUSTODY_SCHEMA')
        _hr_need(value['lane'] in ('daemon', 'cli', 'shared') and value['target'] in ('PYZ', 'EXE', 'COLLECT'), 'CUSTODY_TARGET')
        _hr_need(type(value['ordinal']) is int and value['ordinal'] >= 0, 'CUSTODY_ORDINAL')
        _hr_need(isinstance(value['run_id'], str) and 0 < len(value['run_id']) <= 128, 'CUSTODY_RUN')
        roots = value['source_roots']
        _hr_need(type(roots) is list and 0 < len(roots) <= 16 and len(set(roots)) == len(roots), 'CUSTODY_ROOTS')
        self.value = dict(value)
        self.roots = [pathlib.Path(p) for p in roots]
        self.stage = pathlib.Path(value['stage_dir'])
        _hr_need(all(p.is_absolute() and '..' not in p.parts and str(p) != '/' for p in [self.stage, *self.roots]), 'CUSTODY_ROOTS')
        _hr_need(any(self.stage.is_relative_to(p) for p in self.roots), 'STAGE_OUTSIDE_ROOTS')
        stage_root = max((p for p in self.roots if self.stage.is_relative_to(p)), key=lambda p: len(p.parts))
        with _hr_fd(self.stage, True) as stage_fd, _hr_fd(stage_root, True) as root_fd:
            _hr_need(os.fstat(stage_fd).st_dev == os.fstat(root_fd).st_dev, 'STAGE_CROSS_DEVICE')
        self.state = _HR_RUNS.setdefault(value['run_id'], {'reads': 0, 'snapshots': 0, 'members': 0, 'records': 0, 'next': {}, 'cache': {}})
        self.aliases = {}
        self.fragment = {'encoding': 'happyranch-freezer-fragment@1', **value, 'events': []}

    def charge(self, size, snapshots=False):
        key, cap = ('snapshots', 2 * 1024**3) if snapshots else ('reads', 8 * 1024**3)
        self.state[key] += size
        _hr_need(self.state[key] <= cap, 'CUMULATIVE_BYTE_CAP')

    def event(self, kind, payload):
        self.state['members'] += 1
        _hr_need(self.state['members'] <= 16384, 'CUMULATIVE_MEMBER_CAP')
        self.fragment['events'].append({'ordinal': len(self.fragment['events']), 'kind': kind, 'payload': payload})
        _hr_need(len(_hr_encode(self.fragment)) <= 8 * 1024**2, 'FRAGMENT_CAP')
        return payload

    def resolve(self, path):
        original = pathlib.Path(path)
        roots = [p for p in self.roots if original.is_relative_to(p)]
        _hr_need(roots, 'SOURCE_OUTSIDE_ROOTS')
        root = max(roots, key=lambda p: len(p.parts))
        pending, done, aliases, seen = list(original.relative_to(root).parts), [], [], set()
        while pending:
            part = pending.pop(0)
            if part in ('', '.'):
                continue
            if part == '..':
                _hr_need(done, 'LINK_ESCAPE')
                done.pop()
                continue
            current = root.joinpath(*done, part)
            with _hr_fd(current.parent, True) as fd:
                info = os.stat(part, dir_fd=fd, follow_symlinks=False)
                if _hr_stat.S_ISLNK(info.st_mode):
                    target = os.readlink(part, dir_fd=fd)
                    _hr_need(_hr_identity(info) == _hr_identity(os.stat(part, dir_fd=fd, follow_symlinks=False)), 'LINK_UNSTABLE')
                    _hr_need(info.st_uid in (0, os.getuid()) and not os.path.isabs(target)
                             and 0 < len(target.encode()) <= 1024, 'LINK_TARGET_INVALID')
                    _hr_need(str(current) not in seen and len(aliases) < 16, 'LINK_CYCLE_OR_HOPS')
                    seen.add(str(current))
                    aliases.append({'relative': current.relative_to(root).as_posix(), 'target': target, 'identity': _hr_identity(info)})
                    pending = target.split('/') + pending
                else:
                    _hr_need(_hr_stat.S_ISDIR(info.st_mode) if pending else _hr_stat.S_ISREG(info.st_mode), 'LINK_TERMINAL_KIND')
                    done.append(part)
        return root.joinpath(*done), aliases, root

    def subject(self, path, retain=True, cap=512 * 1024**2):
        original_path = pathlib.Path(path)
        path, aliases, alias_root = self.resolve(path)
        if aliases:
            self.event('source_alias', {'root': str(alias_root), 'original': original_path.relative_to(alias_root).as_posix(),
                                       'terminal': path.relative_to(alias_root).as_posix(), 'aliases': aliases})
        choices = [p for p in self.roots if path.is_relative_to(p)]
        _hr_need(choices, 'SOURCE_OUTSIDE_ROOTS')
        root = max(choices, key=lambda p: len(p.parts))
        _hr_name(path.relative_to(root).as_posix())
        with _hr_fd(path) as src, _hr_fd(root, True) as root_fd:
            info = os.fstat(src)
            _hr_need(info.st_dev == os.fstat(root_fd).st_dev, 'SOURCE_CROSS_DEVICE')
            _hr_need(info.st_size <= cap, 'SUBJECT_CAP')
            self.charge(info.st_size + 1)
            digest = hashlib.sha256()
            snap = None
            out = None
            with _hr_contextlib.ExitStack() as destination:
                if retain:
                    key = str(self.stage)
                    ordinal = self.state['next'].get(key, 0)
                    self.state['next'][key] = ordinal + 1
                    snap = self.stage / f'{ordinal}.bin'
                    self.charge(info.st_size, True)
                    stage_fd = destination.enter_context(_hr_fd(self.stage, True))
                    out = os.open(snap.name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC,
                                  0o600, dir_fd=stage_fd)
                try:
                    count = 0
                    while True:
                        data = os.read(src, min(65536, cap - count + 1))
                        if not data:
                            break
                        count += len(data)
                        _hr_need(count <= cap, 'SUBJECT_CAP')
                        digest.update(data)
                        if out is not None:
                            view = memoryview(data)
                            while view:
                                n = os.write(out, view)
                                _hr_need(n > 0, 'SNAPSHOT_WRITE')
                                view = view[n:]
                    _hr_need(count == info.st_size, 'SUBJECT_SHORT_OR_GROWING')
                    if out is not None:
                        os.fsync(out)
                finally:
                    if out is not None:
                        os.close(out)
            result = {'root': str(root), 'relative': path.relative_to(root).as_posix(),
                      'identity': _hr_identity(info), 'size': count, 'sha256': digest.hexdigest(),
                      'snapshot': str(snap) if snap else None}
        if aliases:
            self.aliases[str(path)] = (original_path, aliases)
        return result

    def stable(self, subject):
        path = str(pathlib.Path(subject['root']) / subject['relative'])
        if path in self.aliases:
            original, old = self.aliases[path]
            resolved, current, _ = self.resolve(original)
            _hr_need(str(resolved) == path and current == old, 'CONSUMED_ALIAS_CHANGED')
        now = self.subject(pathlib.Path(subject['root']) / subject['relative'], False)
        _hr_need(all(now[k] == subject[k] for k in ('root', 'relative', 'identity', 'size', 'sha256')), 'CONSUMPTION_UNSTABLE')

    def rows(self, toc, stage):
        rows = []
        for i, (name, src, kind) in enumerate(toc):
            _hr_need(kind in ('PYMODULE', 'PYMODULE-1', 'PYMODULE-2', 'PYSOURCE', 'PYSOURCE-1', 'PYSOURCE-2',
                              'EXTENSION', 'BINARY', 'DATA', 'ZIPFILE', 'PYZ', 'EXECUTABLE', 'SYMLINK', 'OPTION'), 'UNSUPPORTED_KIND')
            _hr_need(isinstance(name, str) and 0 < len(name.encode()) <= 1024, 'NAME_INVALID')
            if kind != 'OPTION':
                _hr_name(os.path.normpath(name))
            literal = str(src) if kind == 'SYMLINK' else name if kind == 'OPTION' else None
            if kind == 'SYMLINK':
                _hr_need(not os.path.isabs(literal) and len(literal.encode()) <= 1024, 'LINK_TARGET_INVALID')
            structural = src in (None, '-') and kind.startswith('PYMODULE')
            subject = None if literal is not None or structural else self.subject(src, cap=(512 * 1024**2 if kind in ('PYZ','EXECUTABLE') or name == 'base_library.zip' else 256 * 1024**2 if kind in ('BINARY','EXTENSION') else 16 * 1024**2))
            rows.append({'id': f"{self.value['lane']}:{stage}:{i}", 'destination': name, 'source': src,
                         'kind': kind, 'literal': literal, 'subject': subject})
            self.state['members'] += 1
            _hr_need(self.state['members'] <= 16384, 'CUMULATIVE_MEMBER_CAP')
        return rows

    def admit(self, raw, stage):
        selected, names = [], set()
        for row in raw:
            key = os.path.normpath(row['destination'])
            if row['kind'] == 'OPTION' or key not in names:
                selected.append((row['destination'], row['source'], row['kind']))
                names.add(key)
        self.normalize(raw, selected, stage)

    def normalize(self, raw, normalized, stage):
        groups = {}
        for row in raw:
            if row['kind'] == 'OPTION':
                continue
            key = os.path.normpath(row['destination'])
            old = groups.setdefault(key, [])
            if old:
                a, b = old[0], row
                _hr_need(a['kind'] == b['kind'] and a['literal'] == b['literal']
                         and ((a['subject'] is None and b['subject'] is None)
                              or (a['subject'] is not None and b['subject'] is not None
                                  and (a['subject']['size'], a['subject']['sha256']) == (b['subject']['size'], b['subject']['sha256']))),
                         stage + '_CONTRIBUTOR_CONFLICT')
            old.append(row)
        edges = []
        options = [r for r in raw if r['kind'] == 'OPTION']
        option_index = 0
        for i, (name, src, kind) in enumerate(normalized):
            if kind == 'OPTION':
                _hr_need(option_index < len(options) and name == options[option_index]['destination'], stage + '_NORMALIZATION_LOSS')
                ids = [options[option_index]['id']]
                option_index += 1
            else:
                members = groups.pop(os.path.normpath(name), [])
                _hr_need(members and members[0]['kind'] == kind, stage + '_NORMALIZATION_LOSS')
                ids = [r['id'] for r in members]
            edges.append({'normalized': i, 'contributors': ids})
        _hr_need(not groups and option_index == len(options), stage + '_NORMALIZATION_LOSS')
        return edges

    def options(self, site, declared_strip, declared_upx, effective_strip, effective_upx, **settings):
        from PyInstaller.config import CONF
        availability = CONF['upx_available']
        force = os.environ.get('PYINSTALLER_FORCE_UPX')
        _hr_need(all(type(v) is bool for v in (availability, declared_strip, declared_upx, effective_strip, effective_upx)), 'OPTION_TYPE')
        _hr_need(force is None or (isinstance(force, str) and len(force.encode()) <= 128), 'OPTION_FORCE')
        _hr_need(effective_strip == declared_strip and effective_upx == (availability and declared_upx), 'OPTION_INCONSISTENT')
        _hr_need(not effective_strip and not effective_upx, 'UNSUPPORTED_EFFECTIVE_OPTION:' + site)
        return self.event('options', {'site': site, 'declared_strip': declared_strip, 'declared_upx': declared_upx,
                                     'availability': availability, 'force': force, 'effective_strip': effective_strip,
                                     'effective_upx': effective_upx, **settings})

    def finish(self):
        raw = _hr_encode(self.fragment)
        self.state['records'] += len(raw)
        _hr_need(self.state['records'] <= 32 * 1024**2, 'AGGREGATE_RECORD_CAP')
        _hr_need(len(raw) <= 8 * 1024**2, 'FRAGMENT_CAP')
        with _hr_fd(self.stage, True) as fd:
            out = os.open('fragment.json', os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600, dir_fd=fd)
            try:
                view = memoryview(raw)
                while view:
                    n = os.write(out, view[:65536])
                    _hr_need(n > 0, 'FRAGMENT_WRITE')
                    view = view[n:]
                os.fsync(out)
            finally:
                os.close(out)
        return self.fragment



def process_collected_binary(
    src_name,
    dest_name,
    use_strip=False,
    use_upx=False,
    upx_exclude=None,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    strict_arch_validation=False,
    custody=None
):
    """
    Process the collected binary using strip or UPX (or both), and apply any platform-specific processing. On macOS,
    this rewrites the library paths in the headers, and (re-)signs the binary. On-disk cache is used to avoid processing
    the same binary with same options over and over.

    In addition to given arguments, this function also uses CONF['cachedir'] and CONF['upx_dir'].
    """
    from PyInstaller.config import CONF

    # HappyRanch custody revision 1: admission precedes every early return/cache.
    witness = _HRCustody(custody) if custody is not None else None
    if witness:
        _hr_need(type(strict_arch_validation) is bool, 'OPTION_TYPE')
        option = witness.options('process_entry', use_strip, use_upx, use_strip, use_upx,
                                 destination=dest_name, target_arch=target_arch,
                                 strict_arch_validation=strict_arch_validation,
                                 signing_sha256=hashlib.sha256(codesign_identity.encode()).hexdigest() if codesign_identity else None,
                                 entitlements=witness.subject(entitlements_file, cap=256 * 1024) if entitlements_file else None)
        original = witness.subject(src_name, cap=256 * 1024**2)
    outcome = 'completed'

    def custody_return(path, cache, prior=None):
        if not witness:
            return path
        witness.options('process_return', use_strip, use_upx, use_strip, use_upx)
        witness.stable(original)
        returned = witness.subject(path, cap=256 * 1024**2)
        if cache == 'cache_hit':
            _hr_need(prior is not None and _hr_option_identity(prior['options']) == _hr_option_identity(option)
                     and (prior['input']['sha256'], prior['input']['size']) == (original['sha256'], original['size'])
                     and (prior['returned']['sha256'], prior['returned']['size']) == (returned['sha256'], returned['size']),
                     'CACHE_PREDECESSOR_MISMATCH')
            actual_outcome = prior['outcome']
        else:
            actual_outcome = outcome
        operation = witness.event('native_return', {'input': original, 'returned': returned, 'options': option,
                                  'cache': cache, 'outcome': actual_outcome, 'predecessor': prior,
                                  'path': path, 'destination': dest_name})
        if cache != 'cache_hit':
            witness.state['cache'][path] = operation
        witness.finish()
        return {'path': path, 'operation': operation}

    # We need to use cache in the following scenarios:
    #  * extra binary processing due to use of `strip` or `upx`
    #  * building on macOS, where we need to rewrite library paths in binaries' headers and (re-)sign the binaries.
    if not use_strip and not use_upx and not is_darwin:
        return custody_return(src_name, 'unchanged')

    # Match against provided UPX exclude patterns.
    upx_exclude = upx_exclude or []
    if use_upx:
        src_path = pathlib.PurePath(src_name)
        for upx_exclude_entry in upx_exclude:
            # pathlib.PurePath.match() matches from right to left, and supports * wildcard, but does not support the
            # "**" syntax for directory recursion. Case sensitivity follows the OS default.
            if src_path.match(upx_exclude_entry):
                logger.info("Disabling UPX for %s due to match in exclude pattern: %s", src_name, upx_exclude_entry)
                use_upx = False
                break

    # Additional automatic disablement rules for UPX and strip.

    # On Windows, avoid using UPX with binaries that have control flow guard (CFG) enabled.
    if use_upx and is_win and versioninfo.pefile_check_control_flow_guard(src_name):
        logger.info('Disabling UPX for %s due to CFG!', src_name)
        use_upx = False

    # Avoid using UPX with Qt plugins, as it strips the data required by the Qt plugin loader.
    if use_upx and misc.is_file_qt_plugin(src_name):
        logger.info('Disabling UPX for %s due to it being a Qt plugin!', src_name)
        use_upx = False

    # On linux, if a binary has an accompanying HMAC or CHK file, avoid modifying it in any way.
    if (use_upx or use_strip) and is_linux:
        src_path = pathlib.Path(src_name)
        hmac_path = src_path.with_name(f".{src_path.name}.hmac")
        chk_path = src_path.with_suffix(".chk")
        if hmac_path.is_file():
            logger.info('Disabling UPX and/or strip for %s due to accompanying .hmac file!', src_name)
            use_upx = use_strip = False
        elif chk_path.is_file():
            logger.info('Disabling UPX and/or strip for %s due to accompanying .chk file!', src_name)
            use_upx = use_strip = False
        del src_path, hmac_path, chk_path

    # Exit early if no processing is required after above rules are applied.
    if not use_strip and not use_upx and not is_darwin:
        return custody_return(src_name, 'unchanged')

    # Prepare cache directory path. Cache is tied to python major/minor version, but also to various processing options.
    pyver = f'py{sys.version_info[0]}{sys.version_info[1]}'
    arch = platform.architecture()[0]
    cache_dir = os.path.join(
        CONF['cachedir'],
        f'bincache{use_strip:d}{use_upx:d}{pyver}{arch}',
    )
    if target_arch:
        cache_dir = os.path.join(cache_dir, target_arch)
    if is_darwin:
        # Separate by codesign identity
        if codesign_identity:
            # Compute hex digest of codesign identity string to prevent issues with invalid characters.
            csi_hash = hashlib.sha256(codesign_identity.encode('utf-8'))
            cache_dir = os.path.join(cache_dir, csi_hash.hexdigest())
        else:
            cache_dir = os.path.join(cache_dir, 'adhoc')  # ad-hoc signing
        # Separate by entitlements
        if entitlements_file:
            # Compute hex digest of entitlements file contents
            with open(entitlements_file, 'rb') as fp:
                ef_hash = hashlib.sha256(fp.read())
            cache_dir = os.path.join(cache_dir, ef_hash.hexdigest())
        else:
            cache_dir = os.path.join(cache_dir, 'no-entitlements')
    os.makedirs(cache_dir, exist_ok=True)

    # Load cache index, if available
    cache_index_file = os.path.join(cache_dir, "index.dat")
    try:
        cache_index = misc.load_py_data_struct(cache_index_file)
    except FileNotFoundError:
        cache_index = {}
    except Exception:
        # Tell the user they may want to fix their cache... However, do not delete it for them; if it keeps getting
        # corrupted, we will never find out.
        logger.warning("PyInstaller bincache may be corrupted; use pyinstaller --clean to fix it.")
        raise

    # Look up the file in cache; use case-normalized destination name as identifier.
    cached_id = os.path.normcase(dest_name)
    cached_name = os.path.join(cache_dir, dest_name)
    src_digest = _compute_file_digest(src_name)

    if cached_id in cache_index:
        # If digest matches to the cached digest, return the cached file...
        if src_digest == cache_index[cached_id]:
            return custody_return(cached_name, 'cache_hit', witness.state['cache'].get(cached_name) if witness else None)

        # ... otherwise remove it.
        os.remove(cached_name)

    # Ensure parent path exists
    os.makedirs(os.path.dirname(cached_name), exist_ok=True)

    # Use `shutil.copyfile` to copy the file with default permissions bits, then manually set executable
    # bits. This way, we avoid copying permission bits and metadata from the original file, which might be too
    # restrictive for further processing (read-only permissions, immutable flag on FreeBSD, and so on).
    shutil.copyfile(src_name, cached_name)
    os.chmod(cached_name, 0o755)

    # Apply strip
    if use_strip:
        strip_options = []
        if is_darwin:
            # The default strip behavior breaks some shared libraries under macOS.
            strip_options = ["-S"]  # -S = strip only debug symbols.
        elif is_aix:
            # Set -X32_64 flag to have strip transparently process both 32-bit and 64-bit binaries, without user having
            # to set OBJECT_MODE environment variable prior to the build. Also accommodates potential mixed-case
            # scenario, for example a 32-bit utility program being collected into a 64-bit application bundle.
            strip_options = ["-X32_64"]

        cmd = ["strip", *strip_options, cached_name]
        logger.info("Executing: %s", " ".join(cmd))
        try:
            p = subprocess.run(
                cmd,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                check=True,
                errors='ignore',
                encoding='utf-8',
            )
            logger.debug("Output from strip command:\n%s", p.stdout)
        except subprocess.CalledProcessError as e:
            show_warning = True

            # On AIX, strip utility raises an error when ran against already-stripped binary. Catch the corresponding
            # message (`0654-419 The specified archive file was already stripped.`) and suppress the warning.
            if is_aix and "0654-419" in e.stdout:
                show_warning = False

            if show_warning:
                logger.warning("Failed to run strip on %r!", cached_name, exc_info=True)
                logger.warning("Output from strip command:\n%s", e.stdout)
        except Exception:
            logger.warning("Failed to run strip on %r!", cached_name, exc_info=True)

    # Apply UPX
    if use_upx:
        upx_exe = 'upx'
        upx_dir = CONF['upx_dir']
        if upx_dir:
            upx_exe = os.path.join(upx_dir, upx_exe)

        upx_options = [
            # Do not compress icons, so that they can still be accessed externally.
            '--compress-icons=0',
            # Use LZMA compression.
            '--lzma',
            # Quiet mode.
            '-q',
        ]
        if is_win:
            # Binaries built with Visual Studio 7.1 require --strip-loadconf or they will not compress.
            upx_options.append('--strip-loadconf')

        cmd = [upx_exe, *upx_options, cached_name]
        logger.info("Executing: %s", " ".join(cmd))
        try:
            p = subprocess.run(
                cmd,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                check=True,
                errors='ignore',
                encoding='utf-8',
            )
            logger.debug("Output from upx command:\n%s", p.stdout)
        except subprocess.CalledProcessError as e:
            logger.warning("Failed to upx strip on %r!", cached_name, exc_info=True)
            logger.warning("Output from upx command:\n%s", e.stdout)
        except Exception:
            logger.warning("Failed to run upx on %r!", cached_name, exc_info=True)

    # On macOS, we need to modify the given binary's paths to the dependent libraries, in order to ensure they are
    # relocatable and always refer to location within the frozen application. Specifically, we make all dependent
    # library paths relative to @rpath, and set @rpath to point to the top-level application directory, relative to
    # the binary's location (i.e., @loader_path).
    #
    # While modifying the headers invalidates existing signatures, we avoid removing them in order to speed things up
    # (and to avoid potential bugs in the codesign utility, like the one reported on macOS 10.13 in #6167).
    # The forced re-signing at the end should take care of the invalidated signatures.
    if is_darwin:
        try:
            osxutils.binary_to_target_arch(cached_name, target_arch, display_name=src_name)
            #osxutils.remove_signature_from_binary(cached_name)  # Disabled as per comment above.
            target_rpath = str(
                pathlib.PurePath('@loader_path', *['..' for level in pathlib.PurePath(dest_name).parent.parts])
            )
            osxutils.set_dylib_dependency_paths(cached_name, target_rpath)
            osxutils.sign_binary(cached_name, codesign_identity, entitlements_file)
        except osxutils.InvalidBinaryError:
            outcome = 'non_macho_passthrough'
            # Raised by osxutils.binary_to_target_arch when the given file is not a valid macOS binary (for example,
            # a linux .so file; see issue #6327). The error prevents any further processing, so just ignore it.
            pass
        except osxutils.IncompatibleBinaryArchError:
            # Raised by osxutils.binary_to_target_arch when the given file does not contain (all) required arch slices.
            # Depending on the strict validation mode, re-raise or swallow the error.
            #
            # Strict validation should be enabled only for binaries where the architecture *must* match the target one,
            # i.e., the extension modules. Everything else is pretty much a gray area, for example:
            #  * a universal2 extension may have its x86_64 and arm64 slices linked against distinct single-arch/thin
            #    shared libraries
            #  * a collected executable that is launched by python code via a subprocess can be x86_64-only, even though
            #    the actual python code is running on M1 in native arm64 mode.
            if strict_arch_validation:
                raise
            outcome = 'optional_arch_passthrough'
            logger.debug("File %s failed optional architecture validation - collecting as-is!", src_name)
        except Exception as e:
            raise SystemError(f"Failed to process binary {cached_name!r}!") from e

    # Update cache index
    cache_index[cached_id] = src_digest
    misc.save_py_data_struct(cache_index_file, cache_index)

    return custody_return(cached_name, 'created')


def _compute_file_digest(filename):
    hasher = hashlib.sha1()
    with open(filename, "rb") as fp:
        for chunk in iter(lambda: fp.read(16 * 1024), b""):
            hasher.update(chunk)
    return bytearray(hasher.digest())


def _check_path_overlap(path):
    """
    Check that path does not overlap with WORKPATH or SPECPATH (i.e., WORKPATH and SPECPATH may not start with path,
    which could be caused by a faulty hand-edited specfile).

    Raise SystemExit if there is overlap, return True otherwise
    """
    from PyInstaller.config import CONF
    specerr = 0
    if CONF['workpath'].startswith(path):
        logger.error('Specfile error: The output path "%s" contains WORKPATH (%s)', path, CONF['workpath'])
        specerr += 1
    if CONF['specpath'].startswith(path):
        logger.error('Specfile error: The output path "%s" contains SPECPATH (%s)', path, CONF['specpath'])
        specerr += 1
    if specerr:
        raise SystemExit(
            'ERROR: Please edit/recreate the specfile (%s) and set a different output name (e.g. "dist").' %
            CONF['spec']
        )
    return True


def _make_clean_directory(path):
    """
    Create a clean directory from the given directory name.
    """
    if _check_path_overlap(path):
        if os.path.isdir(path) or os.path.isfile(path):
            try:
                os.remove(path)
            except OSError:
                _rmtree(path)

        os.makedirs(path, exist_ok=True)


def _rmtree(path):
    """
    Remove directory and all its contents, but only after user confirmation, or if the -y option is set.
    """
    from PyInstaller.config import CONF
    if CONF['noconfirm']:
        choice = 'y'
    elif sys.stdout.isatty():
        choice = input(
            'WARNING: The output directory "%s" and ALL ITS CONTENTS will be REMOVED! Continue? (y/N)' % path
        )
    else:
        raise SystemExit(
            'ERROR: The output directory "%s" is not empty. Please remove all its contents or use the -y option (remove'
            ' output directory without confirmation).' % path
        )
    if choice.strip().lower() == 'y':
        if not CONF['noconfirm']:
            print("On your own risk, you can use the option `--noconfirm` to get rid of this question.")
        logger.info('Removing dir %s', path)
        shutil.rmtree(path)
    else:
        raise SystemExit('User aborted')


# TODO Refactor to prohibit empty target directories. As the docstring below documents, this function currently permits
# the second item of each 2-tuple in "hook.datas" to be the empty string, in which case the target directory defaults to
# the source directory's basename. However, this functionality is very fragile and hence bad. Instead:
#
# * An exception should be raised if such item is empty.
# * All hooks currently passing the empty string for such item (e.g.,
#   "hooks/hook-babel.py", "hooks/hook-matplotlib.py") should be refactored
#   to instead pass such basename.
def format_binaries_and_datas(binaries_or_datas, workingdir=None):
    """
    Convert the passed list of hook-style 2-tuples into a returned set of `TOC`-style 2-tuples.

    Elements of the passed list are 2-tuples `(source_dir_or_glob, target_dir)`.
    Elements of the returned set are 2-tuples `(target_file, source_file)`.
    For backwards compatibility, the order of elements in the former tuples are the reverse of the order of elements in
    the latter tuples!

    Parameters
    ----------
    binaries_or_datas : list
        List of hook-style 2-tuples (e.g., the top-level `binaries` and `datas` attributes defined by hooks) whose:
        * The first element is either:
          * A glob matching only the absolute or relative paths of source non-Python data files.
          * The absolute or relative path of a source directory containing only source non-Python data files.
        * The second element is the relative path of the target directory into which these source files will be
          recursively copied.

        If the optional `workingdir` parameter is passed, source paths may be either absolute or relative; else, source
        paths _must_ be absolute.
    workingdir : str
        Optional absolute path of the directory to which all relative source paths in the `binaries_or_datas`
        parameter will be prepended by (and hence converted into absolute paths) _or_ `None` if these paths are to be
        preserved as relative. Defaults to `None`.

    Returns
    ----------
    set
        Set of `TOC`-style 2-tuples whose:
        * First element is the absolute or relative path of a target file.
        * Second element is the absolute or relative path of the corresponding source file to be copied to this target
          file.
    """
    toc_datas = set()

    for src_root_path_or_glob, trg_root_dir in binaries_or_datas:
        # Disallow empty source path. Those are typically result of errors, and result in implicit collection of the
        # whole current working directory, which is never a good idea.
        if not src_root_path_or_glob:
            raise InvalidSrcDestTupleError(
                (src_root_path_or_glob, trg_root_dir),
                "Empty SRC is not allowed when adding binary and data files, as it would result in collection of the "
                "whole current working directory."
            )
        if not trg_root_dir:
            raise InvalidSrcDestTupleError(
                (src_root_path_or_glob, trg_root_dir),
                "Empty DEST_DIR is not allowed - to collect files into application's top-level directory, use "
                f"{os.curdir!r}."
            )
        # Disallow absolute target paths, as well as target paths that would end up pointing outside of the
        # application's top-level directory.
        if os.path.isabs(trg_root_dir):
            raise InvalidSrcDestTupleError((src_root_path_or_glob, trg_root_dir), "DEST_DIR must be a relative path!")
        if os.path.normpath(trg_root_dir).startswith('..'):
            raise InvalidSrcDestTupleError(
                (src_root_path_or_glob, trg_root_dir),
                "DEST_DIR must not point outside of application's top-level directory!",
            )

        # Convert relative to absolute paths if required.
        if workingdir and not os.path.isabs(src_root_path_or_glob):
            src_root_path_or_glob = os.path.join(workingdir, src_root_path_or_glob)

        # Normalize paths.
        src_root_path_or_glob = os.path.normpath(src_root_path_or_glob)

        # If given source path is a file or directory path, pass it on.
        # If not, treat it as a glob and pass on all matching paths. However, we need to preserve the directories
        # captured by the glob - as opposed to collecting their contents into top-level target directory. Therefore,
        # we set a flag which is used in subsequent processing to distinguish between original directory paths and
        # directory paths that were captured by the glob.
        if os.path.isfile(src_root_path_or_glob) or os.path.isdir(src_root_path_or_glob):
            src_root_paths = [src_root_path_or_glob]
            was_glob = False
        else:
            src_root_paths = glob.glob(src_root_path_or_glob)
            was_glob = True

        if not src_root_paths:
            raise SystemExit(f'ERROR: Unable to find {src_root_path_or_glob!r} when adding binary and data files.')

        for src_root_path in src_root_paths:
            if os.path.isfile(src_root_path):
                # Normalizing the result to remove redundant relative paths (e.g., removing "./" from "trg/./file").
                toc_datas.add((
                    os.path.normpath(os.path.join(trg_root_dir, os.path.basename(src_root_path))),
                    os.path.normpath(src_root_path),
                ))
            elif os.path.isdir(src_root_path):
                for src_dir, src_subdir_basenames, src_file_basenames in os.walk(src_root_path):
                    # Ensure the current source directory is a subdirectory of the passed top-level source directory.
                    # Since os.walk() does *NOT* follow symlinks by default, this should be the case. (But let's make
                    # sure.)
                    assert src_dir.startswith(src_root_path)

                    # Relative path of the current target directory, obtained by:
                    #
                    # * Stripping the top-level source directory from the current source directory (e.g., removing
                    #   "/top" from "/top/dir").
                    # * Normalizing the result to remove redundant relative paths (e.g., removing "./" from
                    #   "trg/./file").
                    if was_glob:
                        # Preserve directories captured by glob.
                        rel_dir = os.path.relpath(src_dir, os.path.dirname(src_root_path))
                    else:
                        rel_dir = os.path.relpath(src_dir, src_root_path)
                    trg_dir = os.path.normpath(os.path.join(trg_root_dir, rel_dir))

                    for src_file_basename in src_file_basenames:
                        src_file = os.path.join(src_dir, src_file_basename)
                        if os.path.isfile(src_file):
                            # Normalize the result to remove redundant relative paths (e.g., removing "./" from
                            # "trg/./file").
                            toc_datas.add((
                                os.path.normpath(os.path.join(trg_dir, src_file_basename)), os.path.normpath(src_file)
                            ))

    return toc_datas


def get_code_object(modname, filename, optimize):
    """
    Get the code-object for a module.

    This is a simplifed non-performant version which circumvents __pycache__.
    """

    # Once upon a time, we compiled dummy code objects for PEP-420 namespace packages. We do not do that anymore.
    assert filename not in {'-', None}, "Called with PEP-420 namespace package!"

    _, ext = os.path.splitext(filename)
    ext = ext.lower()

    if ext == '.pyc':
        # The module is available in binary-only form. Read the contents of .pyc file using helper function, which
        # supports reading from either stand-alone or archive-embedded .pyc files.
        logger.debug('Reading code object from .pyc file %s', filename)
        pyc_data = _read_pyc_data(filename)
        code_object = marshal.loads(pyc_data[16:])
    else:
        # Assume this is a source .py file, but allow an arbitrary extension (other than .pyc, which is taken in
        # the above branch). This allows entry-point scripts to have an arbitrary (or no) extension, as tested by
        # the `test_arbitrary_ext` in `test_basic.py`.
        logger.debug('Compiling python script/module file %s', filename)

        with open(filename, 'rb') as f:
            source = f.read()

        # If entry-point script has no suffix, append .py when compiling the source. In POSIX builds, the executable
        # has no suffix either; this causes issues with `traceback` module, as it tries to read the executable file
        # when trying to look up the code for the entry-point script (when current working directory contains the
        # executable).
        _, ext = os.path.splitext(filename)
        if not ext:
            logger.debug("Appending .py to compiled entry-point name...")
            filename += '.py'

        try:
            code_object = compile(source, filename, 'exec', optimize=optimize)
        except SyntaxError:
            logger.warning("Sytnax error while compiling %s", filename)
            raise

    return code_object


def replace_filename_in_code_object(code_object, filename):
    """
    Recursively replace the `co_filename` in the given code object and code objects stored in its `co_consts` entries.
    Primarily used to anonymize collected code objects, i.e., by removing the build environment's paths from them.
    """

    consts = tuple(
        replace_filename_in_code_object(const_co, filename) if isinstance(const_co, types.CodeType) else const_co
        for const_co in code_object.co_consts
    )

    return code_object.replace(co_consts=consts, co_filename=filename)


def _should_include_system_binary(binary_tuple, exceptions):
    """
    Return True if the given binary_tuple describes a system binary that should be included.

    Exclude all system library binaries other than those with "lib-dynload" in the destination or "python" in the
    source, except for those matching the patterns in the exceptions list. Intended to be used from the Analysis
    exclude_system_libraries method.
    """
    dest = binary_tuple[0]
    if dest.startswith(f'python{sys.version_info.major}.{sys.version_info.minor}/lib-dynload'):
        return True
    src = binary_tuple[1]
    if fnmatch.fnmatch(src, '*python*'):
        return True
    if is_termux:
        # Termux linux; system libraries are in /system/lib{,64} and /data/data/com.termux/files/usr/lib; in addition
        # /usr is symbolic link pointing at /data/data/com.termux/files/usr
        SYS_PREFIX = ('/system/lib', '/data/data/com.termux/files/usr/lib', '/usr/lib')
    else:
        # Standard linux distributions; system libraries are in /lib{,64} and /usr/lib{,64}
        SYS_PREFIX = ('/lib', '/usr/lib')
    if not src.startswith(SYS_PREFIX):
        return True
    for exception in exceptions:
        if fnmatch.fnmatch(dest, exception):
            return True
    return False


def compile_pymodule(name, src_path, workpath, optimize, code_cache=None):
    """
    Given the name and source file for a pure-python module, compile the module in the specified working directory,
    and return the name of resulting .pyc file. The paths in the resulting .pyc module are anonymized by having their
    absolute prefix removed.

    If a .pyc file with matching name already exists in the target working directory, it is re-used (provided it has
    compatible bytecode magic in the header, and that its modification time is newer than that of the source file).

    If the specified module is available in binary-only form, the input .pyc file is copied to the target working
    directory and post-processed. If the specified module is available in source form, it is compiled only if
    corresponding code object is not available in the optional code-object cache; otherwise, it is copied from cache
    and post-processed. When compiling the module, the specified byte-code optimization level is used.

    It is up to caller to ensure that the optional code-object cache contains only code-objects of target optimization
    level, and that if the specified working directory already contains .pyc files, that they were created with target
    optimization level.
    """

    # Construct the target .pyc filename in the workpath
    split_name = name.split(".")
    if "__init__" in src_path:
        # __init__ module; use "__init__" as module name, and construct parent path using all components of the
        # fully-qualified name
        parent_dirs = split_name
        mod_basename = "__init__"
    else:
        # Regular module; use last component of the fully-qualified name as module name, and the rest as the parent
        # path.
        parent_dirs = split_name[:-1]
        mod_basename = split_name[-1]
    pyc_path = os.path.join(workpath, *parent_dirs, mod_basename + '.pyc')

    # Check if optional cache contains module entry
    code_object = code_cache.get(name, None) if code_cache else None

    if code_object is None:
        _, ext = os.path.splitext(src_path)
        ext = ext.lower()

        if ext == '.py':
            # Source py file; read source and compile it.
            with open(src_path, 'rb') as f:
                src_data = f.read()
            code_object = compile(src_data, src_path, 'exec', optimize=optimize)
        elif ext == '.pyc':
            # The module is available in binary-only form. Read the contents of .pyc file using helper function, which
            # supports reading from either stand-alone or archive-embedded .pyc files.
            pyc_data = _read_pyc_data(src_path)
            # Unmarshal code object; this is necessary if we want to strip paths from it
            code_object = marshal.loads(pyc_data[16:])
        else:
            raise ValueError(f"Invalid python module file {src_path}; unhandled extension {ext}!")

    # Replace co_filename in code object with anonymized filename that does not contain full path. Construct the
    # relative filename from module name, similar how we earlier constructed the `pyc_path`.
    co_filename = os.path.join(*parent_dirs, mod_basename + '.py')
    code_object = replace_filename_in_code_object(code_object, co_filename)

    # Write complete .pyc module to in-memory stream. Then, check if .pyc file already exists, compare contents, and
    # (re)write it only if different. This avoids unnecessary (re)writing of the file, and in turn also avoids
    # unnecessary cache invalidation for targets that make use of the .pyc file (e.g., PKG, COLLECT).
    with io.BytesIO() as pyc_stream:
        pyc_stream.write(compat.BYTECODE_MAGIC)
        pyc_stream.write(struct.pack('<I', 0b01))  # PEP-552: hash-based pyc, check_source=False
        pyc_stream.write(b'\00' * 8)  # Zero the source hash
        marshal.dump(code_object, pyc_stream)
        pyc_data = pyc_stream.getvalue()

    if os.path.isfile(pyc_path):
        with open(pyc_path, 'rb') as fh:
            existing_pyc_data = fh.read()
        if pyc_data == existing_pyc_data:
            return pyc_path  # Return path to (existing) file.

    # Ensure the existence of parent directories for the target pyc path
    os.makedirs(os.path.dirname(pyc_path), exist_ok=True)

    # Write
    with open(pyc_path, 'wb') as fh:
        fh.write(pyc_data)

    # Return output path
    return pyc_path


def _read_pyc_data(filename):
    """
    Helper for reading data from .pyc files. Supports both stand-alone and archive-embedded .pyc files. Used by
    `compile_pymodule` and `get_code_object` helper functions.
    """
    src_file = pathlib.Path(filename)

    if src_file.is_file():
        # Stand-alone .pyc file.
        pyc_data = src_file.read_bytes()
    else:
        # Check if .pyc file is stored in a .zip archive, as is the case for stdlib modules in embeddable
        # python on Windows.
        parent_zip_file = misc.path_to_parent_archive(src_file)
        if parent_zip_file is not None and zipfile.is_zipfile(parent_zip_file):
            with zipfile.ZipFile(parent_zip_file, 'r') as zip_archive:
                # NOTE: zip entry names must be in POSIX format, even on Windows!
                zip_entry_name = str(src_file.relative_to(parent_zip_file).as_posix())
                pyc_data = zip_archive.read(zip_entry_name)
        else:
            raise FileNotFoundError(f"Cannot find .pyc file {filename!r}!")

        # Verify the python version
        if pyc_data[:4] != compat.BYTECODE_MAGIC:
            raise ValueError(f"The .pyc module {filename} was compiled for incompatible version of python!")

    return pyc_data


def postprocess_binaries_toc_pywin32(binaries):
    """
    Process the given `binaries` TOC list to apply work around for `pywin32` package, fixing the target directory
    for collected extensions.
    """
    # Ensure that all files collected from `win32`  or `pythonwin` into top-level directory are put back into
    # their corresponding directories. They end up in top-level directory because `pywin32.pth` adds both
    # directories to the `sys.path`, so they end up visible as top-level directories. But these extensions
    # might in fact be linked against each other, so we should preserve the directory layout for consistency
    # between modulegraph-discovered extensions and linked binaries discovered by link-time dependency analysis.
    # Within the same framework, also consider `pywin32_system32`, just in case.
    PYWIN32_SUBDIRS = {'win32', 'pythonwin', 'pywin32_system32'}

    processed_binaries = []
    for dest_name, src_name, typecode in binaries:
        dest_path = pathlib.PurePath(dest_name)
        src_path = pathlib.PurePath(src_name)

        if dest_path.parent == pathlib.PurePath('.') and src_path.parent.name.lower() in PYWIN32_SUBDIRS:
            dest_path = pathlib.PurePath(src_path.parent.name) / dest_path
            dest_name = str(dest_path)

        processed_binaries.append((dest_name, src_name, typecode))

    return processed_binaries


def postprocess_binaries_toc_pywin32_anaconda(binaries):
    """
    Process the given `binaries` TOC list to apply work around for Anaconda `pywin32` package, fixing the location
    of collected `pywintypes3X.dll` and `pythoncom3X.dll`.
    """
    # The Anaconda-provided `pywin32` package installs three copies of `pywintypes3X.dll` and `pythoncom3X.dll`,
    # located in the following directories (relative to the environment):
    # - Library/bin
    # - Lib/site-packages/pywin32_system32
    # - Lib/site-packages/win32
    #
    # This turns our dependency scanner and directory layout preservation mechanism into a lottery based on what
    # `pywin32` modules are imported and in what order. To keep things simple, we deal with this insanity by
    # post-processing the `binaries` list, modifying the destination of offending copies, and let the final TOC
    # list normalization deal with potential duplicates.
    DLL_CANDIDATES = {
        f"pywintypes{sys.version_info[0]}{sys.version_info[1]}.dll",
        f"pythoncom{sys.version_info[0]}{sys.version_info[1]}.dll",
    }

    DUPLICATE_DIRS = {
        pathlib.PurePath('.'),
        pathlib.PurePath('win32'),
    }

    processed_binaries = []
    for dest_name, src_name, typecode in binaries:
        # Check if we need to divert - based on the destination base name and destination parent directory.
        dest_path = pathlib.PurePath(dest_name)
        if dest_path.name.lower() in DLL_CANDIDATES and dest_path.parent in DUPLICATE_DIRS:
            dest_path = pathlib.PurePath("pywin32_system32") / dest_path.name
            dest_name = str(dest_path)

        processed_binaries.append((dest_name, src_name, typecode))

    return processed_binaries


def create_base_library_zip(filename, modules_toc, code_cache=None):
    """
    Create a zip archive with python modules that are needed during python interpreter initialization.
    """
    with zipfile.ZipFile(filename, 'w') as zf:
        for name, src_path, typecode in sorted(modules_toc, key=lambda entry: entry[0]):
            # Obtain code object from cache, or compile it.
            code = None if code_cache is None else code_cache.get(name, None)
            if code is None:
                optim_level = {'PYMODULE': 0, 'PYMODULE-1': 1, 'PYMODULE-2': 2}[typecode]
                code = get_code_object(name, src_path, optimize=optim_level)
            # Determine destination name
            dest_name = name.replace('.', os.sep)
            # Special case: packages have an implied `__init__` filename that needs to be added.
            basename, ext = os.path.splitext(os.path.basename(src_path))
            if basename == '__init__':
                dest_name += os.sep + '__init__'
            dest_name += '.pyc'  # Always .pyc, regardless of optimization level.
            # Replace full-path co_filename in code object with `dest_name` (and shorten suffix from .pyc to .py).
            code = replace_filename_in_code_object(code, dest_name[:-1])
            # Write the .pyc module
            with io.BytesIO() as fc:
                fc.write(compat.BYTECODE_MAGIC)
                fc.write(struct.pack('<I', 0b01))  # PEP-552: hash-based pyc, check_source=False
                fc.write(b'\00' * 8)  # Match behavior of `building.utils.compile_pymodule`
                marshal.dump(code, fc)
                # Use a ZipInfo to set timestamp for deterministic build.
                info = zipfile.ZipInfo(dest_name)
                zf.writestr(info, fc.getvalue())
